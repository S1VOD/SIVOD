// src/components/auth/LoginForm.js
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

// Importar iconos
import emailIcon from '../../assets/icons/icon-white/icon05.ico';
import candado from '../../assets/icons/icon-white/candado.png';
import contrasena from '../../assets/icons/icon-white/contrasena.png';
import ingresar from '../../assets/icons/icon-white/ingresar.png';
import seguroIcon from '../../assets/icons/icon-white/icon12.ico';
import acceso from '../../assets/icons/icon-white/icon04.ico';

const LoginForm = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('http://localhost:8000/api/v1/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password
        })
      });

      const data = await response.json();
      console.log('Login response:', data);

      if (response.ok && data.success) {
        const token = data.token;
        
        if (!token) {
          throw new Error('No se recibió token del servidor');
        }

        // Extraer datos del usuario de la respuesta
        const userData = data.user || {};
        const userProfile = {
          ...userData,
          nombre: userData.nombre || '',
          ape_pa: userData.ape_pa || '',
          correo: userData.correo || formData.email,
          activo: userData.activo !== undefined ? userData.activo : 0
        };

        const userId = userData.id || userData.id_edu || userData.id_adm || userData.id_tut || userData.id_alu;
        const userType = userData.userType || data.userType || 'educativo';

        console.log('Datos extraídos del login:', {
          token,
          userId,
          userType,
          userProfile,
          accountActive: userProfile.activo === 1
        });

        // Usar el contexto de autenticación para login
        login(
          userProfile, // datos del usuario principal
          token,       // token
          {
            userId: userId.toString(),
            userType: userType,
            userProfile: userProfile
          }
        );

        // Redirigir siempre al dashboard después del login
        console.log('Login exitoso, redirigiendo a dashboard');
        navigate('/dashboard');
        
      } else {
        setError(data.detail || data.message || 'Error en el login');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError(error.message || 'Error de conexión con el servidor');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (error) setError('');
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden transform hover:shadow-3xl transition-all duration-300 max-w-md mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-twine-400/70 to-twine-600/90 py-4 px-6 text-center border-b border-white/20">
        <div className="w-16 h-16 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
          <img src={acceso} alt="Acceso" className="w-10 h-10 filter brightness-0 invert" />
        </div>
        <h2 className="text-xl font-patria font-bold text-white mb-1">
          Iniciar Sesión
        </h2>
        <p className="text-white/90 font-patria text-sm">
          Accede a tu cuenta en <span className="font-semibold">SIVOD</span>
        </p>
      </div>

      {/* Formulario */}
      <div className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Mensaje de error */}
          {error && (
            <div className="bg-red-500/20 border border-red-400/50 rounded-xl p-3">
              <p className="text-red-200 text-sm font-patria text-center">
                {error}
              </p>
            </div>
          )}

          {/* Correo Institucional */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-white font-patria">
              Correo Institucional
            </label>
            <div className="relative">
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 pl-10 hover:border-white/30 text-white placeholder-twine-200 font-patria text-sm"
                placeholder="usuario@sep.gob.mx"
                required
                disabled={isLoading}
              />
              <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                <img src={emailIcon} alt="Email" className="w-4 h-4 filter brightness-0 invert opacity-80" />
              </div>
            </div>
            <p className="text-xs text-twine-200 font-patria">
              Usa tu correo institucional registrado
            </p>
          </div>

          {/* Contraseña */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-white font-patria">
              Contraseña
            </label>
            <div className="relative">
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 pl-10 hover:border-white/30 text-white placeholder-twine-200 font-patria text-sm"
                placeholder="••••••••"
                required
                disabled={isLoading}
                minLength="6"
              />
              <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                <img src={candado} alt="Candado" className="w-4 h-4 filter brightness-0 invert opacity-80" />
              </div>
            </div>
            <p className="text-xs text-twine-200 font-patria">
              Contraseña segura requerida
            </p>
          </div>

          {/* Botón de Login */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-xl hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-2 font-patria text-sm"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Conectando...
              </>
            ) : (
              <>
                <img src={ingresar} alt="Ingresar" className="w-6 h-6 filter brightness-0 invert" />
                Iniciar Sesión
              </>
            )}
          </button>

          {/* Enlaces adicionales */}
          <div className="text-center space-y-3 pt-4 border-t border-white/10">
            <div>
              <Link
                to="/forgot-password"
                className="text-twine-300 hover:text-white font-medium transition-colors duration-300 font-patria flex items-center justify-center gap-2 text-sm"
              >
                <img src={contrasena} alt="" className="w-5 h-5 filter brightness-0 invert" />
                ¿Olvidaste tu contraseña?
              </Link>
            </div>
            <div>
              <Link
                to="/register"
                className="text-white hover:text-twine-200 font-medium transition-colors duration-300 font-patria flex items-center justify-center gap-2 text-sm"
              >
                <img src={acceso} alt="" className="w-5 h-5 filter brightness-0 invert" />
                ¿No tienes cuenta? Regístrate ahora
              </Link>
            </div>
          </div>

          {/* Info adicional */}
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
            <div className="flex items-start gap-3">
              <img src={seguroIcon} alt="Seguro" className="w-10 h-10 filter brightness-0 invert" />
              <div>
                <p className="text-sm text-white font-medium font-patria">
                  Acceso Seguro
                </p>
                <p className="text-xs text-twine-200 font-patria">
                  Tu información está protegida con encriptación de última generación
                </p>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;