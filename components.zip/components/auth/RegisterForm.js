import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import docenteIcon from '../../assets/icons/icon-white/icon10.ico';
import estudianteIcon from '../../assets/icons/icon-white/icon08.ico';
import tutorIcon from '../../assets/icons/icon-white/icon9.ico';
import directorIcon from '../../assets/icons/icon-white/director.png';
import administrativoIcon from '../../assets/icons/icon-white/icon14.ico';
import escuela from '../../assets/icons/icon-white/icon03.ico';
import candadoIcon from '../../assets/icons/icon-white/candado.png';
import notas from '../../assets/icons/icon-white/icon11.ico';
import acceso from '../../assets/icons/icon-white/icon04.ico';
import { AlertService } from '../common/Alerts'; 

const RegisterForm = () => {
  // Estado inicial - IMPORTANTE: Los nombres deben coincidir con el backend
  const [formData, setFormData] = useState({
    // Campos que el backend espera EXACTAMENTE como en RegisterRequest
    userType: 'educativo', // educativo, administrativo, tutor, alumno
    nombre: '',
    ape_pa: '',
    ape_ma: '',
    curp: '',
    fecha_nac: '',
    correo: '', // IMPORTANTE: El backend espera 'correo', no 'correo'
    contrasena: '', // IMPORTANTE: El backend espera 'contrasena', no 'contrasena'
    confirmcontrasena: '',
    
    // Campos específicos para backend
    rol_id: null, // Solo para educativos
    cargo: '', // Solo para administrativos
    ocupacion: '', // Solo para tutores
    id_tutor: null, // Solo para alumnos
    
    // Campos adicionales para UI (no se envían al backend)
    cct: '',
    escuelaNombre: '',
    grado: '',
    grupo: '',
    municipio: '',
    estado: '',
    telefono: '',
    aceptaTerminos: false
  });
  
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isSearchingSchool, setIsSearchingSchool] = useState(false);

  // Mapeo de tipos de usuario frontend -> backend
  const userTypeMapping = {
    docente: { 
      backendType: 'educativo', 
      rol_id: 3, // 3 = docente por defecto
      title: 'Docente'
    },
    director: { 
      backendType: 'educativo', 
      rol_id: 2, // 2 = director
      title: 'Director'
    },
    administrativo: { 
      backendType: 'administrativo', 
      title: 'Personal Administrativo'
    },
    padre: { 
      backendType: 'tutor', 
      title: 'Tutor'
    },
    estudiante: { 
      backendType: 'alumno', 
      title: 'Estudiante'
    }
  };

const handleSubmit = async (e) => {
  e.preventDefault();
  
  // Validaciones básicas
  if (!formData.aceptaTerminos) {
    await AlertService.error(
      'Términos y Condiciones',
      'Debes aceptar los términos y condiciones para continuar'
    );
    return;
  }
  
  if (formData.contrasena !== formData.confirmcontrasena) {
    await AlertService.error(
      'Contraseñas no coinciden',
      'Las contraseñas ingresadas no coinciden. Por favor verifica.'
    );
    return;
  }
  
  if (formData.contrasena.length < 6) {
    await AlertService.error(
      'Contraseña muy corta',
      'La contraseña debe tener al menos 6 caracteres'
    );
    return;
  }
    // Preparar datos para el backend según el tipo de usuario
    const userTypeConfig = userTypeMapping[formData.userType];
    
    // Payload EXACTO como espera el backend en RegisterRequest
    const payload = {
      nombre: formData.nombre.trim(),
      ape_pa: formData.ape_pa.trim(),
      ape_ma: formData.ape_ma?.trim() || null,
      curp: formData.curp.toUpperCase().trim(),
      fecha_nac: formData.fecha_nac,
      correo: formData.correo.toLowerCase().trim(), 
      contrasena: formData.contrasena, 
      userType: userTypeConfig.backendType
    };

    // Agregar campos específicos según tipo
  if (userTypeConfig.backendType === 'educativo') {
    payload.rol_id = userTypeConfig.rol_id;
    // Para educativos, también enviar información de escuela si existe
    if (formData.id_esc) {
      payload.id_esc = formData.id_esc;
    }
  } else if (userTypeConfig.backendType === 'administrativo') {
    payload.cargo = formData.cargo?.trim() || 'Personal Administrativo';
    // Para administrativos, también enviar información de escuela si existe
    if (formData.id_esc) {
      payload.id_esc = formData.id_esc;
    }
  } else if (userTypeConfig.backendType === 'tutor') {
    payload.ocupacion = formData.ocupacion?.trim() || 'No especificado';
  } else if (userTypeConfig.backendType === 'alumno') {
    // Para alumnos, necesitamos el tutor y la escuela
    payload.id_tutor = null;
    if (formData.grado) payload.grado = formData.grado;
    if (formData.grupo) payload.grupo = formData.grupo;
    if (formData.id_esc) {
      payload.id_esc = formData.id_esc;
      payload.ciclo_escolar = '2025-2026'; // Puedes hacer esto dinámico
    }
  }

  // Enviar también los datos adicionales de escuela si existen
  if (formData.id_esc) {
    payload.escuela_data = {
      id_esc: formData.id_esc,
      nombre: formData.escuelaNombre,
      clave_esc: formData.clave_esc,
      nivel_educativo: formData.nivel_educativo,
      turno: formData.turno,
      estado: formData.estado,
      municipio: formData.municipio
    };
  }
    console.log('Payload a enviar:', payload); // Para debug

    setIsLoading(true);

  try {
    // Mostrar alerta de carga ANTES de hacer el fetch
    AlertService.loading(
      'Registrando cuenta',
      'Estamos procesando tu información, por favor espera...'
    );
    
    const response = await fetch('http://localhost:8000/api/v1/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });


      const data = await response.json();
      AlertService.close();

    if (response.ok) {
      await AlertService.success(
        '¡Registro Exitoso!',
        'Tu cuenta ha sido creada exitosamente. Al dar clic en aceptar sera redirigido al login para que inicie sesion por primera vez.',
        'Aceptar'
      ).then((result) => {
        if (result.isConfirmed) {
          window.location.href = '/login';
        }
      });
      
      setTimeout(() => {
        window.location.href = '/login';
      }, 5000);
    } else {
      await AlertService.error(
        'Error en el Registro',
        data.detail || `Error ${response.status}: ${response.statusText}`
      );
    }
  } catch (error) {
    AlertService.close();
    console.error('Error completo:', error);
    await AlertService.error(
      'Error de Conexión',
      'No se pudo conectar con el servidor. Verifica tu conexión a internet y que el backend esté ejecutándose.'
    );
  } finally {
    setIsLoading(false);
  }
};
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Si cambia el CCT, buscar escuela automáticamente
    if (name === 'cct' && value.length >= 10) {
      searchSchool(value);
    }
  };

const searchSchool = async (cct) => {
  if (cct.length < 10) return;
  
  setIsSearchingSchool(true);
  
  try {
    // Cambiar esta parte para buscar en la API del backend
    const response = await fetch(`http://localhost:8000/api/v1/schools/search?cct=${cct}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    if (response.ok) {
      const data = await response.json();
      
      if (data.success && data.escuela) {
        const escuela = data.escuela;
        setFormData(prev => ({
          ...prev,
          escuelaNombre: escuela.nombre,
          municipio: escuela.municipio,
          estado: escuela.estado,
          id_esc: escuela.id_esc, // Guardar el ID de la escuela
          clave_esc: escuela.clave_esc, // Guardar clave
          nivel_educativo: escuela.nivel_educativo,
          turno: escuela.turno
        }));
await AlertService.success(
            'Escuela Encontrada',
            `Se ha encontrado la escuela: ${escuela.nombre}`
          );
        } else {
          await AlertService.error(
            'Escuela no encontrada',
            data.message || 'No se encontró una escuela con ese CCT. Verifica el código e intenta nuevamente.'
          );
        }
      } else {
        await AlertService.error(
          'Error en la búsqueda',
          'No se pudo buscar la escuela en este momento. Intenta nuevamente más tarde.'
        );
      }
    } catch (error) {
      console.error('Error buscando escuela:', error);
      await AlertService.error(
        'Error de conexión',
        'No se pudo conectar con el servidor para buscar la escuela.'
      );
    } finally {
      setIsSearchingSchool(false);
    }
  };

  const handleUserTypeSelect = (type) => {
    const config = userTypeMapping[type];
    setFormData({
      ...formData,
      userType: type,
      rol_id: config.rol_id || null,
      // Limpiar campos específicos al cambiar tipo
      cargo: type === 'administrativo' ? formData.cargo : '',
      ocupacion: type === 'padre' ? formData.ocupacion : '',
      grado: type === 'estudiante' ? formData.grado : '',
      grupo: type === 'estudiante' ? formData.grupo : ''
    });
  };

const nextStep = async () => {
  // Validaciones antes de avanzar
  if (currentStep === 1) {
    if (!formData.userType) {
      await AlertService.error('Selección requerida', 'Selecciona un tipo de usuario para continuar');
      return;
    }
  } else if (currentStep === 2) {
    const requiredFields = ['nombre', 'ape_pa', 'curp', 'fecha_nac', 'correo'];
    const missingFields = requiredFields.filter(field => !formData[field]);
    if (missingFields.length > 0) {
      await AlertService.error(
        'Campos requeridos',
        'Completa todos los campos marcados con asterisco (*) para continuar'
      );
      return;
    }
    
    if (formData.curp.length !== 18) {
      await AlertService.error('CURP inválida', 'La CURP debe tener exactamente 18 caracteres');
      return;
    }
    
    if (formData.userType === 'administrativo' && !formData.cargo) {
      await AlertService.error('Cargo requerido', 'El cargo es requerido para personal administrativo');
      return;
    }
    
    // Validación básica de correo
    const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!correoRegex.test(formData.correo)) {
      await AlertService.error('Correo inválido', 'Ingresa un correo electrónico válido');
      return;
    }
  } else if (currentStep === 3) {
    // Para algunos tipos de usuario, la escuela es importante
    const tiposRequierenEscuela = ['docente', 'director', 'administrativo', 'estudiante'];
    if (tiposRequierenEscuela.includes(formData.userType)) {
      if (!formData.cct) {
        await AlertService.error('CCT requerido', 'El CCT es requerido para este tipo de usuario');
        return;
      }
      
      if (formData.cct.length < 10) {
        await AlertService.error('CCT inválido', 'El CCT debe tener al menos 10 caracteres');
        return;
      }
    }
  } else if (currentStep === 4) {
    if (!formData.contrasena) {
      await AlertService.error('Contraseña requerida', 'La contraseña es requerida');
      return;
    }
    
    if (formData.contrasena.length < 6) {
      await AlertService.error('Contraseña muy corta', 'La contraseña debe tener al menos 6 caracteres');
      return;
    }
    
    if (formData.contrasena !== formData.confirmcontrasena) {
      await AlertService.error('Contraseñas no coinciden', 'Las contraseñas ingresadas no coinciden');
      return;
    }
    
    if (!formData.aceptaTerminos) {
      await AlertService.error('Términos requeridos', 'Debes aceptar los términos y condiciones');
      return;
    }
  }
  
  setCurrentStep(currentStep + 1);
};

  const prevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const getIconForUserType = (type) => {
    const icons = {
      docente: docenteIcon,
      estudiante: estudianteIcon,
      padre: tutorIcon,
      director: directorIcon,
      administrativo: administrativoIcon
    };
    return icons[type] || docenteIcon;
  };

  const renderStep1 = () => (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <h3 className="text-xl font-patria font-bold text-white mb-2">
          Selecciona tu Cargo
        </h3>
        <p className="text-twine-200 font-patria text-sm">
          Elige cómo participarás en el sistema SIVOD
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {Object.keys(userTypeMapping).map((type) => {
          const config = userTypeMapping[type];
          const isSelected = formData.userType === type;
          const icon = getIconForUserType(type);
          
          return (
            <div
              key={type}
              onClick={() => handleUserTypeSelect(type)}
              className={`p-3 border-2 rounded-xl cursor-pointer transition-all duration-300 transform hover:scale-105 backdrop-blur-sm ${
                isSelected 
                  ? 'border-twine-400 bg-twine-500/20 shadow-lg' 
                  : 'border-white/20 bg-white/5 hover:border-white/30 hover:shadow-md'
              }`}
            >
              <div className="flex items-center space-x-4">
                <img src={icon} alt={config.title} className="w-10 h-10 rounded-lg filter brightness-0 invert contrast-150 drop-shadow-md" />
                <div>
                  <h4 className="font-bold text-white font-patria text-lg">{config.title}</h4>
                  <p className="text-xs text-twine-200 mt-1 font-patria leading-tight">
                    {type === 'docente' && 'Personal educativo que imparte clases'}
                    {type === 'estudiante' && 'Alumno de educación básica o media superior'}
                    {type === 'padre' && 'Padres o Representante del estudiante'}
                    {type === 'director' && 'Personal directivo de la institución educativa'}
                    {type === 'administrativo' && 'Personal administrativo de la institución educativa'}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex justify-end pt-4">
        <button
          type="button"
          onClick={nextStep}
          className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-lg hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg font-patria text-sm w-full sm:w-auto"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            {isLoading ? 'Procesando...' : 'Continuar'}
            {!isLoading && <div className="w-3 h-3 border-r-2 border-b-2 border-white transform -rotate-45"></div>}
          </div>
        </button>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <h3 className="text-xl font-patria font-bold text-white mb-2">
          Información Personal
        </h3>
        <p className="text-twine-200 font-patria text-sm">
          Completa tus datos básicos de identificación
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Nombre(s)*</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
            placeholder="Tu nombre"
            required
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Apellido Paterno*</label>
          <input
            type="text"
            name="ape_pa"
            value={formData.ape_pa}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
            placeholder="Apellido paterno"
            required
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Apellido Materno</label>
          <input
            type="text"
            name="ape_ma"
            value={formData.ape_ma}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
            placeholder="Apellido materno"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">CURP*</label>
          <input
            type="text"
            name="curp"
            value={formData.curp}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm uppercase"
            placeholder="Ej: GOMA920531HDFRNN01"
            maxLength="18"
            required
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Fecha de Nacimiento*</label>
          <input
            type="date"
            name="fecha_nac"
            value={formData.fecha_nac}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
            required
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Correo Electrónico*</label>
          <input
            type="correo"
            name="correo"
            value={formData.correo}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
            placeholder="usuario@correo.com"
            required
            disabled={isLoading}
          />
        </div>

        {formData.userType === 'administrativo' && (
          <div className="space-y-2 md:col-span-2">
            <label className="block text-sm font-semibold text-white font-patria">Cargo*</label>
            <input
              type="text"
              name="cargo"
              value={formData.cargo}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
              placeholder="Ej: Secretaria, Conserje, etc."
              required
              disabled={isLoading}
            />
          </div>
        )}

        {formData.userType === 'padre' && (
          <div className="space-y-2 md:col-span-2">
            <label className="block text-sm font-semibold text-white font-patria">Ocupación</label>
            <input
              type="text"
              name="ocupacion"
              value={formData.ocupacion}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm"
              placeholder="Ej: Comerciante, Empleado, Profesionista, etc."
              disabled={isLoading}
            />
          </div>
        )}

        {formData.userType === 'estudiante' && (
          <>
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-white font-patria">Grado</label>
              <select
                name="grado"
                value={formData.grado}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-twine-400 font-patria text-sm"
                disabled={isLoading}
              >
                <option value="">Selecciona un grado</option>
                <option value="1ro">1°</option>
                <option value="2do">2°</option>
                <option value="3ro">3°</option>
                <option value="4to">4°</option>
                <option value="5to">5°</option>
                <option value="6to">6°</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-white font-patria">Grupo</label>
              <input
                type="text"
                name="grupo"
                value={formData.grupo}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm uppercase"
                placeholder="Ej: A, B, C"
                maxLength="1"
                disabled={isLoading}
              />
            </div>
          </>
        )}
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-3 pt-4">
        <button
          type="button"
          onClick={prevStep}
          className="px-4 py-2 border-2 border-white/30 text-white font-semibold rounded-lg hover:border-white/40 hover:bg-white/10 transition-all duration-300 font-patria text-sm order-2 sm:order-1"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45"></div>
            Anterior
          </div>
        </button>
        <button
          type="button"
          onClick={nextStep}
          className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-lg hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg font-patria text-sm order-1 sm:order-2"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            {isLoading ? 'Procesando...' : 'Continuar'}
            {!isLoading && <div className="w-3 h-3 border-r-2 border-b-2 border-white transform -rotate-45"></div>}
          </div>
        </button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <h3 className="text-xl font-patria font-bold text-white mb-2">
          Busca tu Escuela
        </h3>
        <p className="text-twine-200 font-patria text-sm">
          Ingresa los datos de tu institución educativa
        </p>
      </div>
      
      <div className="space-y-3">
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">
            CCT (Clave de Centro de Trabajo)
            {['docente', 'director', 'administrativo', 'estudiante'].includes(formData.userType) && ' *'}
          </label>
          <div className="relative">
            <input
              type="text"
              name="cct"
              value={formData.cct}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm uppercase"
              placeholder="Ej: 09DPR1234Z"
              maxLength="10"
              disabled={isLoading || isSearchingSchool}
              required={['docente', 'director', 'administrativo', 'estudiante'].includes(formData.userType)}
            />
            {isSearchingSchool && (
              <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
          </div>
        </div>

        {formData.escuelaNombre && (
          <div className="bg-gradient-to-r from-twine-500/10 to-twine-600/10 backdrop-blur-sm rounded-lg p-4 border border-twine-400/30">
            <div className="flex items-start space-x-3">
              <div className="w-12 h-12 bg-twine-500/20 rounded-xl flex items-center justify-center border-2 border-twine-400/30 shadow-xl flex-shrink-0">
                <img src={escuela} alt="Escuela" className="w-8 h-8 filter brightness-0 invert contrast-200 drop-shadow-lg" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold text-white font-patria mb-1">Escuela encontrada</h4>
                <p className="text-white font-patria text-sm mb-2">{formData.escuelaNombre}</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-xs text-twine-200 font-patria">Estado</p>
                    <p className="text-white text-sm font-patria">{formData.estado}</p>
                  </div>
                  <div>
                    <p className="text-xs text-twine-200 font-patria">Municipio</p>
                    <p className="text-white text-sm font-patria">{formData.municipio}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {!formData.escuelaNombre && formData.cct && !isSearchingSchool && (
          <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10">
            <div className="flex items-start space-x-3">
              <div className="w-12 h-12 bg-night-900/90 rounded-xl flex items-center justify-center border-2 border-white/20 shadow-xl flex-shrink-0">
                <img src={escuela} alt="Escuela" className="w-8 h-8 filter brightness-0 invert contrast-200 drop-shadow-lg" />
              </div>
              <div>
                <p className="text-sm text-white font-medium font-patria">
                  Información de la Escuela
                </p>
                <p className="text-xs text-twine-200 mt-1 font-patria">
                  Al ingresar el CCT, el sistema validará automáticamente los datos de tu institución educativa.
                  Asegúrate de que la información sea correcta.
                </p>
              </div>
            </div>
          </div>
        )}

        {formData.userType === 'padre' && (
          <div className="bg-twine-500/10 backdrop-blur-sm rounded-lg p-3 border border-twine-400/20">
            <p className="text-xs text-twine-200 font-patria">
              <span className="font-semibold text-white">Nota:</span> Como tutor, no es obligatorio ingresar un CCT. 
              Puedes asociarte a una escuela más tarde cuando tu estudiante sea registrado.
            </p>
          </div>
        )}
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-3 pt-4">
        <button
          type="button"
          onClick={prevStep}
          className="px-4 py-2 border-2 border-white/30 text-white font-semibold rounded-lg hover:border-white/40 hover:bg-white/10 transition-all duration-300 font-patria text-sm order-2 sm:order-1"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45"></div>
            Anterior
          </div>
        </button>
        <button
          type="button"
          onClick={nextStep}
          className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-lg hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg font-patria text-sm order-1 sm:order-2"
          disabled={isLoading || isSearchingSchool}
        >
          <div className="flex items-center justify-center gap-2">
            {isLoading || isSearchingSchool ? 'Procesando...' : 'Continuar'}
            {!isLoading && !isSearchingSchool && <div className="w-3 h-3 border-r-2 border-b-2 border-white transform -rotate-45"></div>}
          </div>
        </button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <h3 className="text-xl font-patria font-bold text-white mb-2">
          Seguridad y Términos
        </h3>
        <p className="text-twine-200 font-patria text-sm">
          Crea tu contraseña y acepta los términos
        </p>
      </div>

      <div className="space-y-3">
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Contraseña*</label>
          <div className="relative">
            <input
              type="contrasena"
              name="contrasena"
              value={formData.contrasena}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm pl-10"
              placeholder="Mínimo 6 caracteres"
              required
              disabled={isLoading}
            />
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <img src={candadoIcon} alt="candado" className="w-4 h-4 filter brightness-0 invert opacity-80" />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white font-patria">Confirmar Contraseña*</label>
          <div className="relative">
            <input
              type="contrasena"
              name="confirmcontrasena"
              value={formData.confirmcontrasena}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-lg focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 text-white placeholder-twine-200 font-patria text-sm pl-10"
              placeholder="Repite tu contraseña"
              required
              disabled={isLoading}
            />
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <img src={candadoIcon} alt="candado" className="w-4 h-4 filter brightness-0 invert opacity-80" />
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10">
          <div className="flex items-start space-x-3">
            <input
              type="checkbox"
              name="aceptaTerminos"
              checked={formData.aceptaTerminos}
              onChange={handleChange}
              className="w-4 h-4 text-twine-400 border-white/30 rounded focus:ring-twine-400/30 bg-white/10 mt-0.5 flex-shrink-0"
              required
              disabled={isLoading}
            />
            <div>
              <p className="text-sm text-white font-medium font-patria">
                Acepto los términos y condiciones del servicio
              </p>
              <p className="text-xs text-twine-200 mt-1 font-patria">
                He leído y acepto la{' '}
                <a href="/privacy" className="text-twine-300 hover:text-white underline" target="_blank" rel="noopener noreferrer">
                  política de privacidad
                </a>{' '}
                y los{' '}
                <a href="/terms" className="text-twine-300 hover:text-white underline" target="_blank" rel="noopener noreferrer">
                  términos de servicio
                </a>{' '}
                de SIVOD.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-3 pt-4">
        <button
          type="button"
          onClick={prevStep}
          className="px-4 py-2 border-2 border-white/30 text-white font-semibold rounded-lg hover:border-white/40 hover:bg-white/10 transition-all duration-300 font-patria text-sm order-2 sm:order-1"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45"></div>
            Anterior
          </div>
        </button>
        <button
          type="button"
          onClick={nextStep}
          className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-lg hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg font-patria text-sm order-1 sm:order-2"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            {isLoading ? 'Procesando...' : 'Continuar'}
            {!isLoading && <div className="w-3 h-3 border-r-2 border-b-2 border-white transform -rotate-45"></div>}
          </div>
        </button>
      </div>
    </div>
  );

  const renderStep5 = () => (
  <div className="space-y-4">
    <div className="text-center mb-4">
      <h3 className="text-xl font-patria font-bold text-white mb-2">
        Resumen del Registro
      </h3>
      <p className="text-twine-200 font-patria text-sm">
        Revisa tus datos antes de completar el registro
      </p>
    </div>

    <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
      <div className="space-y-3">
        {/* Información del usuario */}
        <div className="flex items-center space-x-3 pb-3 border-b border-white/10">
          <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30">
            <img 
              src={getIconForUserType(formData.userType)} 
              alt="Tipo de usuario" 
              className="w-6 h-6 filter brightness-0 invert" 
            />
          </div>
          <div>
            <p className="text-sm text-twine-200 font-patria">Tipo de cuenta</p>
            <p className="text-white font-semibold font-patria">{userTypeMapping[formData.userType]?.title}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-twine-200 font-patria">Nombre completo</p>
            <p className="text-white font-patria">{formData.nombre} {formData.ape_pa} {formData.ape_ma || ''}</p>
          </div>
          <div>
            <p className="text-xs text-twine-200 font-patria">CURP</p>
            <p className="text-white font-patria">{formData.curp}</p>
          </div>
          <div>
            <p className="text-xs text-twine-200 font-patria">Fecha de nacimiento</p>
            <p className="text-white font-patria">{formData.fecha_nac}</p>
          </div>
          <div>
            <p className="text-xs text-twine-200 font-patria">Correo electrónico</p>
            <p className="text-white font-patria">{formData.correo}</p>
          </div>
          
          {formData.userType === 'administrativo' && formData.cargo && (
            <div>
              <p className="text-xs text-twine-200 font-patria">Cargo</p>
              <p className="text-white font-patria">{formData.cargo}</p>
            </div>
          )}
          
          {formData.userType === 'padre' && formData.ocupacion && (
            <div>
              <p className="text-xs text-twine-200 font-patria">Ocupación</p>
              <p className="text-white font-patria">{formData.ocupacion}</p>
            </div>
          )}
          
          {formData.userType === 'estudiante' && formData.grado && (
            <div>
              <p className="text-xs text-twine-200 font-patria">Grado</p>
              <p className="text-white font-patria">{formData.grado}</p>
            </div>
          )}
          
          {formData.userType === 'estudiante' && formData.grupo && (
            <div>
              <p className="text-xs text-twine-200 font-patria">Grupo</p>
              <p className="text-white font-patria">{formData.grupo}</p>
            </div>
          )}
        </div>

        {/* INFORMACIÓN DE LA ESCUELA (si existe) */}
        {formData.escuelaNombre && (
          <div className="mt-4 pt-3 border-t border-white/10">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30">
                <img src={escuela} alt="Escuela" className="w-6 h-6 filter brightness-0 invert" />
              </div>
              <div>
                <p className="text-sm text-twine-200 font-patria">Escuela asignada</p>
                <p className="text-white font-semibold font-patria">{formData.escuelaNombre}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-13">
              <div>
                <p className="text-xs text-twine-200 font-patria">CCT</p>
                <p className="text-white font-patria text-sm">{formData.cct}</p>
              </div>
              <div>
                <p className="text-xs text-twine-200 font-patria">Nivel educativo</p>
                <p className="text-white font-patria text-sm">{formData.nivel_educativo || 'No especificado'}</p>
              </div>
              <div>
                <p className="text-xs text-twine-200 font-patria">Turno</p>
                <p className="text-white font-patria text-sm">{formData.turno || 'No especificado'}</p>
              </div>
              <div>
                <p className="text-xs text-twine-200 font-patria">Ubicación</p>
                <p className="text-white font-patria text-sm">{formData.municipio}, {formData.estado}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>

      <div className="flex flex-col sm:flex-row justify-between gap-3 pt-4">
        <button
          type="button"
          onClick={prevStep}
          className="px-4 py-2 border-2 border-white/30 text-white font-semibold rounded-lg hover:border-white/40 hover:bg-white/10 transition-all duration-300 font-patria text-sm order-2 sm:order-1"
          disabled={isLoading}
        >
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45"></div>
            Anterior
          </div>
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-lg hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg flex items-center justify-center gap-2 font-patria text-sm order-1 sm:order-2"
          disabled={isLoading || !formData.aceptaTerminos}
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Procesando...
            </>
          ) : (
            <>
              <div className="w-9 h-9 bg-white/25 backdrop-blur-md rounded-full border border-white/50 flex items-center justify-center shadow-lg">
                <img src={notas} alt="Completar" className="w-6 h-6 filter brightness-0 invert drop-shadow-md" />
              </div>
              Completar Registro
            </>
          )}
        </button>
      </div>
    </div>
  );

  const getProgress = () => {
    return (currentStep / 5) * 100;
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl shadow-2xl border border-white/20 overflow-hidden transform transition-all duration-300 w-full max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-twine-400/90 to-twine-600/90 py-4 px-4 sm:px-6 text-center border-b border-white/20">
        <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
          <img src={acceso} alt="Acceso" className="w-8 h-8 filter brightness-0 invert" />
        </div>
        <h2 className="text-lg sm:text-xl font-patria font-bold text-white mb-1">
          Crear Cuenta en SIVOD
        </h2>
        <p className="text-white/90 font-patria text-xs sm:text-sm">
          Únete a la comunidad educativa mexicana
        </p>
      </div>

      {/* Barra de progreso */}
      <div className="bg-white/5 backdrop-blur-sm px-4 sm:px-6 py-3 border-b border-white/10">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs sm:text-sm font-medium text-white font-patria">Paso {currentStep} de 5</span>
          <span className="text-xs sm:text-sm text-twine-200 font-patria">{Math.round(getProgress())}%</span>
        </div>
        <div className="w-full bg-white/10 rounded-full h-1.5">
          <div 
            className="bg-gradient-to-r from-twine-400 to-twine-500 h-1.5 rounded-full transition-all duration-500"
            style={{ width: `${getProgress()}%` }}
          ></div>
        </div>
      </div>

      {/* Formulario */}
      <div className="p-4 sm:p-6">
        <form onSubmit={handleSubmit}>
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
          {currentStep === 5 && renderStep5()}
        </form>

        {/* Enlace a login */}
        <div className="text-center mt-4 pt-4 border-t border-white/10">
          <p className="text-twine-200 font-patria text-xs sm:text-sm">
            ¿Ya tienes una cuenta?{' '}
            <Link to="/login" className="text-white hover:text-twine-200 font-semibold transition-colors duration-300 font-patria">
              Inicia sesión aquí
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterForm;