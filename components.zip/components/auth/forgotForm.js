import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import emailIcon from '../../assets/icons/icon-white/icon05.ico';
import candado from '../../assets/icons/icon-white/candado.png';
import enviar from '../../assets/icons/icon-white/enviar.png';
import contrasena from '../../assets/icons/icon-white/contrasena.png';   // ← icono del header
import seguroIcon from '../../assets/icons/icon-white/icon12.ico';
import acceso from '../../assets/icons/icon-white/acceso.png';

export default function PasswordRecovery() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

const handleSubmit = async (e) => {
  e.preventDefault();
  
  if (!email) {
    alert('Por favor ingresa tu correo electrónico');
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert('Por favor ingresa un correo válido');
    return;
  }

  setIsLoading(true);

  try {
    const response = await fetch('http://localhost:8000/api/v1/request-password-reset', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || 'Error al enviar el correo');
    }

    // Mostrar mensaje de éxito (siempre mostrar el mismo mensaje por seguridad)
    setIsSubmitted(true);
    
  } catch (error) {
    alert('Hubo un error al procesar tu solicitud. Por favor, intenta nuevamente.');
    console.error('Error:', error);
  } finally {
    setIsLoading(false);
  }
};

  const handleBack = () => {
    setIsSubmitted(false);
    setEmail('');
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden transform transition-all duration-300 max-w-md w-full mx-auto">
          {/* Header */}
      <div className="bg-gradient-to-r from-twine-400/70 to-twine-600/90 py-4 px-6 text-center border-b border-white/20">
        <div className="w-16 h-16 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
          <img src={enviar} alt="Enviar" className="w-10 h-10 filter brightness-0 invert" />
        </div>
            <h2 className="text-xl font-bold text-white mb-1">
              ¡Código Enviado!
            </h2>
            <p className="text-white/90 text-sm">
              Revisa tu correo electrónico
            </p>
          </div>

          {/* Contenido */}
          <div className="p-6">
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-white/80 text-sm mb-2">
                  Hemos enviado un código de verificación a:
                </p>
                <p className="text-white font-semibold text-lg">
                  {email}
                </p>
              </div>

              {/* Información adicional */}
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 bg-gradient-to-r from-green-400 to-green-300 rounded-lg flex-shrink-0 mt-0.5"></div>
                  <div>
                    <p className="text-sm text-white font-medium">
                      Revisa tu correo
                    </p>
                    <p className="text-xs text-white/70">
                      El código puede tardar unos minutos en llegar. Verifica también tu carpeta de spam.
                    </p>
                  </div>
                </div>
              </div>

              {/* Botones */}
              <div className="space-y-3">
                <button
                  onClick={handleBack}
                  className="w-full py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white font-semibold rounded-xl hover:bg-white/20 transition-all duration-300 flex items-center justify-center gap-2 text-sm"
                >
                  <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45"></div>
                  Volver atrás
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden transform transition-all duration-300 max-w-md w-full mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-twine-400/70 to-twine-600/90 py-6 px-6 text-center border-b border-white/20">
          <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-3 border border-white/20">
            <div className="w-12 h-12 bg-night-900/80 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-white/10">
                <img 
                  src={contrasena} 
                  alt="Recuperar contraseña" 
                  className="w-10 h-10 filter brightness-0 invert contrast-150 drop-shadow-lg"
                />
              </div>
          </div>
          <h2 className="text-xl font-bold text-white mb-1">
            Recuperar Contraseña
          </h2>
          <p className="text-white/90 text-sm">
            Ingresa tu correo para enviarte un código
          </p>
        </div>

        {/* Formulario */}
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Campo de email */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-white">
                Correo Electrónico
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300 pl-12 text-white placeholder-white/50"
                  placeholder="usuario@sep.gob.mx"
                  required
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-4">
                  <img src={emailIcon} alt="Email" className="w-6 h-6 filter brightness-0 invert contrast-150 drop-shadow-md opacity-90" />
                </div>
              </div>
              <p className="text-xs text-white/70">
                Usa tu correo institucional registrado
              </p>
            </div>

            {/* Información adicional */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="flex items-start gap-3">
                <img src={seguroIcon} alt="Seguro" className="w-7 h-7 filter brightness-0 invert contrast-150 drop-shadow-md flex-shrink-0 mt-1" />
                <div>
                  <p className="text-sm text-white font-medium">
                    Seguridad
                  </p>
                  <p className="text-xs text-white/70">
                    Tu información está protegida. Código válido por 15 minutos.
                  </p>
                </div>
              </div>
            </div>

            {/* Botón de envío */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-xl hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-2 text-sm"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Enviando código...
                </>
              ) : (
                <>
                 <img src={enviar} alt="Enviar" className="w-5 h-5 filter brightness-0 invert contrast-150 drop-shadow-md" />
                  Enviar Código
                </>
              )}
            </button>

            {/* Enlaces adicionales */}
            <div className="text-center space-y-4 pt-4 border-t border-white/10">
              <div>
                <Link 
                  to="/login" 
                  className="text-white hover:text-twine-200 font-medium transition-colors duration-300 flex items-center justify-center gap-2 text-sm"
                >
                  <img src={candado} alt="Login" className="w-5 h-5 filter brightness-0 invert contrast-150 drop-shadow-md" />
                  Volver al Inicio de Sesión
                </Link>
              </div>
              <div>
                <Link 
                  to="/register" 
                  className="text-white/70 hover:text-white font-medium transition-colors duration-300 flex items-center justify-center gap-2 text-sm"
                >
                <img src={acceso} alt="Registro" className="w-5 h-5 filter brightness-0 invert contrast-150 drop-shadow-md" />
                  ¿No tienes cuenta? Regístrate ahora
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
