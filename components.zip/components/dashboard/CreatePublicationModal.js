import React, { useState, useEffect } from 'react';
import { 
  XMarkIcon, 
  PhotoIcon, 
  DocumentTextIcon, 
  TagIcon, 
  PlusCircleIcon, 
  PencilSquareIcon,
  ArrowUpTrayIcon,
  TrashIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';

const CreatePublicationModal = ({ isOpen, onClose, onSuccess, apiUrl = 'http://localhost:8000', editingPublication = null }) => {
  const [formData, setFormData] = useState({
    titulo: '',
    contenido: '',
    tipo_publicacion: 'general',
    imagen: null
  });
  const [previewImage, setPreviewImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [removeImage, setRemoveImage] = useState(false);

  // Inicializar datos si hay edición
  useEffect(() => {
    if (editingPublication) {
      setFormData({
        titulo: editingPublication.titulo || '',
        contenido: editingPublication.contenido || '',
        tipo_publicacion: editingPublication.tipo_publicacion || 'general',
        imagen: null
      });

      if (editingPublication.imagen_url) {
        setPreviewImage(`${apiUrl}${editingPublication.imagen_url}`);
      } else {
        setPreviewImage(null);
      }
    } else {
      // Resetear si no hay edición
      setFormData({
        titulo: '',
        contenido: '',
        tipo_publicacion: 'general',
        imagen: null
      });
      setPreviewImage(null);
    }
    setError('');
  }, [editingPublication, apiUrl]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validar tamaño (máximo 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError('La imagen no debe exceder los 5MB');
        return;
      }

      setFormData(prev => ({
        ...prev,
        imagen: file
      }));
      setRemoveImage(false);

      // Crear preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
      setError('');
    }
  };

  const handleRemoveImage = () => {
    setPreviewImage(null);
    setFormData(prev => ({ ...prev, imagen: null }));
    setRemoveImage(true);
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Validar campos requeridos
      if (!formData.titulo.trim()) {
        throw new Error('El título es requerido');
      }

      if (!formData.contenido.trim()) {
        throw new Error('El contenido es requerido');
      }

      const formDataToSend = new FormData();
      formDataToSend.append('titulo', formData.titulo);
      formDataToSend.append('contenido', formData.contenido);
      formDataToSend.append('tipo_publicacion', formData.tipo_publicacion);

      if (formData.imagen) {
        formDataToSend.append('imagen', formData.imagen);
      }
      if (removeImage) {
        formDataToSend.append('remove_image', 'true');
      }

      // Obtener token de autenticación
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');

      if (!token) {
        throw new Error('No estás autenticado. Por favor, inicia sesión nuevamente.');
      }

      let url, method;
      if (editingPublication) {
        // Editar publicación existente
        url = `${apiUrl}/api/v1/publications/${editingPublication.id}`;
        method = 'PUT';
      } else {
        // Crear nueva publicación
        url = `${apiUrl}/api/v1/publications`;
        method = 'POST';
      }

      const response = await fetch(url, {
        method: method,
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formDataToSend,
        mode: 'cors',
        credentials: 'omit'
      });

      if (!response.ok) {
        let errorMessage = `Error ${response.status}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorMessage;
        } catch (e) {
          // No se pudo parsear la respuesta como JSON
        }
        throw new Error(errorMessage);
      }

      const responseData = await response.json();

      // Reset form
      if (!editingPublication) {
        setFormData({
          titulo: '',
          contenido: '',
          tipo_publicacion: 'general',
          imagen: null
        });
        setPreviewImage(null);
      }

      // Llamar a onSuccess
      onSuccess(responseData);

    } catch (err) {
      // Mensajes de error más descriptivos
      if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
        setError('Error de conexión. Verifica que el servidor backend esté corriendo en ' + apiUrl);
      } else {
        setError(err.message || 'Error al procesar la publicación. Por favor, inténtalo de nuevo.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-night-900/95 to-night-800/95 backdrop-blur-md rounded-2xl border border-white/20 shadow-2xl overflow-hidden">
        
        {/* Header similar a InfoModal */}
        <div className="bg-gradient-to-r from-twine-600/80 to-twine-800/80 px-6 py-4 border-b border-white/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
                {editingPublication ? (
                  <PencilSquareIcon className="w-5 h-5 text-white" />
                ) : (
                  <PlusCircleIcon className="w-5 h-5 text-white" />
                )}
              </div>
              <div>
                <h3 className="text-xl font-patria font-bold text-white">
                  {editingPublication ? 'Editar Publicación' : 'Nueva Publicación'}
                </h3>
                <p className="text-white/80 text-sm font-patria">
                  {editingPublication ? 'Modifica los detalles de tu publicación' : 'Comparte contenido con la comunidad'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all duration-300"
              disabled={loading}
            >
              <XMarkIcon className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-6 p-4 bg-red-500/20 border border-red-400/30 rounded-xl flex items-start space-x-3">
              <div className="w-5 h-5 bg-red-500/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <XMarkIcon className="w-3 h-3 text-red-200" />
              </div>
              <p className="text-red-200 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-6">
            {/* Título */}
            <div>
              <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                <DocumentTextIcon className="w-4 h-4 text-twine-300" />
                <span>Título de la publicación *</span>
              </label>
              <input
                type="text"
                name="titulo"
                value={formData.titulo}
                onChange={handleChange}
                required
                maxLength={255}
                disabled={loading}
                className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-twine-400 transition-all duration-300 disabled:opacity-50"
                placeholder="Escribe un título atractivo..."
              />
              <p className="text-white/50 text-xs mt-1 font-patria flex items-center space-x-1">
                <span>Máximo 255 caracteres</span>
              </p>
            </div>

            {/* Contenido */}
            <div>
              <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                <DocumentTextIcon className="w-4 h-4 text-twine-300" />
                <span>Contenido *</span>
              </label>
              <textarea
                name="contenido"
                value={formData.contenido}
                onChange={handleChange}
                required
                rows={6}
                disabled={loading}
                className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-twine-400 transition-all duration-300 resize-none disabled:opacity-50"
                placeholder="Comparte información importante con la comunidad..."
              />
            </div>

            {/* Tipo de publicación */}
            <div>
              <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                <TagIcon className="w-4 h-4 text-twine-300" />
                <span>Tipo de publicación</span>
              </label>
              <select
                name="tipo_publicacion"
                value={formData.tipo_publicacion}
                onChange={handleChange}
                disabled={loading}
                className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-twine-400 transition-all duration-300 disabled:opacity-50 appearance-none cursor-pointer"
              >
                <option value="general" className="bg-night-800">📄 General</option>
                <option value="anuncio" className="bg-night-800">📢 Anuncio</option>
                <option value="evento" className="bg-night-800">🎉 Evento</option>
                <option value="logro" className="bg-night-800">🏆 Logro</option>
                <option value="importante" className="bg-night-800">⚠️ Importante</option>
              </select>
            </div>

            {/* Imagen */}
            <div>
              <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                <PhotoIcon className="w-4 h-4 text-twine-300" />
                <span>Imagen {!editingPublication && '(opcional)'}</span>
              </label>
              <div className="space-y-4">
                {previewImage && (
                  <div className="relative group">
                    <img
                      src={previewImage}
                      alt="Preview"
                      className="w-full h-48 object-cover rounded-xl border border-white/20 group-hover:border-twine-400 transition-all duration-300"
                    />
                    {!loading && (
                      <button
                        type="button"
                        onClick={handleRemoveImage}
    className="absolute top-2 right-2 bg-red-500/80 hover:bg-red-600 text-white p-1.5 rounded-full transition-all duration-300"
  >
                        <TrashIcon className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                <div className={`border-2 border-dashed border-white/20 rounded-xl p-6 text-center transition-all duration-300 ${loading ? 'opacity-50' : 'hover:border-twine-400 hover:bg-white/5'}`}>
                  <input
                    type="file"
                    id="imagen"
                    accept="image/*"
                    onChange={handleImageChange}
                    disabled={loading}
                    className="hidden"
                  />
                  <label 
                    htmlFor="imagen" 
                    className={`flex flex-col items-center justify-center cursor-pointer ${loading ? 'cursor-not-allowed' : ''}`}
                  >
                    <div className="w-12 h-12 bg-twine-500/20 rounded-xl flex items-center justify-center mx-auto mb-3 border border-twine-400/30 group-hover:border-twine-400 transition-all duration-300">
                      {previewImage ? (
                        <PhotoIcon className="w-5 h-5 text-twine-300" />
                      ) : (
                        <ArrowUpTrayIcon className="w-5 h-5 text-twine-300" />
                      )}
                    </div>
                    <p className="text-white font-patria mb-1">
                      {previewImage ? 'Cambiar imagen' : 'Subir imagen'}
                    </p>
                    <p className="text-white/60 text-sm">
                      PNG, JPG, GIF (Máx. 5MB)
                    </p>
                  </label>
                </div>

                {editingPublication && editingPublication.imagen_url && !previewImage && (
                  <div className="p-3 bg-twine-500/10 border border-twine-400/20 rounded-xl">
                    <p className="text-twine-300 text-sm flex items-center space-x-2">
                      <PhotoIcon className="w-4 h-4" />
                      <span>Imagen actual conservada. Sube una nueva si deseas cambiarla.</span>
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Consejo */}
            <div className="bg-twine-500/10 border border-twine-400/20 rounded-xl p-4">
              <h4 className="text-white font-patria font-semibold text-sm mb-2 flex items-center space-x-2">
                <span>💡</span>
                <span>Consejo para una buena publicación</span>
              </h4>
              <p className="text-twine-200 font-patria text-xs">
                Escribe contenido claro y conciso. Selecciona el tipo adecuado para tu publicación y añade una imagen relevante para hacerla más atractiva.
              </p>
            </div>
          </div>

          {/* Footer similar a InfoModal */}
          <div className="mt-8 pt-6 border-t border-white/10 flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-patria transition-all duration-300 border border-white/20 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <XMarkIcon className="w-4 h-4" />
              <span>Cancelar</span>
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-gradient-to-r from-twine-500/90 to-twine-600/90 hover:from-twine-600 hover:to-twine-700 text-white rounded-xl font-patria transition-all duration-300 border border-twine-400 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>{editingPublication ? 'Editando...' : 'Creando...'}</span>
                </>
              ) : (
                <>
                  {editingPublication ? (
                    <>
                      <PencilSquareIcon className="w-4 h-4" />
                      <span>Actualizar</span>
                    </>
                  ) : (
                    <>
                      <CheckCircleIcon className="w-4 h-4 group-hover:scale-110 transition-transform duration-300" />
                      <span>Publicar</span>
                    </>
                  )}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePublicationModal;