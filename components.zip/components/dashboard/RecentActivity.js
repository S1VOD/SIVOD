import React from 'react';

const RecentActivity = ({ userType, isModal = false, onClose }) => {
  const getActivitiesByUserType = () => {
    switch (userType) {
      case 'docente':
        return [
          { 
            action: 'Nueva evaluación recibida de estudiantes', 
            time: 'Hace 2 horas', 
            type: 'evaluation',
            status: 'new',
            details: '15 estudiantes han completado tu evaluación'
          },
          { 
            action: 'Postulación actualizada - Nivel Estatal', 
            time: 'Hace 1 día', 
            type: 'postulation',
            status: 'in-progress',
            details: 'Documentación en revisión'
          },
          { 
            action: 'Reconocimiento Municipal obtenido', 
            time: 'Hace 3 días', 
            type: 'recognition',
            status: 'completed',
            details: 'Felicidades por tu excelente trabajo'
          },
          { 
            action: 'Comentarios positivos recibidos', 
            time: 'Hace 4 días', 
            type: 'feedback',
            status: 'positive',
            details: '12 comentarios constructivos'
          }
        ];
      case 'estudiante':
        return [
          { 
            action: 'Evaluación completada - Matemáticas', 
            time: 'Hace 1 hora', 
            type: 'evaluation',
            status: 'completed',
            details: 'Prof. María González'
          },
          { 
            action: 'Nuevo docente asignado en tu grupo', 
            time: 'Hace 2 días', 
            type: 'assignment',
            status: 'new',
            details: 'Prof. Carlos Rodríguez - Ciencias'
          },
          { 
            action: 'Recordatorio de evaluación pendiente', 
            time: 'Hace 3 días', 
            type: 'reminder',
            status: 'pending',
            details: '3 docentes por evaluar'
          },
          { 
            action: 'Tus sugerencias fueron consideradas', 
            time: 'Hace 5 días', 
            type: 'suggestion',
            status: 'completed',
            details: 'Mejoras implementadas en el aula'
          }
        ];
      case 'padre':
        return [
          { 
            action: 'Evaluación de docente completada', 
            time: 'Hace 4 horas', 
            type: 'evaluation',
            status: 'completed',
            details: 'Prof. Ana Martínez - Español'
          },
          { 
            action: 'Sugerencia enviada al director', 
            time: 'Hace 1 día', 
            type: 'suggestion',
            status: 'in-progress',
            details: 'Mejora en infraestructura'
          },
          { 
            action: 'Notificación de reunión de padres', 
            time: 'Hace 2 días', 
            type: 'notification',
            status: 'new',
            details: 'Próximo viernes a las 16:00'
          }
        ];
      case 'director':
        return [
          { 
            action: 'Nuevas evaluaciones recibidas', 
            time: 'Hace 3 horas', 
            type: 'evaluation',
            status: 'new',
            details: '45 evaluaciones de padres y estudiantes'
          },
          { 
            action: 'Sugerencias pendientes de revisión', 
            time: 'Hace 1 día', 
            type: 'suggestion',
            status: 'pending',
            details: '8 sugerencias por revisar'
          },
          { 
            action: 'Reporte mensual generado', 
            time: 'Hace 2 días', 
            type: 'report',
            status: 'completed',
            details: 'Reporte de desempeño institucional'
          }
        ];
      case 'administrativo':
        return [
          { 
            action: 'Documentos procesados exitosamente', 
            time: 'Hace 2 horas', 
            type: 'document',
            status: 'completed',
            details: '15 documentos de matrícula'
          },
          { 
            action: 'Tareas administrativas pendientes', 
            time: 'Hace 1 día', 
            type: 'task',
            status: 'pending',
            details: '7 tareas por completar'
          },
          { 
            action: 'Reporte de asistencia generado', 
            time: 'Hace 3 días', 
            type: 'report',
            status: 'completed',
            details: 'Reporte semanal de asistencia'
          }
        ];
      case 'admin':
        return [
          { 
            action: 'Nuevos usuarios registrados', 
            time: 'Hace 1 hora', 
            type: 'user',
            status: 'new',
            details: '24 nuevos usuarios en el sistema'
          },
          { 
            action: 'Evaluaciones procesadas hoy', 
            time: 'Hace 3 horas', 
            type: 'evaluation',
            status: 'completed',
            details: '156 evaluaciones completadas'
          },
          { 
            action: 'Mantenimiento del sistema', 
            time: 'Hace 1 día', 
            type: 'system',
            status: 'completed',
            details: 'Actualización de seguridad aplicada'
          }
        ];
      default:
        return [];
    }
  };

  const getActivityConfig = (type, status) => {
    const configs = {
      evaluation: { 
        color: 'twine',
        variants: {
          new: { badge: 'Nuevo', badgeColor: 'bg-green-500/20 text-green-300' },
          completed: { badge: 'Completado', badgeColor: 'bg-blue-500/20 text-blue-300' }
        }
      },
      postulation: { 
        color: 'night',
        variants: {
          'in-progress': { badge: 'En Proceso', badgeColor: 'bg-yellow-500/20 text-yellow-300' }
        }
      },
      recognition: { 
        color: 'twine',
        variants: {
          completed: { badge: 'Logro', badgeColor: 'bg-purple-500/20 text-purple-300' }
        }
      },
      assignment: { 
        color: 'night',
        variants: {
          new: { badge: 'Nuevo', badgeColor: 'bg-green-500/20 text-green-300' }
        }
      },
      reminder: { 
        color: 'twine',
        variants: {
          pending: { badge: 'Pendiente', badgeColor: 'bg-orange-500/20 text-orange-300' }
        }
      },
      feedback: { 
        color: 'twine',
        variants: {
          positive: { badge: 'Positivo', badgeColor: 'bg-green-500/20 text-green-300' }
        }
      },
      suggestion: { 
        color: 'night',
        variants: {
          completed: { badge: 'Aplicado', badgeColor: 'bg-blue-500/20 text-blue-300' },
          'in-progress': { badge: 'En Revisión', badgeColor: 'bg-yellow-500/20 text-yellow-300' }
        }
      },
      notification: { 
        color: 'twine',
        variants: {
          new: { badge: 'Nuevo', badgeColor: 'bg-green-500/20 text-green-300' }
        }
      },
      report: { 
        color: 'night',
        variants: {
          completed: { badge: 'Generado', badgeColor: 'bg-blue-500/20 text-blue-300' }
        }
      },
      document: { 
        color: 'twine',
        variants: {
          completed: { badge: 'Procesado', badgeColor: 'bg-green-500/20 text-green-300' }
        }
      },
      task: { 
        color: 'night',
        variants: {
          pending: { badge: 'Pendiente', badgeColor: 'bg-orange-500/20 text-orange-300' }
        }
      },
      user: { 
        color: 'twine',
        variants: {
          new: { badge: 'Nuevo', badgeColor: 'bg-green-500/20 text-green-300' }
        }
      },
      system: { 
        color: 'night',
        variants: {
          completed: { badge: 'Completado', badgeColor: 'bg-blue-500/20 text-blue-300' }
        }
      }
    };

    const defaultConfig = { 
      color: 'twine',
      variants: {}
    };

    const config = configs[type] || defaultConfig;
    const variant = config.variants[status] || {};
    
    return { ...config, ...variant };
  };

  const getIcon = (color) => {
    return (
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
        color === 'twine' ? 'bg-twine-500/20 border-twine-400/30' : 'bg-night-500/20 border-night-400/30'
      } border`}>
        <div className={`w-4 h-4 rounded-lg ${
          color === 'twine' ? 'bg-twine-300' : 'bg-night-300'
        }`}></div>
      </div>
    );
  };

  const getTimeIcon = () => {
    return (
      <div className="w-3 h-3 bg-gradient-to-r from-twine-300 to-twine-400 rounded-sm"></div>
    );
  };

  const activities = getActivitiesByUserType();

  return (
    <div className={`bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden ${
      isModal ? 'w-full max-w-4xl max-h-[85vh] overflow-y-auto' : ''
    }`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-night-600/80 to-night-900/80 px-6 py-4 border-b border-white/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
              <div className="w-5 h-5 bg-gradient-to-r from-white to-twine-100 rounded-sm"></div>
            </div>
            <div>
              <h3 className="text-xl font-patria font-bold text-white">Actividad Reciente</h3>
              <p className="text-white/80 text-sm font-patria">Tu historial de actividades en SIVOD</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-white/60 font-patria">
              <span className="text-sm">{activities.length} actividades</span>
            </div>
            
            {/* Botón de cerrar para modal - MEJORADO */}
            {isModal && (
              <button
                onClick={onClose}
                className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center border border-white/20 hover:bg-white/20 hover:scale-105 transition-all duration-300 group"
                aria-label="Cerrar modal"
              >
                <div className="w-4 h-4 relative">
                  <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white transform -rotate-45 group-hover:bg-twine-200 transition-colors"></div>
                  <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white transform rotate-45 group-hover:bg-twine-200 transition-colors"></div>
                </div>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Lista de actividades */}
      <div className="divide-y divide-white/10 max-h-[400px] overflow-y-auto">
        {activities.map((activity, index) => {
          const config = getActivityConfig(activity.type, activity.status);
          
          return (
            <div 
              key={index}
              className="group relative p-4 transition-all duration-300 hover:bg-white/5"
            >
              <div className="flex items-start space-x-4">
                {/* Icono */}
                <div className="flex-shrink-0">
                  {getIcon(config.color)}
                </div>

                {/* Contenido */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-white font-semibold leading-tight font-patria">
                      {activity.action}
                    </p>
                    {config.badge && (
                      <span className={`text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap ml-2 font-patria ${config.badgeColor}`}>
                        {config.badge}
                      </span>
                    )}
                  </div>
                  
                  {activity.details && (
                    <p className="text-twine-200 text-sm mb-3 leading-tight font-patria">
                      {activity.details}
                    </p>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <span className="text-twine-300 text-xs flex items-center space-x-2 font-patria">
                      {getTimeIcon()}
                      <span>{activity.time}</span>
                    </span>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button className="text-white hover:text-twine-200 text-xs font-medium font-patria flex items-center space-x-1">
                        <span>Ver detalles</span>
                        <div className="w-3 h-3 border-r-2 border-b-2 border-current transform -rotate-45"></div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      {activities.length > 0 && (
        <div className="bg-white/5 border-t border-white/10 px-6 py-4">
          <div className="text-center">
            <button className="text-white hover:text-twine-200 font-medium text-sm transition-colors duration-300 flex items-center justify-center space-x-2 mx-auto font-patria">
              <span>Ver todo el historial</span>
              <div className="w-3 h-3 border-r-2 border-b-2 border-current transform -rotate-45"></div>
            </button>
          </div>
        </div>
      )}

      {/* Estado vacío */}
      {activities.length === 0 && (
        <div className="p-8 text-center">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
            <div className="w-6 h-6 bg-gradient-to-r from-twine-400 to-twine-600 rounded-lg"></div>
          </div>
          <p className="text-twine-200 font-medium font-patria">No hay actividad reciente</p>
          <p className="text-twine-300 text-sm mt-1 font-patria">Las actividades aparecerán aquí</p>
        </div>
      )}
    </div>
  );
};

export default RecentActivity;