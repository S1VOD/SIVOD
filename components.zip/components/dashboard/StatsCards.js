import React from 'react';

const StatsCards = ({ userType }) => {
  const getStatsByUserType = () => {
    switch (userType) {
      case 'educativo': // Cambiado de 'docente' a 'educativo'
        return [
          { 
            title: 'Evaluaciones Recibidas', 
            value: '24', 
            color: 'twine',
            trend: '+12%',
            description: 'Este mes'
          },
          { 
            title: 'Puntuación Promedio', 
            value: '4.8', 
            suffix: '/5',
            color: 'twine',
            trend: '+0.2',
            description: 'Excelente'
          },
          { 
            title: 'Postulaciones Activas', 
            value: '2', 
            color: 'night',
            trend: 'Activas',
            description: 'En proceso'
          },
          { 
            title: 'Reconocimientos', 
            value: '3', 
            color: 'night',
            trend: '+1',
            description: 'Este año'
          }
        ];
      case 'alumno': // Cambiado de 'estudiante' a 'alumno'
        return [
          { 
            title: 'Evaluaciones Pendientes', 
            value: '5', 
            color: 'twine',
            trend: 'Por completar',
            description: 'Urgente'
          },
          { 
            title: 'Evaluaciones Completadas', 
            value: '12', 
            color: 'twine',
            trend: '+3',
            description: 'Este semestre'
          },
          { 
            title: 'Docentes por Evaluar', 
            value: '3', 
            color: 'night',
            trend: 'Pendientes',
            description: 'Asignados'
          },
          { 
            title: 'Calificaciones', 
            value: '8.5', 
            suffix: '/10',
            color: 'night',
            trend: '+0.5',
            description: 'Promedio actual'
          }
        ];
      case 'tutor': // Cambiado de 'padre' a 'tutor'
        return [
          { 
            title: 'Evaluaciones Pendientes', 
            value: '2', 
            color: 'twine',
            trend: 'Por completar',
            description: 'Este mes'
          },
          { 
            title: 'Sugerencias Enviadas', 
            value: '5', 
            color: 'twine',
            trend: '+2',
            description: 'Total'
          },
          { 
            title: 'Sugerencias Resueltas', 
            value: '3', 
            color: 'night',
            trend: '60%',
            description: 'Tasa de resolución'
          },
          { 
            title: 'Alumnos a Cargo', 
            value: '2', 
            color: 'night',
            trend: 'Activos',
            description: 'Tus dependientes'
          }
        ];
      case 'director': // Director es un tipo de educativo
        return [
          { 
            title: 'Evaluaciones Totales', 
            value: '156', 
            color: 'twine',
            trend: '+24',
            description: 'Este mes'
          },
          { 
            title: 'Sugerencias Pendientes', 
            value: '8', 
            color: 'twine',
            trend: 'Por revisar',
            description: 'En espera'
          },
          { 
            title: 'Reportes Generados', 
            value: '12', 
            color: 'night',
            trend: '+3',
            description: 'Este trimestre'
          },
          { 
            title: 'Personal Activo', 
            value: '28', 
            color: 'night',
            trend: '+2',
            description: 'En la institución'
          }
        ];
      case 'administrativo':
        return [
          { 
            title: 'Documentos Procesados', 
            value: '45', 
            color: 'twine',
            trend: '+15',
            description: 'Esta semana'
          },
          { 
            title: 'Tareas Pendientes', 
            value: '7', 
            color: 'twine',
            trend: 'Por completar',
            description: 'Prioridad alta'
          },
          { 
            title: 'Reportes Entregados', 
            value: '18', 
            color: 'night',
            trend: '+5',
            description: 'Este mes'
          },
          { 
            title: 'Usuarios Atendidos', 
            value: '32', 
            color: 'night',
            trend: '+8',
            description: 'Hoy'
          }
        ];
      case 'admin':
        return [
          { 
            title: 'Usuarios Activos', 
            value: '2,458', 
            color: 'twine',
            trend: '+156',
            description: 'En línea ahora'
          },
          { 
            title: 'Evaluaciones Hoy', 
            value: '342', 
            color: 'twine',
            trend: '+42',
            description: 'Completadas'
          },
          { 
            title: 'Sistema', 
            value: '100%', 
            color: 'night',
            trend: 'Estable',
            description: 'Disponibilidad'
          },
          { 
            title: 'Incidentes', 
            value: '0', 
            color: 'night',
            trend: 'Resueltos',
            description: 'Últimas 24h'
          }
        ];
      default:
        return [
          { 
            title: 'Actividad', 
            value: '0', 
            color: 'twine',
            trend: 'Nueva',
            description: 'Recién registrado'
          },
          { 
            title: 'Estado', 
            value: 'Activo', 
            color: 'twine',
            trend: 'Verificado',
            description: 'Cuenta activa'
          },
          { 
            title: 'Membresía', 
            value: 'Básica', 
            color: 'night',
            trend: 'Gratuita',
            description: 'Plan actual'
          },
          { 
            title: 'Soporte', 
            value: '24/7', 
            color: 'night',
            trend: 'Disponible',
            description: 'Asistencia'
          }
        ];
    }
  };

  // Resto del código se mantiene igual...
  const getGradient = (color) => {
    const gradients = {
      twine: 'from-twine-500/90 to-twine-600/90',
      night: 'from-night-500/90 to-night-600/90'
    };
    return gradients[color] || 'from-gray-500/90 to-gray-600/90';
  };

  const getIcon = (color) => {
    return (
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
        color === 'twine' ? 'bg-twine-400/20' : 'bg-night-400/20'
      } border ${
        color === 'twine' ? 'border-twine-400/30' : 'border-night-400/30'
      }`}>
        <div className={`w-4 h-4 rounded-lg ${
          color === 'twine' ? 'bg-twine-300' : 'bg-night-300'
        }`}></div>
      </div>
    );
  };

  const stats = getStatsByUserType();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div 
          key={index} 
          className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 transition-all duration-300 hover:border-white/30"
        >
          {/* Header con icono y tendencia */}
          <div className="flex items-center justify-between mb-4">
            {getIcon(stat.color)}
            <div className="text-right">
              <span className={`text-sm px-3 py-1 rounded-full font-medium font-patria ${
                stat.color === 'twine' 
                  ? 'bg-twine-500/20 text-twine-300' 
                  : 'bg-night-500/20 text-night-300'
              }`}>
                {stat.trend}
              </span>
            </div>
          </div>

          {/* Valor principal */}
          <div className="mb-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold font-patria text-white">{stat.value}</span>
              {stat.suffix && (
                <span className="text-lg text-twine-200 font-patria">{stat.suffix}</span>
              )}
            </div>
          </div>

          {/* Título y descripción */}
          <div>
            <h3 className="text-lg font-semibold font-patria text-white mb-2 leading-tight">
              {stat.title}
            </h3>
            <p className="text-sm text-twine-200 font-patria leading-tight">
              {stat.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatsCards;