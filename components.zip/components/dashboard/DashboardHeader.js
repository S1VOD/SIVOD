// DashboardHeader.js - versión responsiva
import React, { useState, useEffect } from 'react';
import InfoModal from '../common/InfoModal'; 
// Importaciones de Heroicons
import {
  InformationCircleIcon,
  CalendarIcon,
  UserCircleIcon,
  ClockIcon,
  CheckCircleIcon,
  ArrowRightIcon,
  AcademicCapIcon,
  BriefcaseIcon,
  UserGroupIcon,
  UserIcon,
  SparklesIcon,
  SunIcon,
  MoonIcon,
  ComputerDesktopIcon,
  Bars3Icon,
  XMarkIcon
} from '@heroicons/react/24/solid';

const DashboardHeader = ({ userProfile, userType, onShowActivities }) => {
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [greeting, setGreeting] = useState('');
  const [timeOfDay, setTimeOfDay] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const updateGreeting = () => {
      const hour = new Date().getHours();
      if (hour < 12) {
        setGreeting('¡Buenos días!');
        setTimeOfDay('mañana');
      } else if (hour < 19) {
        setGreeting('¡Buenas tardes!');
        setTimeOfDay('tarde');
      } else {
        setGreeting('¡Buenas noches!');
        setTimeOfDay('noche');
      }
    };

    updateGreeting();
    const interval = setInterval(updateGreeting, 3600000);
    return () => clearInterval(interval);
  }, []);

  // Configuración basada en el tipo de usuario real
  const getUserTypeConfig = () => {
    const configs = {
      educativo: {
        name: 'Educativo',
        description: 'Profesional de la educación',
        badge: 'Educador',
        welcome: 'Gracias por su dedicación a la educación',
        icon: AcademicCapIcon
      },
      administrativo: {
        name: 'Administrativo',
        description: 'Soporte educativo',
        badge: 'Administración',
        welcome: 'Contribuyendo al sistema educativo',
        icon: BriefcaseIcon
      },
      tutor: {
        name: 'Tutor',
        description: 'Acompañamiento educativo',
        badge: 'Tutoría',
        welcome: 'Apoyando el desarrollo educativo',
        icon: UserGroupIcon
      },
      alumno: {
        name: 'Alumno',
        description: 'Futuro de nuestra nación',
        badge: 'Estudiante',
        welcome: 'Sigue construyendo tu futuro',
        icon: UserIcon
      }
    };

    return configs[userType] || configs.educativo;
  };

  const getDashboardInfo = () => {
    const info = {
      educativo: {
        title: 'Panel del Educativo',
        description: 'En esta ventana encontrarás todas las herramientas necesarias para tu desarrollo profesional y la interacción con la comunidad educativa.',
        features: [
          'Revisa tus estadísticas de desempeño y evaluaciones',
          'Accede rápidamente a las funciones más utilizadas',
          'Mantente informado con las actividades de la comunidad',
          'Consulta tu historial de actividades recientes',
          'Participa en encuestas y publicaciones educativas'
        ]
      },
      administrativo: {
        title: 'Panel Administrativo',
        description: 'Herramientas para la gestión operativa y apoyo a la comunidad educativa.',
        features: [
          'Gestiona procesos administrativos',
          'Da seguimiento a trámites y documentación',
          'Participa en la comunidad educativa',
          'Consulta estadísticas operativas',
          'Coordina con otros miembros del personal'
        ]
      },
      tutor: {
        title: 'Panel del Tutor',
        description: 'Espacio dedicado para el seguimiento educativo y participación en la comunidad.',
        features: [
          'Monitorea el progreso académico',
          'Evalúa el desempeño educativo',
          'Participa en encuestas y decisiones escolares',
          'Mantente informado sobre eventos y reuniones',
          'Consulta el historial de tu participación'
        ]
      },
      alumno: {
        title: 'Panel del Alumno',
        description: 'Tu centro de control para el seguimiento académico y participación en la comunidad educativa.',
        features: [
          'Consulta tu progreso y calificaciones',
          'Evalúa a tus educativos y participa en encuestas',
          'Interactúa con publicaciones de la comunidad',
          'Revisa tu historial de actividades',
          'Mantente informado sobre eventos escolares'
        ]
      }
    };

    return info[userType] || info.educativo;
  };

  const userConfig = getUserTypeConfig();
  const dashboardInfo = getDashboardInfo();
  const UserIconComponent = userConfig.icon;

  return (
    <>
      <div className="bg-white/10 backdrop-blur-md rounded-xl lg:rounded-2xl shadow-lg lg:shadow-2xl border border-white/20 overflow-hidden">
        <div className="p-4 lg:p-6 xl:p-8">
          {/* Mobile Header - Solo visible en móviles */}
          <div className="lg:hidden mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-br from-twine-400 to-twine-600 rounded-xl flex items-center justify-center border-2 border-white/20">
                    {userProfile && userProfile.foto_url ? (
                      <img 
                        src={userProfile.foto_url}
                        alt={`Foto de ${userProfile.nombre_completo}`}
                        className="w-full h-full rounded-xl object-cover"
                        onError={(e) => {
                          e.target.src = 'http://localhost:8000/uploads/photos/Fotoperfil.jpg';
                        }}
                      />
                    ) : (
                      <UserCircleIcon className="w-6 h-6 text-white opacity-80" />
                    )}
                  </div>
                  <button
                    onClick={() => setShowInfoModal(true)}
                    className="absolute -top-1 -right-1 w-6 h-6 bg-twine-500 rounded-full flex items-center justify-center border border-white/20 hover:bg-twine-600 transition-all duration-300"
                    aria-label="Información del dashboard"
                  >
                    <InformationCircleIcon className="w-3 h-3 text-white" />
                  </button>
                </div>
                <div>
                  <h1 className="text-lg font-patria font-bold text-white truncate max-w-[150px]">
                    {greeting}
                  </h1>
                  <p className="text-xs text-twine-200 truncate max-w-[150px]">
                    {userProfile?.nombre || 'Usuario'}
                  </p>
                </div>
              </div>
              
              {/* Botón menú móvil */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center border border-white/20"
                aria-label="Menú"
              >
                {isMobileMenuOpen ? (
                  <XMarkIcon className="w-5 h-5 text-white" />
                ) : (
                  <Bars3Icon className="w-5 h-5 text-white" />
                )}
              </button>
            </div>
          </div>

          {/* Contenido principal */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            {/* Información del usuario - Desktop */}
            <div className="flex-1 hidden lg:block">
              <div className="flex items-center space-x-6">
                <div className="relative">
                  <div className="w-24 h-24 lg:w-32 lg:h-32 bg-gradient-to-br from-twine-400 to-twine-600 rounded-2xl flex items-center justify-center border-4 border-white/20">
                    {userProfile && userProfile.foto_url ? (
                      <img 
                        src={userProfile.foto_url}
                        alt={`Foto de ${userProfile.nombre_completo}`}
                        className="w-full h-full rounded-2xl object-cover"
                        onError={(e) => {
                          e.target.src = 'http://localhost:8000/uploads/photos/Fotoperfil.jpg';
                        }}
                      />
                    ) : (
                      <UserCircleIcon className="w-10 h-10 lg:w-16 lg:h-16 text-white opacity-80" />
                    )}
                  </div>
                  <button
                    onClick={() => setShowInfoModal(true)}
                    className="absolute -top-1 -right-1 w-7 h-7 lg:w-8 lg:h-8 bg-twine-500 rounded-full flex items-center justify-center border border-white/20 hover:bg-twine-600 transition-all duration-300 group hover:scale-110"
                    aria-label="Información del dashboard"
                  >
                    <InformationCircleIcon className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
                  </button>
                </div>

                <div className="flex-1">
                  <div className="flex flex-col lg:flex-row lg:items-center space-y-2 lg:space-y-0 lg:space-x-4 mb-3">
                    <h1 className="text-2xl lg:text-3xl xl:text-4xl font-patria font-bold text-white">
                      {greeting}
                    </h1>
                    <span className="bg-white/20 backdrop-blur-sm px-3 py-1.5 lg:px-4 lg:py-2 rounded-full text-xs lg:text-sm font-medium text-white border border-white/30 flex items-center w-fit">
                      <UserIconComponent className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                      {userProfile?.role || userConfig.badge}
                    </span>
                  </div>
                  
                  <p className="text-base lg:text-xl text-twine-200 font-patria mb-2 lg:mb-3">
                    {userConfig.welcome}, <span className="text-white font-semibold">{userProfile?.nombre || 'Usuario'}</span>
                  </p>
                  
                  <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-6 text-twine-200 font-patria">
                    <div className="flex items-center space-x-2">
                      <SparklesIcon className="w-3 h-3 lg:w-4 lg:h-4 text-twine-300" />
                      <span className="text-sm lg:text-base">Rol: <strong className="text-white">{userProfile?.role || userConfig.name}</strong></span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CalendarIcon className="w-3 h-3 lg:w-4 lg:h-4 text-white" />
                      <span className="text-sm lg:text-base">
                        {new Date().toLocaleDateString('es-MX', { 
                          weekday: 'short', 
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Panel derecho - Desktop */}
            <div className="hidden lg:block mt-0 lg:mt-0 lg:pl-8">
              <div className="flex flex-col space-y-4 min-w-[250px]">
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                  <div className="flex items-center justify-center mb-2">
                    <ComputerDesktopIcon className="w-5 h-5 lg:w-6 lg:h-6 text-white mr-2" />
                    <div className="text-lg lg:text-xl font-bold font-patria text-white text-center">
                      SIVOD
                    </div>
                  </div>
                  <div className="text-xs lg:text-sm text-twine-200 font-patria text-center">
                    Sistema Integral de
                  </div>
                  <div className="text-xs lg:text-sm text-twine-200 font-patria text-center">
                    Votación y Opinión Docente
                  </div>
                  <div className="w-full h-0.5 bg-white/20 rounded-full mt-2"></div>
                  <div className="flex items-center justify-center mt-2">
                    {timeOfDay === 'mañana' ? (
                      <SunIcon className="w-3 h-3 lg:w-4 lg:h-4 text-yellow-300 mr-1" />
                    ) : timeOfDay === 'tarde' ? (
                      <SunIcon className="w-3 h-3 lg:w-4 lg:h-4 text-orange-400 mr-1" />
                    ) : (
                      <MoonIcon className="w-3 h-3 lg:w-4 lg:h-4 text-blue-300 mr-1" />
                    )}
                    <span className="text-xs text-twine-300 font-patria">
                      {timeOfDay.charAt(0).toUpperCase() + timeOfDay.slice(1)} • {new Date().getFullYear()}
                    </span>
                  </div>
                </div>
                
                <button
                  onClick={onShowActivities}
                  className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20 hover:bg-white/15 transition-all duration-300 group text-left"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 lg:w-12 lg:h-12 bg-twine-500/20 rounded-xl flex items-center justify-center border border-twine-400/30">
                      <ClockIcon className="w-5 h-5 lg:w-6 lg:h-6 text-twine-300" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-base lg:text-lg font-patria font-bold text-white">Actividad Reciente</h3>
                      <p className="text-twine-200 text-xs lg:text-sm font-patria">Ver tu historial</p>
                    </div>
                    <div className="w-7 h-7 lg:w-8 lg:h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 group-hover:bg-white/20 transition-all duration-300">
                      <ArrowRightIcon className="w-3 h-3 lg:w-4 lg:h-4 text-white" />
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Mobile Menu Content */}
            {isMobileMenuOpen && (
              <div className="lg:hidden mt-4 space-y-4 animate-fadeIn">
                {/* Panel SIVOD móvil */}
                <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                  <div className="flex items-center justify-center mb-2">
                    <ComputerDesktopIcon className="w-5 h-5 text-white mr-2" />
                    <div className="text-lg font-bold font-patria text-white text-center">
                      SIVOD
                    </div>
                  </div>
                  <div className="text-xs text-twine-200 font-patria text-center">
                    Sistema Integral de Votación y Opinión Docente
                  </div>
                  <div className="w-full h-0.5 bg-white/20 rounded-full mt-2"></div>
                  <div className="flex items-center justify-center mt-2">
                    {timeOfDay === 'mañana' ? (
                      <SunIcon className="w-3 h-3 text-yellow-300 mr-1" />
                    ) : timeOfDay === 'tarde' ? (
                      <SunIcon className="w-3 h-3 text-orange-400 mr-1" />
                    ) : (
                      <MoonIcon className="w-3 h-3 text-blue-300 mr-1" />
                    )}
                    <span className="text-xs text-twine-300 font-patria">
                      {timeOfDay.charAt(0).toUpperCase() + timeOfDay.slice(1)} • {new Date().getFullYear()}
                    </span>
                  </div>
                </div>

                {/* Botón de Actividades móvil */}
                <button
                  onClick={onShowActivities}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 hover:bg-white/15 transition-all duration-300 w-full text-left"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30">
                      <ClockIcon className="w-5 h-5 text-twine-300" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-base font-patria font-bold text-white">Actividad Reciente</h3>
                      <p className="text-twine-200 text-xs font-patria">Ver tu historial</p>
                    </div>
                    <div className="w-7 h-7 bg-white/10 rounded flex items-center justify-center border border-white/20">
                      <ArrowRightIcon className="w-3 h-3 text-white" />
                    </div>
                  </div>
                </button>
              </div>
            )}
          </div>

          {/* Información adicional - Responsive */}
          <div className="mt-6 lg:mt-8 pt-4 lg:pt-6 border-t border-white/10">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 lg:gap-4">
              <div className="bg-white/5 backdrop-blur-sm rounded-lg lg:rounded-xl p-3 lg:p-4 border border-white/10 text-center">
                <div className="text-xs lg:text-sm text-twine-300 font-patria mb-2 flex items-center justify-center">
                  <CheckCircleIcon className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  Estado de Cuenta
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${userProfile?.activo === 1 ? 'bg-green-400' : 'bg-yellow-400'}`}></div>
                  <span className="text-sm lg:text-base text-white font-patria font-semibold">
                    {userProfile?.activo === 1 ? 'Activo' : 'Pendiente'}
                  </span>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg lg:rounded-xl p-3 lg:p-4 border border-white/10 text-center">
                <div className="text-xs lg:text-sm text-twine-300 font-patria mb-2 flex items-center justify-center">
                  <ClockIcon className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  Última Conexión
                </div>
                <div className="text-sm lg:text-base text-white font-patria font-semibold">Hoy</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg lg:rounded-xl p-3 lg:p-4 border border-white/10 text-center">
                <div className="text-xs lg:text-sm text-twine-300 font-patria mb-2 flex items-center justify-center">
                  <UserCircleIcon className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  Tipo de Usuario
                </div>
                <div className="text-sm lg:text-base text-white font-patria font-semibold">
                  {userProfile?.userType ? userProfile.userType.charAt(0).toUpperCase() + userProfile.userType.slice(1) : userConfig.name}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Información */}
      <InfoModal
        isOpen={showInfoModal}
        onClose={() => setShowInfoModal(false)}
        title={dashboardInfo.title}
        description={dashboardInfo.description}
        advice={dashboardInfo.features}
      />

      {/* Estilos adicionales para animaciones */}
      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </>
  );
};

export default DashboardHeader;