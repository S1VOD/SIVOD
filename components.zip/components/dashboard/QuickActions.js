import React from 'react';
import { Link } from 'react-router-dom';
import {
  UserCircleIcon,
  DocumentTextIcon,
  ChartBarIcon,
  AcademicCapIcon,
  BellIcon,
  CalendarIcon,
  ChatBubbleLeftRightIcon,
  EyeIcon,
  Cog6ToothIcon,
  UsersIcon,
  ClipboardDocumentCheckIcon,
  FolderIcon,
  ShieldCheckIcon,
  ArrowRightIcon,
  StarIcon,
  TrophyIcon,
  EnvelopeIcon,
  BookOpenIcon,
  BuildingLibraryIcon,
  WrenchScrewdriverIcon,
  ChartPieIcon,
  CogIcon,
  ExclamationCircleIcon,
  HomeIcon
} from '@heroicons/react/24/outline';

const QuickActions = ({ userType }) => {
  // Función para obtener el componente de icono por tipo
  const getIconComponent = (iconType) => {
    const iconMap = {
      // Íconos para educativos
      profile: UserCircleIcon,
      postulations: DocumentTextIcon,
      evaluation: ChartBarIcon,
      certificates: AcademicCapIcon,
      
      // Íconos para estudiantes
      results: ChartBarIcon,
      calendar: CalendarIcon,
      
      // Íconos para tutores
      suggestions: ChatBubbleLeftRightIcon,
      grades: EyeIcon,
      announcements: BellIcon,
      
      // Íconos para directores
      admin: Cog6ToothIcon,
      reports: DocumentTextIcon,
      suggestionsReview: ChatBubbleLeftRightIcon,
      staff: UsersIcon,
      
      // Íconos para administrativos
      schoolManagement: BuildingLibraryIcon,
      documents: FolderIcon,
      support: ShieldCheckIcon,
      
      // Íconos para administradores del sistema
      users: UsersIcon,
      analytics: ChartPieIcon,
      settings: CogIcon
    };
    return iconMap[iconType] || DocumentTextIcon;
  };

  const getActionsByUserType = () => {
    const baseActions = {
      educativo: [
        { 
          label: 'Ver Mi Perfil', 
          path: '/profile', 
          type: 'primary',
          description: 'Gestiona tu información profesional',
          badge: 'Actualizado',
          iconType: 'profile'
        },
        { 
          label: 'Mis Postulaciones', 
          path: '/postulations', 
          type: 'secondary',
          description: 'Revisa el estado de tus postulaciones',
          badge: '2 Activas',
          iconType: 'postulations'
        },
        { 
          label: 'Historial de Evaluaciones', 
          path: '/evaluation-history', 
          type: 'outline',
          description: 'Consulta tus evaluaciones pasadas',
          badge: '24 recibidas',
          iconType: 'evaluation'
        },
        { 
          label: 'Certificados', 
          path: '/certificates', 
          type: 'outline',
          description: 'Descarga tus reconocimientos',
          badge: '3 disponibles',
          iconType: 'certificates'
        }
      ],
      alumno: [
        { 
          label: 'Evaluar Docentes', 
          path: '/evaluation', 
          type: 'primary',
          description: 'Evalúa a tus docentes asignados',
          badge: '5 pendientes',
          iconType: 'evaluation'
        },
        { 
          label: 'Ver Resultados', 
          path: '/results', 
          type: 'secondary',
          description: 'Consulta resultados de evaluaciones',
          badge: 'Reciente',
          iconType: 'results'
        },
        { 
          label: 'Mi Perfil', 
          path: '/profile', 
          type: 'outline',
          description: 'Actualiza tu información estudiantil',
          badge: 'Completo',
          iconType: 'profile'
        },
        { 
          label: 'Calendario', 
          path: '/calendar', 
          type: 'outline',
          description: 'Próximas evaluaciones y eventos',
          badge: '2 eventos',
          iconType: 'calendar'
        }
      ],
      tutor: [
        { 
          label: 'Evaluar Docentes', 
          path: '/evaluation', 
          type: 'primary',
          description: 'Participa en la evaluación docente',
          badge: '2 pendientes',
          iconType: 'evaluation'
        },
        { 
          label: 'Buzón de Mejora', 
          path: '/suggestions', 
          type: 'secondary',
          description: 'Envía sugerencias para la escuela',
          badge: '5 enviadas',
          iconType: 'suggestions'
        },
        { 
          label: 'Ver Calificaciones', 
          path: '/grades', 
          type: 'outline',
          description: 'Consulta calificaciones de tus dependientes',
          badge: 'Actualizado',
          iconType: 'grades'
        },
        { 
          label: 'Comunicados', 
          path: '/announcements', 
          type: 'outline',
          description: 'Últimos comunicados escolares',
          badge: '3 nuevos',
          iconType: 'announcements'
        }
      ],
      director: [
        { 
          label: 'Panel de Control', 
          path: '/admin', 
          type: 'primary',
          description: 'Gestión integral de la institución',
          badge: 'Activo',
          iconType: 'admin'
        },
        { 
          label: 'Reportes', 
          path: '/reports', 
          type: 'secondary',
          description: 'Genera reportes institucionales',
          badge: 'Disponible',
          iconType: 'reports'
        },
        { 
          label: 'Sugerencias', 
          path: '/suggestions-review', 
          type: 'outline',
          description: 'Revisa sugerencias de padres',
          badge: '8 por revisar',
          iconType: 'suggestionsReview'
        },
        { 
          label: 'Personal', 
          path: '/staff', 
          type: 'outline',
          description: 'Gestión del personal educativo',
          badge: '28 miembros',
          iconType: 'staff'
        }
      ],
      administrativo: [
        { 
          label: 'Gestión Escolar', 
          path: '/school-management', 
          type: 'primary',
          description: 'Administración de datos escolares',
          badge: 'Activo',
          iconType: 'schoolManagement'
        },
        { 
          label: 'Reportes', 
          path: '/reports', 
          type: 'secondary',
          description: 'Genera reportes administrativos',
          badge: 'Disponible',
          iconType: 'reports'
        },
        { 
          label: 'Documentación', 
          path: '/documents', 
          type: 'outline',
          description: 'Gestión de documentos escolares',
          badge: '15 archivos',
          iconType: 'documents'
        },
        { 
          label: 'Atención al Usuario', 
          path: '/support', 
          type: 'outline',
          description: 'Asistencia a usuarios del sistema',
          badge: '32 hoy',
          iconType: 'support'
        }
      ],
      admin: [
        { 
          label: 'Administración', 
          path: '/admin', 
          type: 'primary',
          description: 'Panel de administración del sistema',
          badge: 'Admin',
          iconType: 'admin'
        },
        { 
          label: 'Usuarios', 
          path: '/users', 
          type: 'secondary',
          description: 'Gestión de usuarios del sistema',
          badge: '500+',
          iconType: 'users'
        },
        { 
          label: 'Estadísticas', 
          path: '/analytics', 
          type: 'outline',
          description: 'Métricas y analíticas del sistema',
          badge: 'En tiempo real',
          iconType: 'analytics'
        },
        { 
          label: 'Configuración', 
          path: '/settings', 
          type: 'outline',
          description: 'Configuración del sistema',
          badge: 'General',
          iconType: 'settings'
        }
      ]
    };

    return baseActions[userType] || [];
  };

  const getButtonStyles = (type) => {
    const styles = {
      primary: 'bg-gradient-to-r from-twine-500/90 to-twine-600/90 hover:from-twine-600 hover:to-twine-700 border border-twine-400 shadow-lg',
      secondary: 'bg-gradient-to-r from-night-500/90 to-night-600/90 hover:from-night-600 hover:to-night-700 border border-night-400 shadow-lg',
      outline: 'bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm border border-white/20 hover:bg-white/20 hover:border-white/30 shadow-md'
    };
    return styles[type] || styles.outline;
  };

  const getBadgeStyles = (type) => {
    const styles = {
      primary: 'bg-white/30 text-white backdrop-blur-sm',
      secondary: 'bg-white/30 text-white backdrop-blur-sm',
      outline: 'bg-twine-500/30 text-twine-200 backdrop-blur-sm'
    };
    return styles[type] || styles.outline;
  };

  const getIconContainerStyles = (type) => {
    const styles = {
      primary: 'bg-white/20 backdrop-blur-sm',
      secondary: 'bg-white/20 backdrop-blur-sm',
      outline: 'bg-white/10 backdrop-blur-sm'
    };
    return styles[type] || styles.outline;
  };

  const getIconColor = (type) => {
    const styles = {
      primary: 'text-white',
      secondary: 'text-white',
      outline: 'text-twine-300'
    };
    return styles[type] || styles.outline;
  };

  const actions = getActionsByUserType();

  if (actions.length === 0) {
    return (
      <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
        <div className="bg-gradient-to-r from-twine-600/80 to-twine-700/80 px-6 py-5 border-b border-white/20">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
              <ExclamationCircleIcon className="h-7 w-7 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-patria font-bold text-white">Acciones Rápidas</h3>
              <p className="text-white/80 text-sm font-patria">Accesos directos a funciones clave</p>
            </div>
          </div>
        </div>
        <div className="p-8 text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-twine-500/20 to-twine-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-twine-400/30">
            <ExclamationCircleIcon className="h-10 w-10 text-twine-300" />
          </div>
          <h4 className="text-lg font-patria font-semibold text-white mb-3">
            Acciones en desarrollo
          </h4>
          <p className="text-twine-200 font-patria mb-6">
            Las acciones personalizadas para <span className="font-semibold text-white">{userType}</span> estarán disponibles próximamente.
          </p>
          <div className="space-y-4">
            <Link to="/profile" className="group block p-4 bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-xl border border-white/20 hover:bg-white/20 transition-all duration-300">
              <div className="flex items-center justify-center">
                <UserCircleIcon className="h-5 w-5 text-white mr-3" />
                <span className="text-white font-patria">Ir a Mi Perfil</span>
              </div>
            </Link>
            <Link to="/dashboard" className="group block p-4 bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-xl border border-white/20 hover:bg-white/20 transition-all duration-300">
              <div className="flex items-center justify-center">
                <HomeIcon className="h-5 w-5 text-white mr-3" />
                <span className="text-white font-patria">Volver al Dashboard</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-twine-600/80 to-twine-700/80 px-6 py-5 border-b border-white/20">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
            <TrophyIcon className="h-7 w-7 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-patria font-bold text-white">Acciones Rápidas</h3>
            <p className="text-white/80 text-sm font-patria">Accesos directos a funciones clave</p>
          </div>
        </div>
      </div>

      {/* Lista de acciones */}
      <div className="p-6 space-y-5">
        {actions.map((action, index) => {
          const IconComponent = getIconComponent(action.iconType);
          
          return (
            <Link
              key={index}
              to={action.path}
              className={`group relative block p-5 rounded-xl transition-all duration-300 hover:shadow-xl ${getButtonStyles(action.type)}`}
            >
              <div className="flex items-center space-x-5">
                {/* Icono */}
                <div className={`w-14 h-14 ${getIconContainerStyles(action.type)} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <IconComponent className={`h-7 w-7 ${getIconColor(action.type)}`} />
                </div>

                {/* Contenido */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className={`font-semibold text-lg leading-tight font-patria text-white group-hover:text-twine-200 transition-colors`}>
                      {action.label}
                    </h4>
                    {action.badge && (
                      <span className={`text-xs px-3 py-1.5 rounded-full font-medium whitespace-nowrap ml-2 font-patria ${getBadgeStyles(action.type)}`}>
                        {action.badge}
                      </span>
                    )}
                  </div>
                  
                  <p className={`text-sm leading-tight font-patria ${
                    action.type === 'outline' ? 'text-twine-200' : 'text-white/80'
                  }`}>
                    {action.description}
                  </p>
                </div>

                {/* Flecha indicadora */}
                <div className="flex-shrink-0">
                  <div className={`w-10 h-10 ${getIconContainerStyles(action.type)} rounded-lg flex items-center justify-center group-hover:bg-white/20 transition-colors duration-300`}>
                    <ArrowRightIcon className={`h-5 w-5 ${getIconColor(action.type)} group-hover:translate-x-1 transition-transform duration-300`} />
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {/* Footer adicional */}
      <div className="p-6 pt-0">
        <div className="flex items-center justify-center text-white/60 text-sm">
          <StarIcon className="h-4 w-4 mr-2" />
          <span className="font-patria">Selecciona una acción para comenzar</span>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;