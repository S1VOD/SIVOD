import React, { useState, useEffect, useCallback } from 'react';
import CreatePublicationModal from './CreatePublicationModal';
import CreateSurveyModal from './CreateSurveyModal';
import RespondSurveyModal from './RespondSurveyModal';
import AlertService from '../common/Alerts'; 
import {
  // Iconos de navegación
  HomeIcon,
  FireIcon,
  ChatBubbleLeftRightIcon,
  ChartBarIcon,
  
  // Iconos de acciones
  HeartIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon,
  CheckCircleIcon,
  XCircleIcon,
  ChartBarSquareIcon,
  ExclamationTriangleIcon,
  ListBulletIcon,
  
  // Iconos de usuario
  UserCircleIcon,
  UserIcon,
  AcademicCapIcon,
  UserGroupIcon,
  
  // Iconos de estado
  StarIcon,
  ClockIcon,
  ArrowPathIcon,
  PlusIcon,
  QuestionMarkCircleIcon,
  UsersIcon,
  
  // Iconos de sistema
  InformationCircleIcon,
  ExclamationCircleIcon,
  ArrowRightIcon,
  DocumentTextIcon,
  CircleStackIcon
} from '@heroicons/react/24/outline';

// Importar versiones sólidas para algunos iconos
import {
  HeartIcon as HeartIconSolid,
  StarIcon as StarIconSolid,
  CheckCircleIcon as CheckCircleIconSolid,
  ExclamationTriangleIcon as ExclamationTriangleIconSolid,
  UserCircleIcon as UserCircleIconSolid
} from '@heroicons/react/24/solid';

const CommunityFeed = () => {
  const [activeFilter, setActiveFilter] = useState('todos');
  const [currentUser, setCurrentUser] = useState(null);
  const [feedData, setFeedData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCreateSurveyModal, setShowCreateSurveyModal] = useState(false);
  const [showRespondSurveyModal, setShowRespondSurveyModal] = useState(false);
  const [editingPublication, setEditingPublication] = useState(null);
  const [likingPublication, setLikingPublication] = useState(null);
  const [selectedSurvey, setSelectedSurvey] = useState(null);
  const [surveysData, setSurveysData] = useState([]);
  const [showComments, setShowComments] = useState({});
  const [commentText, setCommentText] = useState('');
  const [postingComment, setPostingComment] = useState(null);
  const [commentsData, setCommentsData] = useState({});

  const API_URL = 'http://localhost:8000';

  useEffect(() => {
    const getUserData = () => {
      try {
        const userProfileStr = localStorage.getItem('userProfile');
        if (userProfileStr) {
          const userProfile = JSON.parse(userProfileStr);
          if (userProfile && userProfile.id) {
            const userData = {
              id: userProfile.id,
              nombre: userProfile.nombre || '',
              ape_pa: userProfile.ape_pa || '',
              ape_ma: userProfile.ape_ma || '',
              userType: localStorage.getItem('userType') || userProfile.userType || 'educativo',
              role: userProfile.role || 'docente',
              escuela_id: userProfile.escuela_id || null,
              escuela_nombre: userProfile.escuela_nombre || '',
              correo: userProfile.email || userProfile.correo || ''
            };
            console.log('Usuario cargado desde userProfile:', userData);
            setCurrentUser(userData);
            return;
          }
        }

        const userDataStr = localStorage.getItem('userData');
        if (userDataStr) {
          const userData = JSON.parse(userDataStr);
          const enhancedUser = {
            ...userData,
            userType: localStorage.getItem('userType') || userData.userType || 'educativo',
            role: userData.role || 'docente',
            id: userData.id || userData.id_edu || userData.id_adm || userData.id_tut || userData.id_alu
          };
          console.log('Usuario cargado desde userData:', enhancedUser);
          setCurrentUser(enhancedUser);
        }
      } catch (error) {
        console.error('Error al cargar datos del usuario:', error);
      }
    };

    getUserData();
  }, []);

  const registerView = useCallback(async (publicationId) => {
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) return;

      const viewKey = `viewed_${publicationId}`;
      const lastView = localStorage.getItem(viewKey);
      const now = Date.now();

      if (lastView && (now - parseInt(lastView)) < 60000) {
        return;
      }

      await fetch(`${API_URL}/api/v1/publications/${publicationId}/view`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      localStorage.setItem(viewKey, now.toString());
    } catch (error) {
      console.error('Error al registrar vista:', error);
    }
  }, [API_URL]);

  const fetchPublications = useCallback(async (token) => {
    try {
      const response = await fetch(`${API_URL}/api/v1/publications`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        mode: 'cors',
        credentials: 'omit'
      });

      const responseData = await response.json();
      console.log('Publicaciones recibidas:', responseData);

      if (response.ok) {
        if (responseData.detail && (responseData.type === 'validation_error' || Array.isArray(responseData.detail))) {
          console.error('Error de validación:', responseData);
          setError('Error en los datos recibidos del servidor');
          setFeedData([]);
          return;
        }

        const data = responseData;
        const transformedData = (data.publications || []).map(pub => {
          setTimeout(() => registerView(pub.id_pub), 1000);

          // Construir el nombre correctamente
          let autorNombreCompleto = '';
          
          if (pub.autor_nombre && pub.autor_apellido) {
            const nombreSinDuplicados = pub.autor_nombre.endsWith(pub.autor_apellido) 
              ? pub.autor_nombre 
              : `${pub.autor_nombre} ${pub.autor_apellido}`;
            autorNombreCompleto = nombreSinDuplicados.trim();
          } else if (pub.autor_nombre) {
            autorNombreCompleto = pub.autor_nombre.trim();
          } else {
            autorNombreCompleto = 'Usuario';
          }

          return {
            id: pub.id_pub,
            type: 'publicacion',
            combinedType: 'publicacion',
            author: {
              name: autorNombreCompleto,
              role: pub.role === 'director' ? 'Director' : 
                    pub.role === 'docente' ? 'Docente' :
                    pub.role === 'admin' ? 'Administrador' :
                    pub.role === 'tutor' ? 'Tutor' :
                    pub.role === 'alumno' ? 'Estudiante' :
                    pub.role || 'Usuario',
              avatar: autorNombreCompleto.split(' ')
                .map(n => n.charAt(0))
                .join('')
                .toUpperCase() || 'US',
              foto: pub.autor_foto || 'Fotoperfil.jpg',
              fotoUrl: pub.autor_foto ? `${API_URL}/uploads/photos/${pub.autor_foto}` : `${API_URL}/uploads/photos/Fotoperfil.jpg`,
              userType: pub.autor_tipo || 'educativo',
              isCurrentUser: currentUser && 
                ((pub.autor_tipo === currentUser.userType && pub.autor_id === currentUser.id) ||
                 (currentUser.userType === 'educativo' && pub.id_educativo === currentUser.id))
            },
            titulo: pub.titulo || 'Sin título',
            contenido: pub.contenido || '',
            fecha: new Date(pub.fecha_publicacion),
            likes: pub.likes || 0,
            vistas: pub.vistas || 0,
            total_comentarios: pub.total_comentarios || 0,
            etiquetas: pub.tipo_publicacion ? [pub.tipo_publicacion] : ['general'],
            imagen_url: pub.imagen_url,
            es_destacado: pub.es_destacado || pub.destacada === 1 || pub.likes >= 50,
            id_educativo: pub.id_educativo,
            autor_tipo: pub.autor_tipo,
            autor_id: pub.autor_id,
            escuela_id: pub.escuela_id,
            tipo_publicacion: pub.tipo_publicacion || 'general'
          };
        });

        const sortedData = transformedData.sort((a, b) => {
          if (a.es_destacado && !b.es_destacado) return -1;
          if (!a.es_destacado && b.es_destacado) return 1;
          return new Date(b.fecha) - new Date(a.fecha);
        });

        setFeedData(sortedData);
      } else if (response.status === 401) {
        setError('Tu sesión ha expirado. Por favor, inicia sesión nuevamente.');
        setFeedData([]);
      } else if (response.status === 403) {
        setError('Los usuarios administrativos no tienen acceso al sistema de publicaciones.');
        setFeedData([]);
      } else {
        setError(`Error del servidor (${response.status})`);
        setFeedData([]);
      }
    } catch (apiError) {
      console.error('Error al cargar publicaciones:', apiError);
      setError('Error de conexión con el servidor');
      setFeedData([]);
    }
  }, [API_URL, currentUser, registerView]);

  const fetchComments = useCallback(async (publicationId) => {
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) return;

      const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}/comments`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setCommentsData(prev => ({
          ...prev,
          [publicationId]: data.comments || []
        }));
      }
    } catch (error) {
      console.error('Error al cargar comentarios:', error);
    }
  }, [API_URL]);

  const handlePostComment = async (publicationId) => {
    if (!commentText.trim() || postingComment === publicationId) return;

    setPostingComment(publicationId);

    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado');
        return;
      }

      const formData = new FormData();
      formData.append('contenido', commentText);

      const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}/comments`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (response.ok) {
        const data = await response.json();
        
        // Actualizar contador de comentarios en el feed
        setFeedData(prev => prev.map(item => {
          if (item.id === publicationId) {
            return {
              ...item,
              total_comentarios: (item.total_comentarios || 0) + 1
            };
          }
          return item;
        }));
        
        // Actualizar lista de comentarios
        setCommentsData(prev => ({
          ...prev,
          [publicationId]: [...(prev[publicationId] || []), data.comment]
        }));
        
        setCommentText('');
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.detail || 'No se pudo publicar el comentario'}`);
      }
    } catch (error) {
      console.error('Error al publicar comentario:', error);
      alert('Error al publicar comentario');
    } finally {
      setPostingComment(null);
    }
  };

const handleDeleteComment = async (commentId, publicationId) => {
  const result = await AlertService.confirm(
    'Eliminar comentario',
    '¿Estás seguro de eliminar este comentario?',
    'Sí, eliminar',
    'Cancelar'
  );

  if (!result.isConfirmed) return;

  try {
    const token = localStorage.getItem('token') || localStorage.getItem('authToken');
    if (!token) {
      await AlertService.error('Error', 'No estás autenticado');
      return;
    }

    const response = await fetch(`${API_URL}/api/v1/comments/${commentId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      await AlertService.success('Comentario eliminado', 'El comentario se ha eliminado correctamente');
      
      // Actualizar contador de comentarios en el feed
      setFeedData(prev => prev.map(item => {
        if (item.id === publicationId) {
          return {
            ...item,
            total_comentarios: Math.max((item.total_comentarios || 0) - 1, 0)
          };
        }
        return item;
      }));
      
      // Actualizar lista de comentarios
      setCommentsData(prev => ({
        ...prev,
        [publicationId]: (prev[publicationId] || []).filter(comment => comment.id_comentario !== commentId)
      }));
    } else {
      const errorData = await response.json();
      await AlertService.error('Error', errorData.detail || 'No se pudo eliminar el comentario');
    }
  } catch (error) {
    console.error('Error al eliminar comentario:', error);
    await AlertService.error('Error', 'Error al eliminar comentario');
  }
};

  const exportToExcel = (surveyData) => {
  const responses = surveyData.responses;
  const questions = surveyData.preguntas;
  
  // Encabezados dinámicos basados en preguntas
  let csv = 'ID Respuesta,Usuario,Tipo Usuario,Fecha Respuesta,Anónimo,Correo Electrónico';
  
  // Agregar columnas para cada pregunta
  questions?.forEach((pregunta, idx) => {
    csv += `,P${idx + 1}: ${pregunta.texto_pregunta.substring(0, 50)}${pregunta.texto_pregunta.length > 50 ? '...' : ''}`;
  });
  
  csv += '\n';
  
  // Datos de cada respuesta
  responses.forEach((response, respIdx) => {
    const row = [
      respIdx + 1,
      `"${response.usuario_nombre}"`,
      response.tipo_usuario,
      response.fecha_respuesta,
      response.anonimo ? 'Sí' : 'No',
      response.usuario_correo || ''
    ];
    
    // Mapear respuestas a preguntas
    const respuestasPorPregunta = {};
    
    if (response.respuesta_completa && Array.isArray(response.respuesta_completa)) {
      response.respuesta_completa.forEach(resp => {
        const pregunta = questions?.find(p => p.id_pregunta === resp.id_pregunta);
        let respuestaTexto = '';
        
        if (resp.respuesta_texto) {
          respuestaTexto = resp.respuesta_texto.replace(/"/g, '""');
        } else if (resp.opciones_seleccionadas && resp.opciones_seleccionadas.length > 0) {
          if (pregunta && pregunta.opciones) {
            const opcionesSeleccionadas = resp.opciones_seleccionadas.map(id => {
              const opcion = pregunta.opciones.find(o => o.id_opcion === id);
              return opcion ? opcion.texto_opcion : `Opción ${id}`;
            });
            respuestaTexto = opcionesSeleccionadas.join('; ');
          } else {
            respuestaTexto = resp.opciones_seleccionadas.join('; ');
          }
        } else if (resp.valor_escala) {
          respuestaTexto = resp.valor_escala.toString();
        }
        
        respuestasPorPregunta[resp.id_pregunta] = `"${respuestaTexto}"`;
      });
    } else if (response.respuesta) {
      // Para encuestas antiguas
      respuestasPorPregunta[1] = `"${response.respuesta.replace(/"/g, '""')}"`;
    }
    
    // Agregar respuestas a la fila en el orden de las preguntas
    questions?.forEach(pregunta => {
      row.push(respuestasPorPregunta[pregunta.id_pregunta] || '""');
    });
    
    csv += row.join(',') + '\n';
  });
  
  // Descargar CSV
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const fecha = new Date().toISOString().split('T')[0];
  a.download = `respuestas_${surveyData.survey_title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${fecha}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

  const fetchSurveys = useCallback(async (token) => {
    try {
      console.log('Fetching surveys for user:', currentUser?.userType, 'with token:', token ? 'Present' : 'Missing');
      
      if (!token) {
        console.log('No token available for fetching surveys');
        setSurveysData([]);
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/surveys`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        mode: 'cors',
        credentials: 'omit'
      });

      console.log('Surveys response status:', response.status);
      
      if (response.status === 401) {
        console.log('Token inválido o expirado');
        setSurveysData([]);
        return;
      }

      if (response.ok) {
        const data = await response.json();
        console.log('Surveys data received for', currentUser?.userType, ':', data);

        if (data.detail && Array.isArray(data.detail)) {
          console.error('Error de validación en encuestas:', data);
          setSurveysData([]);
          return;
        }

        const transformedSurveys = (data.surveys || []).map(survey => {
          if (!survey || typeof survey !== 'object') {
            console.error('Survey inválido:', survey);
            return null;
          }

          const isCreator = currentUser && 
            survey.id_creador === currentUser.id && 
            survey.tipo_creador === currentUser.userType;

          // Manejar nombres de creador sin duplicaciones
          let creadorNombre = String(survey.creador_nombre || 'Usuario');
          const nombreParts = creadorNombre.split(' ');
          if (nombreParts.length >= 2 && nombreParts[nombreParts.length - 1] === nombreParts[nombreParts.length - 2]) {
            creadorNombre = nombreParts.slice(0, -1).join(' ');
          }

          // Obtener tipos de preguntas para mostrar
          const tiposPreguntas = survey.preguntas ? 
            Array.from(new Set(survey.preguntas.map(p => p.tipo_pregunta))) : ['texto_libre'];
          
          // Determinar icono basado en tipos de preguntas
          const getSurveyIcon = () => {
            if (tiposPreguntas.includes('opcion_multiple')) return ListBulletIcon;
            if (tiposPreguntas.includes('seleccion_unica')) return CircleStackIcon;
            if (tiposPreguntas.includes('escala')) return ChartBarSquareIcon;
            return DocumentTextIcon;
          };

          const SurveyIcon = getSurveyIcon();

          // Formatear usuarios permitidos
          const usuariosPermitidos = Array.isArray(survey.usuarios_permitidos) 
            ? survey.usuarios_permitidos.map(u => {
                const labels = {
                  'educativo': 'Educativos',
                  'tutor': 'Tutores',
                  'alumno': 'Alumnos',
                  'administrativo': 'Administrativos'
                };
                return labels[u] || u;
              }).join(', ')
            : 'Educativos y Tutores';

          // Determinar si el usuario puede responder
          const userType = currentUser?.userType;
          const puedeResponder = survey.puede_responder || (
            !survey.esta_cerrada && 
            !survey.usuario_ya_respondio &&
            survey.usuarios_permitidos?.includes(userType)
          );

          return {
            id: survey.id_encuesta || 0,
            type: 'encuesta',
            combinedType: 'encuesta',
            titulo: String(survey.titulo || 'Sin título'),
            descripcion: String(survey.descripcion || ''),
            primera_pregunta: survey.preguntas && survey.preguntas.length > 0 
              ? survey.preguntas[0].texto_pregunta 
              : String(survey.pregunta || ''),
            preguntas: survey.preguntas || [],
            total_preguntas: survey.preguntas ? survey.preguntas.length : 1,
            tipos_preguntas: tiposPreguntas,
            icono: SurveyIcon,
            creador_nombre: creadorNombre,
            fecha_creacion: survey.fecha_creacion || new Date().toISOString(),
            fecha_cierre: survey.fecha_cierre || null,
            total_respuestas: Number(survey.total_respuestas) || 0,
            escuela_id: survey.escuela_id || 0,
            usuario_ya_respondio: survey.usuario_ya_respondio === 1,
            puede_responder: puedeResponder,
            esta_cerrada: survey.esta_cerrada || false,
            usuarios_permitidos: usuariosPermitidos,
            permite_anonimo: survey.permite_anonimo || false,
            max_respuestas: survey.max_respuestas || null,
            autor_rol: survey.creador_nombre?.includes('Director') ? 'Director' : 'Educativo/Tutor',
            id_creador: survey.id_creador || null,
            tipo_creador: survey.tipo_creador || 'educativo',
            es_creador: isCreator,
            creador_foto_url: survey.creador_foto ? 
              `${API_URL}/uploads/photos/${survey.creador_foto}` : 
              `${API_URL}/uploads/photos/Fotoperfil.jpg`,
            author: {
              name: creadorNombre,
              role: survey.creador_nombre?.includes('Director') ? 'Director' : 'Educativo/Tutor',
              avatar: creadorNombre ? creadorNombre.substring(0, 2) : 'US',
              foto: survey.creador_foto || 'Fotoperfil.jpg',
              fotoUrl: survey.creador_foto ? 
                `${API_URL}/uploads/photos/${survey.creador_foto}` : 
                `${API_URL}/uploads/photos/Fotoperfil.jpg`,
              userType: survey.tipo_creador || 'educativo'
            }
          };
        }).filter(survey => survey !== null);

        console.log(`Transformed ${transformedSurveys.length} surveys for user type:`, currentUser?.userType);
        setSurveysData(transformedSurveys);
      } else {
        const errorText = await response.text();
        console.error('Error al cargar encuestas:', response.status, errorText);
        
        // No establecer error global, solo dejar array vacío
        setSurveysData([]);
      }
    } catch (error) {
      console.error('Error al cargar encuestas:', error);
      // No establecer error global, solo dejar array vacío
      setSurveysData([]);
    }
  }, [API_URL, currentUser]);

  useEffect(() => {
    const fetchFeedData = async () => {
      try {
        setLoading(true);
        setError(null);

        if (currentUser) {
          const token = localStorage.getItem('token') || localStorage.getItem('authToken');
          console.log('Current user:', currentUser.userType, currentUser.id);
          console.log('Token:', token ? 'Present' : 'Missing');
          
          if (token) {
            // Siempre cargar publicaciones
            await fetchPublications(token);

            // IMPORTANTE: TODOS los usuarios pueden ver encuestas
            // Solo se limita quién puede CREAR encuestas
            await fetchSurveys(token);
            
          } else {
            console.log('No token found');
            setFeedData([]);
            setSurveysData([]);
          }
        } else {
          console.log('No current user');
          setFeedData([]);
          setSurveysData([]);
        }
      } catch (err) {
        console.error('Error general al cargar el feed:', err);
        setError('No se pudo cargar el contenido');
        setFeedData([]);
        setSurveysData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchFeedData();
  }, [currentUser, fetchPublications, fetchSurveys]);

  const getCommunityFeed = () => {
    const combined = [
      ...feedData.map(item => ({ ...item, fecha_creacion: item.fecha })),
      ...surveysData.map(item => ({ ...item, fecha_creacion: new Date(item.fecha_creacion) }))
    ].sort((a, b) => {
      const dateA = new Date(a.fecha_creacion);
      const dateB = new Date(b.fecha_creacion);
      return dateB - dateA;
    });

    console.log('Combined feed items:', combined.length, 'Publicaciones:', feedData.length, 'Encuestas:', surveysData.length);
    return combined;
  };

  const handleLikePublication = async (publicationId, currentLikes) => {
    if (likingPublication === publicationId) return;

    setLikingPublication(publicationId);

    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado. Por favor, inicia sesión nuevamente.');
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}/like`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();

        setFeedData(prevData =>
          prevData.map(item => {
            if (item.id === publicationId) {
              return {
                ...item,
                likes: result.likes,
                es_destacado: result.es_destacado,
                destacada: result.es_destacado ? 1 : 0
              };
            }
            return item;
          })
        );

        if (result.es_destacado && currentLikes < 50) {
          setTimeout(() => {
            alert('¡Esta publicación ahora es destacada!');
          }, 300);
        }
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.detail || 'No se pudo dar like a la publicación'}`);
      }
    } catch (error) {
      console.error('Error al dar like:', error);
      alert('Error al dar like. Por favor, intenta nuevamente.');
    } finally {
      setLikingPublication(null);
    }
  };

  const isPublicationAuthor = (publication) => {
    if (!currentUser || !publication) return false;
    
    if (publication.autor_tipo && publication.autor_id) {
      return publication.autor_tipo === currentUser.userType && 
             publication.autor_id === currentUser.id;
    }
    
    return currentUser.userType === 'educativo' && 
           publication.id_educativo === currentUser.id;
  };

  const isSurveyCreator = (survey) => {
    if (!currentUser || !survey) return false;

    if (survey.es_creador !== undefined) {
      return survey.es_creador === true;
    }

    if (survey.id_creador && currentUser.id && survey.id_creador === currentUser.id) {
      return true;
    }

    return false;
  };

const handleDeletePublication = async (publicationId, publicationTitle) => {
  const result = await AlertService.confirm(
    'Eliminar publicación',
    `¿Estás seguro de que deseas eliminar la publicación "${publicationTitle || 'esta publicación'}"?\n\nEsta acción no se puede deshacer.`,
    'Sí, eliminar',
    'Cancelar'
  );

  if (!result.isConfirmed) {
    return;
  }

  try {
    const token = localStorage.getItem('token') || localStorage.getItem('authToken');
    if (!token) {
      await AlertService.error('Error', 'No estás autenticado. Por favor, inicia sesión nuevamente.');
      return;
    }

    const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const result = await response.json();
      await AlertService.success('Publicación eliminada', result.message || 'Publicación eliminada exitosamente');

      setFeedData(prev => prev.filter(item => item.id !== publicationId));
    } else {
      const errorData = await response.json();
      await AlertService.error('Error', errorData.detail || 'No se pudo eliminar la publicación');
    }
  } catch (error) {
    console.error('Error al eliminar publicación:', error);
    await AlertService.error('Error', 'Error al eliminar la publicación. Por favor, intenta nuevamente.');
  }
};

  const handleDeleteSurvey = async (surveyId, surveyTitle) => {
  const result = await AlertService.confirm(
    'Eliminar encuesta',
    `¿Estás seguro de que deseas eliminar la encuesta "${surveyTitle || 'esta encuesta'}"?\n\nADVERTENCIA: Esta acción eliminará:\n• Todas las respuestas asociadas\n• Los datos estadísticos\n• La encuesta completa`,
    'Sí, eliminar',
    'Cancelar'
  );

  if (!result.isConfirmed) {
    return;
  }

  try {
    const token = localStorage.getItem('token') || localStorage.getItem('authToken');
    if (!token) {
      await AlertService.error('Error', 'No estás autenticado. Por favor, inicia sesión nuevamente.');
      return;
    }

    const response = await fetch(`${API_URL}/api/v1/surveys/${surveyId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const result = await response.json();
      await AlertService.success('Encuesta eliminada', result.message || 'Encuesta eliminada exitosamente');

      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (token) {
        await fetchSurveys(token);
      }
    } else {
      const errorData = await response.json();
      await AlertService.error('Error', errorData.detail || 'No se pudo eliminar la encuesta');
    }
  } catch (error) {
    console.error('Error al eliminar encuesta:', error);
    await AlertService.error('Error', 'Error al eliminar la encuesta. Por favor, intenta nuevamente.');
  }
};

  const handleEditPublication = (publication) => {
    setEditingPublication(publication);
    setShowCreateModal(true);
  };

  const getUserRoleLabel = (userType, role) => {
    const roleLabels = {
      'educativo': {
        'director': 'Director',
        'docente': 'Docente',
        'admin': 'Administrador'
      },
      'administrativo': {
        'administrativo': 'Administrativo'
      },
      'tutor': {
        'tutor': 'Tutor'
      },
      'alumno': {
        'alumno': 'Estudiante'
      }
    };
    return roleLabels[userType]?.[role] || 'Usuario';
  };

  const canCreatePublication = () => {
    if (!currentUser) return false;
    return true; // Todos los usuarios pueden crear publicaciones
  };

  const canCreateSurvey = () => {
    if (!currentUser) return false;
    return currentUser.userType === 'educativo' || currentUser.userType === 'tutor';
  };

  const handleRespondSurvey = (survey) => {
    if (!survey.puede_responder) {
      if (survey.esta_cerrada) {
        alert('Esta encuesta está cerrada y no se pueden enviar más respuestas.');
      } else if (survey.usuario_ya_respondio) {
        alert('Ya has respondido esta encuesta.');
      } else if (!survey.usuarios_permitidos?.includes(currentUser?.userType)) {
        alert('No tienes permiso para responder esta encuesta.');
      }
      return;
    }
    setSelectedSurvey(survey);
    setShowRespondSurveyModal(true);
  };

const handleViewSurveyStats = async (surveyId, surveyTitle) => {
  try {
    const token = localStorage.getItem('token') || localStorage.getItem('authToken');
    if (!token) {
      alert('No estás autenticado');
      return;
    }

    const response = await fetch(`${API_URL}/api/v1/surveys/${surveyId}/responses`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const data = await response.json();
      
      // Almacenar los datos para exportar
      window.currentSurveyData = data;
      
      // Obtener colores CSS exactos del InfoModal
      const modalHtml = `
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div class="relative w-full max-w-4xl max-h-[85vh] bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden flex flex-col">
            <!-- Header con gradiente exacto del InfoModal -->
            <div class="bg-gradient-to-r from-twine-600/80 to-twine-800/80 px-6 py-4 border-b border-white/20 flex-shrink-0">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                  <div>
                    <h3 class="text-xl font-patria font-bold text-white">${surveyTitle}</h3>
                    <p class="text-white/80 text-sm font-patria">
                      Respuestas: ${data.total_responses} | Creador: ${data.creador_nombre} | Escuela: ${data.escuela_nombre}
                    </p>
                  </div>
                </div>
                <div class="flex items-center space-x-2">
                  ${data.total_responses > 0 ? `
                    <button id="exportExcelBtn" class="bg-twine-500/20 hover:bg-twine-500/30 text-twine-300 px-4 py-2 rounded-xl border border-twine-400/30 transition-all duration-300 font-patria text-sm flex items-center space-x-2">
                      <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                      </svg>
                      <span>Exportar CSV</span>
                    </button>
                  ` : ''}
                  <button id="closeModalBtn" class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                    <div class="w-3 h-3 relative">
                      <div class="absolute top-1/2 left-0 w-full h-0.5 bg-white transform -rotate-45"></div>
                      <div class="absolute top-1/2 left-0 w-full h-0.5 bg-white transform rotate-45"></div>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <!-- Contenido del modal con scroll -->
            <div class="flex-1 overflow-y-auto p-6">
              <div class="space-y-6">
                
                <!-- Sección de Preguntas -->
                ${data.preguntas && data.preguntas.length > 0 ? `
                  <div>
                    <h4 class="text-white font-patria font-semibold text-lg mb-3">Preguntas de la encuesta</h4>
                    <div class="space-y-4">
                      ${data.preguntas.map((pregunta, idx) => `
                        <div class="bg-white/5 border border-white/10 rounded-xl p-4">
                          <div class="flex justify-between items-start mb-3">
                            <div class="flex-1">
                              <p class="text-white font-patria font-medium mb-2">${idx + 1}. ${pregunta.texto_pregunta}</p>
                              <span class="inline-block px-3 py-1 bg-twine-500/20 text-twine-300 rounded-full text-xs border border-twine-400/30">
                                ${pregunta.tipo_pregunta === 'texto_libre' ? 'Texto libre' : 
                                  pregunta.tipo_pregunta === 'seleccion_unica' ? 'Selección única' :
                                  pregunta.tipo_pregunta === 'opcion_multiple' ? 'Opción múltiple' : 'Escala'}
                              </span>
                            </div>
                          </div>
                          ${pregunta.opciones && pregunta.opciones.length > 0 ? `
                            <div class="mt-3">
                              <p class="text-white/70 text-sm mb-2">Opciones:</p>
                              <div class="space-y-2">
                                ${pregunta.opciones.map(opcion => `
                                  <div class="flex items-center space-x-3">
                                    <div class="w-5 h-5 bg-twine-500/20 rounded-full flex items-center justify-center border border-twine-400/30 flex-shrink-0">
                                      <div class="w-2 h-2 bg-twine-300 rounded-full"></div>
                                    </div>
                                    <span class="text-twine-200 text-sm">${opcion.texto_opcion}</span>
                                  </div>
                                `).join('')}
                              </div>
                            </div>
                          ` : ''}
                        </div>
                      `).join('')}
                    </div>
                  </div>
                ` : ''}
                
                <!-- Sección de Respuestas -->
                ${data.responses && data.responses.length > 0 ? `
                  <div>
                    <h4 class="text-white font-patria font-semibold text-lg mb-3">
                      Respuestas recibidas (${data.responses.length})
                    </h4>
                    <div class="space-y-4">
                      ${data.responses.map((respuesta, idx) => {
                        const fecha = new Date(respuesta.fecha_respuesta);
                        const fechaFormateada = fecha.toLocaleDateString('es-MX', {
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        });
                        
                        return `
                          <div class="bg-white/5 border border-white/10 rounded-xl p-4">
                            <!-- Header de respuesta -->
                            <div class="flex justify-between items-start mb-4 pb-4 border-b border-white/10">
                              <div class="flex items-center space-x-3">
                                <img src="${respuesta.usuario_foto ? `${API_URL}/uploads/photos/${respuesta.usuario_foto}` : `${API_URL}/uploads/photos/Fotoperfil.jpg`}" 
                                     class="w-10 h-10 rounded-full border-2 ${respuesta.anonimo ? 'border-green-500/30' : 'border-twine-400/30'} object-cover"
                                     alt="${respuesta.usuario_nombre}"
                                     onerror="this.src='${API_URL}/uploads/photos/Fotoperfil.jpg'">
                                <div>
                                  <div class="flex items-center space-x-2">
                                    <p class="text-white font-patria font-medium ${respuesta.anonimo ? 'text-green-300' : ''}">
                                      ${respuesta.usuario_nombre}
                                    </p>
                                    ${respuesta.anonimo ? `
                                      <span class="px-2 py-0.5 bg-green-500/20 text-green-300 rounded-full text-xs border border-green-400/30">
                                        Anónimo
                                      </span>
                                    ` : ''}
                                  </div>
                                  <p class="text-twine-300 text-xs mt-1">
                                    ${respuesta.tipo_usuario} • ${fechaFormateada}
                                    ${respuesta.usuario_correo && !respuesta.anonimo ? ` • ${respuesta.usuario_correo}` : ''}
                                  </p>
                                </div>
                              </div>
                              <span class="bg-white/10 text-twine-300 px-2 py-1 rounded-full text-xs border border-white/10">
                                #${idx + 1}
                              </span>
                            </div>
                            
                            <!-- Contenido de la respuesta -->
                            ${respuesta.respuesta_completa && Array.isArray(respuesta.respuesta_completa) ? `
                              <div class="space-y-3">
                                ${respuesta.respuesta_completa.map((resp, respIdx) => {
                                  const pregunta = data.preguntas?.find(p => p.id_pregunta === resp.id_pregunta);
                                  let contenidoRespuesta = '';
                                  
                                  if (resp.respuesta_texto) {
                                    contenidoRespuesta = resp.respuesta_texto;
                                  } else if (resp.opciones_seleccionadas && resp.opciones_seleccionadas.length > 0) {
                                    if (pregunta && pregunta.opciones) {
                                      const opcionesSeleccionadas = resp.opciones_seleccionadas.map(id => {
                                        const opcion = pregunta.opciones.find(o => o.id_opcion === id);
                                        return opcion ? opcion.texto_opcion : `Opción ${id}`;
                                      });
                                      contenidoRespuesta = opcionesSeleccionadas.join(', ');
                                    } else {
                                      contenidoRespuesta = `Seleccionó opción(es): ${resp.opciones_seleccionadas.join(', ')}`;
                                    }
                                  } else if (resp.valor_escala) {
                                    contenidoRespuesta = `Calificación: ${resp.valor_escala}/5`;
                                  }
                                  
                                  return `
                                    <div class="bg-white/5 rounded-lg p-3 border border-white/5">
                                      <p class="text-twine-300 font-patria font-medium text-sm mb-2">
                                        ${pregunta ? pregunta.texto_pregunta : `Pregunta ${resp.id_pregunta}`}
                                      </p>
                                      <p class="text-white font-patria text-sm pl-2">
                                        ${contenidoRespuesta || 'Sin respuesta'}
                                      </p>
                                    </div>
                                  `;
                                }).join('')}
                              </div>
                            ` : respuesta.respuesta ? `
                              <div class="bg-white/5 rounded-lg p-3 border border-white/5">
                                <p class="text-twine-300 font-patria font-medium text-sm mb-2">Respuesta:</p>
                                <p class="text-white font-patria text-sm pl-2 whitespace-pre-wrap">${respuesta.respuesta}</p>
                              </div>
                            ` : `
                              <p class="text-twine-300 text-sm italic text-center py-3">
                                Sin respuesta detallada
                              </p>
                            `}
                          </div>
                        `;
                      }).join('')}
                    </div>
                  </div>
                ` : `
                  <!-- Estado sin respuestas -->
                  <div class="text-center py-8">
                    <div class="text-5xl text-twine-500/20 mb-4">📝</div>
                    <h4 class="text-white font-patria font-medium text-lg mb-2">Aún no hay respuestas</h4>
                    <p class="text-twine-300 font-patria text-sm">
                      Esta encuesta no ha recibido respuestas aún.
                    </p>
                  </div>
                `}
                
                <!-- Sección de consejos (igual que InfoModal) -->
                <div class="bg-twine-500/10 border border-twine-400/20 rounded-xl p-4">
                  <h4 class="text-white font-patria font-semibold text-lg mb-2">💡 Consejos</h4>
                  <p class="text-twine-200 font-patria text-sm">
                    Puedes exportar todas las respuestas en formato CSV para análisis externos. Solo se muestran las respuestas anónimas como "Usuario Anónimo".
                  </p>
                </div>
              </div>
            </div>

            <!-- Footer del modal (igual que InfoModal) -->
            <div class="bg-white/5 border-t border-white/10 px-6 py-4 flex-shrink-0">
              <div class="flex justify-end">
                <button id="footerCloseBtn" class="bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-6 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm">
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      `;

      // Crear e insertar el modal
      const modal = document.createElement('div');
      modal.innerHTML = modalHtml;
      document.body.appendChild(modal);
      document.body.style.overflow = 'hidden';

      // Agregar funcionalidad al botón de exportar
      const exportBtn = modal.querySelector('#exportExcelBtn');
      if (exportBtn) {
        exportBtn.addEventListener('click', () => {
          exportToExcel(data);
        });
      }

      // Agregar funcionalidad a los botones de cerrar
      const closeModal = () => {
        document.body.removeChild(modal);
        document.body.style.overflow = '';
        document.removeEventListener('keydown', handleEscape);
      };

      modal.querySelector('#closeModalBtn').addEventListener('click', closeModal);
      modal.querySelector('#footerCloseBtn').addEventListener('click', closeModal);

      // Cerrar al hacer clic fuera del modal
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          closeModal();
        }
      });

      // Cerrar con la tecla Escape
      const handleEscape = (e) => {
        if (e.key === 'Escape') {
          closeModal();
        }
      };
      document.addEventListener('keydown', handleEscape);

    } else {
      const errorData = await response.json();
      if (response.status === 403) {
        alert(`Acceso restringido: ${errorData.detail}\n\nSolo el creador de la encuesta puede ver las respuestas detalladas.`);
      } else {
        alert(errorData.detail || 'Error al cargar las respuestas');
      }
    }
  } catch (error) {
    console.error('Error al obtener respuestas:', error);
    alert('Error al obtener respuestas. Por favor, intenta nuevamente.');
  }
};

  const getAuthorColor = (userType, role) => {
    const colors = {
      docente: 'from-twine-400 to-twine-600',
      alumno: 'from-twine-400 to-twine-600',
      tutor: 'from-twine-400 to-twine-600',
      director: 'from-night-400 to-night-600',
      administrativo: 'from-night-400 to-night-600',
      admin: 'from-night-400 to-night-600'
    };
    return colors[userType] || 'from-twine-400 to-twine-600';
  };

  const getTypeColor = (type) => {
    const colors = {
      publicacion: 'bg-twine-500/20 text-twine-300 border-twine-400/30',
      encuesta: 'bg-yellow-500/20 text-yellow-300 border-yellow-400/30'
    };
    return colors[type] || 'bg-twine-500/20 text-twine-300 border-twine-400/30';
  };

  const getTypeLabel = (type) => {
    const labels = {
      publicacion: 'Publicación',
      encuesta: 'Encuesta'
    };
    return labels[type] || type;
  };

  // Función para obtener etiqueta de tipo de pregunta
  const getQuestionTypeLabel = (tipo) => {
    const labels = {
      'texto_libre': 'Texto libre',
      'seleccion_unica': 'Selección única',
      'opcion_multiple': 'Opción múltiple',
      'escala': 'Escala'
    };
    return labels[tipo] || tipo;
  };

  // Función para obtener icono de tipo de pregunta
  const getQuestionTypeIcon = (tipo) => {
    switch (tipo) {
      case 'texto_libre': return DocumentTextIcon;
      case 'seleccion_unica': return CircleStackIcon;
      case 'opcion_multiple': return ListBulletIcon;
      case 'escala': return ChartBarSquareIcon;
      default: return QuestionMarkCircleIcon;
    }
  };

  const feedItems = getCommunityFeed();

  const filteredItems = activeFilter === 'todos'
    ? feedItems
    : activeFilter === 'destacadas'
    ? feedItems.filter(item => item.es_destacado)
    : activeFilter === 'publicacion'
    ? feedItems.filter(item => item.combinedType === 'publicacion')
    : feedItems.filter(item => item.combinedType === 'encuesta');

  const filters = [
    { key: 'todos', label: 'Todas', count: feedItems.length, icon: HomeIcon },
    { key: 'destacadas', label: 'Destacadas', count: feedItems.filter(item => item.es_destacado).length, icon: FireIcon },
    { key: 'publicacion', label: 'Publicaciones', count: feedItems.filter(item => item.combinedType === 'publicacion').length, icon: ChatBubbleLeftRightIcon },
    { key: 'encuesta', label: 'Encuestas', count: feedItems.filter(item => item.combinedType === 'encuesta').length, icon: ChartBarIcon }
  ];

  if (loading) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl sm:rounded-2xl p-6 border border-white/20 mx-2 sm:mx-0">
        <div className="text-center py-12">
          <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20 animate-pulse">
            <ArrowPathIcon className="w-8 h-8 text-twine-400 animate-spin" />
          </div>
          <p className="text-twine-200 font-patria text-lg mb-2">Cargando contenido...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl sm:rounded-2xl p-6 border border-white/20 mx-2 sm:mx-0">
        <div className="text-center py-12">
          <div className="w-16 h-16 sm:w-20 sm:h-20 bg-red-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-400/30">
            <ExclamationCircleIcon className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-red-200 font-patria text-lg mb-2">Error al cargar</p>
          <p className="text-red-300 font-patria text-sm mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="flex items-center space-x-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm"
          >
            <ArrowPathIcon className="w-4 h-4" />
            <span>Reintentar</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl sm:rounded-2xl p-3 sm:p-4 md:p-6 border border-white/20 mx-2 sm:mx-0">
      {/* Header y controles */}
      <div className="mb-4 sm:mb-6">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 sm:gap-0">
          <div>
            <div className="flex items-center space-x-2">
              <HomeIcon className="w-6 h-6 text-white" />
              <h2 className="text-xl sm:text-2xl font-patria font-bold text-white">Comunidad SIVOD</h2>
            </div>
            {currentUser && (
              <div className="flex items-center flex-wrap gap-2 mt-2">
                <div className="flex items-center space-x-1">
                  <UserCircleIcon className="w-4 h-4 text-twine-300" />
                  <p className="text-twine-200 font-patria text-sm sm:text-base">
                    Bienvenido, <span className="text-white font-semibold">{currentUser.nombre} {currentUser.ape_pa}</span>
                  </p>
                </div>
                <span className="text-twine-300">•</span>
                <div className="flex items-center space-x-1">
                  <AcademicCapIcon className="w-4 h-4 text-twine-300" />
                  <span className="text-twine-300">{getUserRoleLabel(currentUser.userType, currentUser.role)}</span>
                </div>
                {currentUser.escuela_nombre && (
                  <>
                    <span className="text-twine-300">•</span>
                    <div className="flex items-center space-x-1">
                      <UserIcon className="w-4 h-4 text-green-300" />
                      <span className="text-green-300">{currentUser.escuela_nombre}</span>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="flex space-x-2 mt-2 sm:mt-0">
            {canCreatePublication() && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center space-x-1 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-3 sm:px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm w-full sm:w-auto"
              >
                <PlusIcon className="w-4 h-4" />
                <span>Nueva Publicación</span>
              </button>
            )}

            {canCreateSurvey() && (
              <button
                onClick={() => setShowCreateSurveyModal(true)}
                className="flex items-center space-x-1 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-3 sm:px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm w-full sm:w-auto"
              >
                <PlusIcon className="w-4 h-4" />
                <span>Nueva Encuesta</span>
              </button>
            )}
          </div>
        </div>

        <div className="mt-4 bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 backdrop-blur-md rounded-xl p-3 sm:p-4 border border-yellow-400/20">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
              <StarIconSolid className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-patria text-sm sm:text-base">
                <span className="text-yellow-300 font-bold">Publicaciones destacadas</span>
                <span className="text-yellow-200 ml-2">
                  Las publicaciones con 50 o más likes se convierten automáticamente en destacadas
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filtros */}
      <div className="mb-4 sm:mb-6">
        <div className="flex space-x-2 sm:space-x-4 overflow-x-auto pb-2 scrollbar-hide">
          {filters.map((filter) => {
            const Icon = filter.icon;
            return (
              <button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                className={`flex items-center space-x-1 px-3 py-2 rounded-xl font-patria transition-all duration-300 whitespace-nowrap text-xs sm:text-sm ${
                  activeFilter === filter.key
                    ? filter.key === 'destacadas' || filter.key === 'encuesta'
                      ? 'bg-yellow-500/20 text-white border border-yellow-400/30'
                      : 'bg-twine-500/20 text-white border border-twine-400/30'
                    : 'bg-white/5 text-twine-200 hover:bg-white/10 hover:text-white border border-white/10'
                }`}
              >
                <Icon className="w-3 h-3 sm:w-4 sm:h-4" />
                <span>{filter.label}</span>
                <span className="bg-white/20 px-1.5 py-0.5 rounded-full text-xs">
                  {filter.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Contenido del feed */}
      <div className="space-y-4 sm:space-y-6">
        {filteredItems.length === 0 ? (
          <div className="text-center py-8 sm:py-12">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/10 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 border border-white/20">
              {activeFilter === 'encuesta' ? (
                <ChartBarIcon className="w-8 h-8 text-twine-400" />
              ) : activeFilter === 'publicacion' ? (
                <ChatBubbleLeftRightIcon className="w-8 h-8 text-twine-400" />
              ) : activeFilter === 'destacadas' ? (
                <FireIcon className="w-8 h-8 text-yellow-400" />
              ) : (
                <InformationCircleIcon className="w-8 h-8 text-twine-400" />
              )}
            </div>
            <p className="text-twine-200 font-patria text-base sm:text-lg mb-2">
              No hay {activeFilter !== 'todos' ? activeFilter : 'actividades'}
            </p>
            <p className="text-twine-300 font-patria text-xs sm:text-sm px-4">
              {activeFilter === 'publicacion'
                ? 'Sé el primero en compartir algo con la comunidad educativa.'
                : activeFilter === 'encuesta'
                ? 'Aún no hay encuestas. ¡Crea la primera!'
                : activeFilter === 'destacadas'
                ? 'Aún no hay publicaciones destacadas. ¡Da likes a las publicaciones!'
                : 'Pronto habrá nuevas actividades en la comunidad.'
              }
            </p>
            {(canCreatePublication() && activeFilter === 'publicacion') && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center space-x-1 mt-4 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm mx-auto"
              >
                <PlusIcon className="w-4 h-4" />
                <span>Crear primera publicación</span>
              </button>
            )}
            {(canCreateSurvey() && activeFilter === 'encuesta') && (
              <button
                onClick={() => setShowCreateSurveyModal(true)}
                className="flex items-center space-x-1 mt-4 bg-gradient-to-r from-yellow-500/90 to-yellow-600/90 backdrop-blur-sm border border-yellow-400 text-white px-4 py-2 rounded-xl hover:from-yellow-600 hover:to-yellow-700 transition-all duration-300 font-patria text-sm mx-auto"
              >
                <PlusIcon className="w-4 h-4" />
                <span>Crear primera encuesta</span>
              </button>
            )}
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={`${item.combinedType}-${item.id}`}
              className={`bg-white/10 backdrop-blur-md rounded-xl sm:rounded-2xl p-3 sm:p-4 md:p-6 border transition-all duration-300 hover:border-white/30 relative ${
                item.combinedType === 'encuesta'
                  ? 'border-yellow-500/40 bg-gradient-to-br from-white/10 to-yellow-500/5'
                  : item.es_destacado
                    ? 'border-yellow-500/40 bg-gradient-to-br from-white/10 to-yellow-500/5'
                    : 'border-white/20'
              }`}
            >
              {item.combinedType === 'encuesta' && (
                <div className="absolute -top-2 -right-2 z-10">
                  <div className="flex items-center space-x-1 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white px-3 py-1 rounded-full text-xs font-bold font-patria shadow-lg border border-yellow-400">
                    <ChartBarIcon className="w-3 h-3" />
                    <span>ENCUESTA</span>
                  </div>
                </div>
              )}

              {item.es_destacado && item.combinedType === 'publicacion' && (
                <div className="absolute -top-2 -right-2 z-10">
                  <div className="flex items-center space-x-1 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white px-3 py-1 rounded-full text-xs font-bold font-patria shadow-lg border border-yellow-400">
                    <StarIconSolid className="w-3 h-3" />
                    <span>DESTACADO</span>
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-start justify-between mb-3 sm:mb-4 gap-2 sm:gap-0">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 relative">
                    <div className={`w-full h-full ${item.author?.foto ? '' : `bg-gradient-to-r ${getAuthorColor(item.author?.userType || 'educativo')}`} rounded-xl flex items-center justify-center overflow-hidden`}>
                      {item.author?.foto ? (
                        <img 
                          src={item.author.fotoUrl}
                          alt={item.author.name}
                          className="w-full h-full object-cover rounded-xl"
                          onError={(e) => {
                            console.error('Error cargando foto de perfil:', e);
                            e.target.style.display = 'none';
                            const initialsSpan = document.createElement('span');
                            initialsSpan.className = 'text-white font-bold text-sm';
                            initialsSpan.textContent = item.author?.avatar || 'US';
                            e.target.parentElement.appendChild(initialsSpan);
                          }}
                        />
                      ) : (
                        <span className="text-white font-bold text-sm">
                          {item.author?.avatar || 'US'}
                        </span>
                      )}
                    </div>
                    
                    {item.author?.isCurrentUser && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 bg-green-500 rounded-full border-2 border-white z-10"></div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-white font-patria font-semibold text-sm sm:text-base truncate">
                        {item.author?.name || item.creador_nombre || 'Usuario'}
                      </h3>
                      {item.author?.isCurrentUser && (
                        <span className="flex items-center space-x-1 px-1.5 py-0.5 bg-green-500/20 text-green-300 rounded-full text-xs font-patria">
                          <UserCircleIcon className="w-3 h-3" />
                          <span>Tú</span>
                        </span>
                      )}
                      {item.combinedType === 'encuesta' && isSurveyCreator(item) && (
                        <span className="flex items-center space-x-1 px-1.5 py-0.5 bg-yellow-500/20 text-yellow-300 rounded-full text-xs font-patria">
                          <StarIcon className="w-3 h-3" />
                          <span>Creador</span>
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-2 text-twine-200 text-xs sm:text-sm font-patria truncate">
                      <AcademicCapIcon className="w-3 h-3" />
                      <span>{item.author?.role || item.autor_rol || 'Usuario'}</span>
                      <span>•</span>
                      <ClockIcon className="w-3 h-3" />
                      <span>{new Date(item.fecha_creacion || item.fecha).toLocaleDateString('es-MX', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row items-end sm:items-center gap-1 sm:gap-2">
                  <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-patria font-bold ${getTypeColor(item.type)} self-end sm:self-auto mt-1 sm:mt-0`}>
                    {item.type === 'encuesta' ? (
                      <ChartBarIcon className="w-3 h-3" />
                    ) : (
                      <ChatBubbleLeftRightIcon className="w-3 h-3" />
                    )}
                    <span>{getTypeLabel(item.type)}</span>
                  </span>
                </div>
              </div>

              <h4 className="flex items-center text-white font-patria font-semibold text-base sm:text-lg mb-2 sm:mb-3 overflow-hidden text-ellipsis line-clamp-2">
                {item.titulo}
                {item.es_destacado && item.combinedType === 'publicacion' && (
                  <StarIconSolid className="ml-2 w-4 h-4 text-yellow-300" />
                )}
              </h4>

              {item.combinedType === 'publicacion' ? (
                <>
                  <p className="text-twine-200 font-patria mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base">
                    {item.contenido}
                  </p>

                  {item.imagen_url && (
                    <div className="mb-3 sm:mb-4">
                      <img
                        src={`${API_URL}${item.imagen_url}`}
                        alt={item.titulo}
                        className="w-full h-48 sm:h-64 object-cover rounded-xl border border-white/10"
                        onError={(e) => {
                          e.target.style.display = 'none';
                        }}
                      />
                    </div>
                  )}

                  {item.etiquetas && item.etiquetas.length > 0 && (
                    <div className="flex flex-wrap gap-1 sm:gap-2 mb-3 sm:mb-4">
                      {item.etiquetas.map((etiqueta, index) => (
                        <span
                          key={index}
                          className="px-2 sm:px-3 py-1 bg-white/5 rounded-full text-xs text-twine-300 font-patria border border-white/10"
                        >
                          #{etiqueta}
                        </span>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                // SECCIÓN DE ENCUESTA - NUEVA ESTRUCTURA
                <div className="space-y-3 sm:space-y-4">
                  {item.descripcion && (
                    <p className="text-twine-200 font-patria mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base bg-white/5 p-3 rounded-xl border border-white/10">
                      {item.descripcion}
                    </p>
                  )}

                  {/* Información de la encuesta */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                    <div className="bg-yellow-500/10 backdrop-blur-md rounded-xl p-3 border border-yellow-400/20">
                      <div className="flex items-center space-x-2 mb-1">
                        <QuestionMarkCircleIcon className="w-4 h-4 text-yellow-300" />
                        <span className="text-white font-patria text-sm font-semibold">Preguntas:</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-yellow-300 font-patria text-lg font-bold">
                          {item.total_preguntas || 1}
                        </span>
                        <span className="text-yellow-200 text-xs">
                          {item.total_preguntas === 1 ? 'pregunta' : 'preguntas'}
                        </span>
                      </div>
                      {item.tipos_preguntas && item.tipos_preguntas.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {item.tipos_preguntas.map((tipo, idx) => {
                            const Icon = getQuestionTypeIcon(tipo);
                            return (
                              <span key={idx} className="flex items-center space-x-1 px-2 py-1 bg-yellow-500/20 rounded-full text-xs text-yellow-200">
                                <Icon className="w-3 h-3" />
                                <span>{getQuestionTypeLabel(tipo)}</span>
                              </span>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    <div className="bg-twine-500/10 backdrop-blur-md rounded-xl p-3 border border-twine-400/20">
                      <div className="flex items-center space-x-2 mb-1">
                        <UserGroupIcon className="w-4 h-4 text-twine-300" />
                        <span className="text-white font-patria text-sm font-semibold">Pueden responder:</span>
                      </div>
                      <p className="text-twine-200 text-sm truncate" title={item.usuarios_permitidos}>
                        {item.usuarios_permitidos}
                      </p>
                      {item.permite_anonimo && (
                        <span className="inline-block mt-1 px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded-full text-xs">
                          Respuestas anónimas
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Muestra la primera pregunta como vista previa */}
                  <div className="p-4 bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 backdrop-blur-md rounded-xl border border-yellow-400/20 mb-4">
                    <div className="flex items-center space-x-2 mb-2">
                      {item.icono ? (
                        <item.icono className="w-5 h-5 text-yellow-300" />
                      ) : (
                        <ChartBarIcon className="w-5 h-5 text-yellow-300" />
                      )}
                      <h4 className="text-white font-patria font-semibold text-base">
                        {item.total_preguntas === 1 ? 'Pregunta:' : 'Vista previa de preguntas:'}
                      </h4>
                    </div>
                    {item.total_preguntas === 1 ? (
                      <p className="text-white font-patria text-lg pl-7">
                        "{item.primera_pregunta}"
                      </p>
                    ) : (
                      <div className="pl-7">
                        <p className="text-white font-patria mb-2">
                          "{item.primera_pregunta}"
                        </p>
                        <p className="text-yellow-200 text-sm">
                          + {item.total_preguntas - 1} pregunta{item.total_preguntas - 1 > 1 ? 's' : ''} más
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {item.combinedType === 'publicacion' ? (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 sm:pt-4 border-t border-white/10 gap-2 sm:gap-0">
                  <div className="flex items-center space-x-4 sm:space-x-6">
                    <button
                      onClick={() => handleLikePublication(item.id, item.likes)}
                      disabled={likingPublication === item.id}
                      className="flex items-center space-x-1 sm:space-x-2 text-twine-200 hover:text-white transition-colors duration-300 font-patria text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {item.likes >= 50 ? (
                        <StarIconSolid className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" />
                      ) : (
                        <HeartIcon className="w-4 h-4 sm:w-5 sm:h-5 text-twine-300 hover:text-red-400 transition-colors" />
                      )}
                      <span className={item.likes >= 50 ? 'text-yellow-300 font-bold' : ''}>
                        {item.likes || 0}
                      </span>
                    </button>
                    <div className="flex items-center space-x-1 sm:space-x-2 text-twine-200 font-patria text-sm">
                      <EyeIcon className="w-4 h-4 sm:w-5 sm:h-5 text-blue-300" />
                      <span>{item.vistas || 0} vistas</span>
                    </div>
                    <button
                      onClick={() => {
                        setShowComments(prev => ({
                          ...prev,
                          [item.id]: !prev[item.id]
                        }));
                        if (!showComments[item.id]) {
                          fetchComments(item.id);
                        }
                      }}
                      className="flex items-center space-x-1 sm:space-x-2 text-twine-200 hover:text-white transition-colors duration-300 font-patria text-sm"
                    >
                      <ChatBubbleLeftRightIcon className="w-4 h-4 sm:w-5 sm:h-5 text-green-300" />
                      <span>{item.total_comentarios || 0}</span>
                    </button>
                  </div>

                  {isPublicationAuthor(item) && (
                    <div className="flex space-x-2 self-end sm:self-auto mt-2 sm:mt-0">
                      <button
                        onClick={() => handleEditPublication(item)}
                        className="flex items-center space-x-1 px-3 py-1 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-colors duration-300 font-patria text-sm border border-blue-400/30"
                      >
                        <PencilIcon className="w-3 h-3" />
                        <span>Editar</span>
                      </button>
                      <button
                        onClick={() => handleDeletePublication(item.id, item.titulo)}
                        className="flex items-center space-x-1 px-3 py-1 bg-red-500/20 text-red-300 rounded-xl hover:bg-red-500/30 transition-colors duration-300 font-patria text-sm border border-red-400/30"
                      >
                        <TrashIcon className="w-3 h-3" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                // ACCIONES DE ENCUESTA
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 sm:pt-4 border-t border-white/10 gap-2 sm:gap-0">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 text-twine-200 font-patria text-sm">
                      <ChartBarSquareIcon className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-300" />
                      <span>{item.total_respuestas || 0} respuestas</span>
                    </div>

                    {item.max_respuestas && (
                      <div className="flex items-center space-x-2 text-twine-200 font-patria text-sm">
                        <UsersIcon className="w-4 h-4 sm:w-5 sm:h-5 text-blue-300" />
                        <span>Límite: {item.max_respuestas}</span>
                      </div>
                    )}

                    {item.fecha_cierre && (
                      <div className="flex items-center space-x-2 text-twine-200 font-patria text-sm">
                        <ClockIcon className="w-4 h-4 sm:w-5 sm:h-5 text-blue-300" />
                        <span>
                          Cierra: {new Date(item.fecha_cierre).toLocaleDateString('es-MX', {
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 self-end sm:self-auto mt-2 sm:mt-0">
                    {item.puede_responder && !item.usuario_ya_respondio && !item.esta_cerrada && (
                      <button
                        onClick={() => handleRespondSurvey(item)}
                        className="flex items-center space-x-1 px-3 py-1 bg-gradient-to-r from-twine-500 to-twine-600 text-white rounded-xl hover:from-twine-600 hover:to-twine-700 transition-colors duration-300 font-patria text-sm border border-twine-400"
                      >
                        <CheckCircleIcon className="w-3 h-3" />
                        <span>Participar</span>
                      </button>
                    )}

                    {item.usuario_ya_respondio && (
                      <span className="flex items-center space-x-1 px-3 py-1 bg-blue-500/20 text-blue-300 rounded-xl font-patria text-sm border border-blue-400/30">
                        <CheckCircleIconSolid className="w-3 h-3" />
                        <span>Ya participaste</span>
                      </span>
                    )}

                    {item.esta_cerrada && (
                      <span className="flex items-center space-x-1 px-3 py-1 bg-red-500/20 text-red-300 rounded-xl font-patria text-sm border border-red-400/30">
                        <XCircleIcon className="w-3 h-3" />
                        <span>Cerrada</span>
                      </span>
                    )}

                    {isSurveyCreator(item) && (
  <button
    onClick={() => handleViewSurveyStats(item.id, item.titulo)}
    className="flex items-center space-x-1 px-3 py-1 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-colors duration-300 font-patria text-sm border border-blue-400/30"
  >
    <ChartBarIcon className="w-3 h-3" />
    <span>Ver respuestas</span>  {/* Cambiado de "Ver estadísticas" a "Ver respuestas" */}
  </button>
)}

                    {isSurveyCreator(item) && (
                      <button
                        onClick={() => handleDeleteSurvey(item.id, item.titulo)}
                        className="flex items-center space-x-1 px-3 py-1 bg-red-500/20 text-red-300 rounded-xl hover:bg-red-500/30 transition-colors duration-300 font-patria text-sm border border-red-400/30"
                      >
                        <TrashIcon className="w-3 h-3" />
                        <span>Eliminar</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Sección de comentarios para publicaciones */}
              {item.combinedType === 'publicacion' && showComments[item.id] && (
                <div className="mt-4 pt-4 border-t border-white/10">
                  <h5 className="text-white font-patria font-semibold mb-3 flex items-center">
                    <ChatBubbleLeftRightIcon className="w-5 h-5 text-green-300 mr-2" />
                    Comentarios ({commentsData[item.id]?.length || 0})
                  </h5>
                  
                  <div className="space-y-3 mb-4 max-h-60 overflow-y-auto pr-2">
                    {(commentsData[item.id] || []).map(comment => (
                      <div key={comment.id_comentario} className="bg-white/5 p-3 rounded-xl border border-white/10">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-2">
                            <img 
                              src={comment.autor_foto ? `${API_URL}/uploads/photos/${comment.autor_foto}` : `${API_URL}/uploads/photos/Fotoperfil.jpg`}
                              alt={comment.autor_nombre}
                              className="w-8 h-8 rounded-full"
                              onError={(e) => {
                                e.target.src = `${API_URL}/uploads/photos/Fotoperfil.jpg`;
                              }}
                            />
                            <div>
                              <p className="text-white font-patria text-sm">
                                {comment.autor_nombre}
                                <span className="text-twine-300 text-xs ml-2">
                                  {comment.autor_rol}
                                </span>
                              </p>
                              <p className="text-twine-200 text-xs">
                                {new Date(comment.fecha_comentario).toLocaleDateString('es-MX', {
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </p>
                            </div>
                          </div>
                          
                          {(comment.es_mi_comentario || 
                            (currentUser && currentUser.userType === 'educativo' && currentUser.role === 'director')) && (
                            <button
                              onClick={() => handleDeleteComment(comment.id_comentario, item.id)}
                              className="text-red-300 hover:text-red-400"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <p className="text-twine-100 mt-2 text-sm">{comment.contenido}</p>
                      </div>
                    ))}
                    
                    {(commentsData[item.id] || []).length === 0 && (
                      <p className="text-twine-300 text-center text-sm py-4">
                        Sé el primero en comentar
                      </p>
                    )}
                  </div>
                  
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Escribe un comentario..."
                      className="flex-1 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-twine-400"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handlePostComment(item.id);
                        }
                      }}
                    />
                    <button
                      onClick={() => handlePostComment(item.id)}
                      disabled={!commentText.trim() || postingComment === item.id}
                      className="bg-gradient-to-r from-twine-500 to-twine-600 text-white px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {postingComment === item.id ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      ) : (
                        'Enviar'
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {filteredItems.length > 0 && feedItems.length > 0 && (
        <div className="text-center mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-white/10">
          <button className="flex items-center space-x-2 justify-center bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-xl hover:bg-white/20 transition-all duration-300 font-patria text-sm w-full sm:w-auto">
            <ArrowRightIcon className="w-4 h-4" />
            <span>Ver más actividades</span>
          </button>
        </div>
      )}

      {/* Modales */}
      {canCreatePublication() && (
        <CreatePublicationModal
          isOpen={showCreateModal}
          onClose={() => {
            setShowCreateModal(false);
            setEditingPublication(null);
          }}
          onSuccess={() => {
            setShowCreateModal(false);
            setEditingPublication(null);
            const token = localStorage.getItem('token') || localStorage.getItem('authToken');
            if (token) fetchPublications(token);
          }}
          apiUrl={API_URL}
          editingPublication={editingPublication}
        />
      )}

      {canCreateSurvey() && (
        <CreateSurveyModal
          isOpen={showCreateSurveyModal}
          onClose={() => setShowCreateSurveyModal(false)}
          onSuccess={() => {
            setShowCreateSurveyModal(false);
            const token = localStorage.getItem('token') || localStorage.getItem('authToken');
            if (token) fetchSurveys(token);
          }}
          apiUrl={API_URL}
        />
      )}

      <RespondSurveyModal
        isOpen={showRespondSurveyModal}
        onClose={() => {
          setShowRespondSurveyModal(false);
          setSelectedSurvey(null);
        }}
        onSuccess={() => {
          setShowRespondSurveyModal(false);
          setSelectedSurvey(null);
          const token = localStorage.getItem('token') || localStorage.getItem('authToken');
          if (token) fetchSurveys(token);
        }}
        apiUrl={API_URL}
        survey={selectedSurvey}
      />
    </div>
  );
};

export default CommunityFeed;