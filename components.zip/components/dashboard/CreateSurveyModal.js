import React, { useState, useEffect } from 'react';
import {
  XMarkIcon, PlusIcon, TrashIcon, DocumentTextIcon,
  CheckCircleIcon, CalendarDaysIcon, UserGroupIcon,
  ExclamationTriangleIcon, ListBulletIcon, CircleStackIcon,
  ChartBarIcon, LockClosedIcon, EyeIcon, EyeSlashIcon,
  InformationCircleIcon, ClockIcon, UsersIcon,
  FingerPrintIcon, ArrowRightIcon
} from '@heroicons/react/24/outline';

const CreateSurveyModal = ({ isOpen, onClose, onSuccess, apiUrl = 'http://localhost:8000' }) => {
  const [formData, setFormData] = useState({
    titulo: '',
    descripcion: '',
    tipo_encuesta: 'multiple',
    preguntas: [
      {
        texto_pregunta: '',
        tipo_pregunta: 'texto_libre',
        orden: 1,
        obligatoria: false,
        max_longitud: 2000,
        instrucciones: '',
        opciones: [],
        escala_min: 1,
        escala_max: 5,
        escala_etiqueta_min: 'Muy insatisfecho',
        escala_etiqueta_max: 'Muy satisfecho'
      }
    ],
    fecha_cierre: '',
    usuarios_permitidos: ['educativo', 'tutor'],
    permite_anonimo: false,
    es_obligatoria: false,
    max_respuestas: '',
    mostrar_resultados: true
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(-1); // Comenzar en configuración general
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);

  const userTypeOptions = [
    { value: 'educativo', label: 'Educativos (Maestros/Directores)', color: 'bg-blue-500' },
    { value: 'tutor', label: 'Tutores', color: 'bg-green-500' },
    { value: 'alumno', label: 'Alumnos', color: 'bg-yellow-500' },
    { value: 'administrativo', label: 'Administrativos', color: 'bg-purple-500' }
  ];

  const questionTypeOptions = [
    { value: 'texto_libre', label: 'Texto Libre', icon: DocumentTextIcon },
    { value: 'seleccion_unica', label: 'Selección Única', icon: CircleStackIcon },
    { value: 'opcion_multiple', label: 'Opción Múltiple', icon: ListBulletIcon },
    { value: 'escala', label: 'Escala', icon: ChartBarIcon }
  ];

  // Agregar nueva pregunta
  const addQuestion = () => {
    setFormData(prev => ({
      ...prev,
      preguntas: [
        ...prev.preguntas,
        {
          texto_pregunta: '',
          tipo_pregunta: 'texto_libre',
          orden: prev.preguntas.length + 1,
          obligatoria: false,
          max_longitud: 2000,
          instrucciones: '',
          opciones: [],
          escala_min: 1,
          escala_max: 5,
          escala_etiqueta_min: 'Muy insatisfecho',
          escala_etiqueta_max: 'Muy satisfecho'
        }
      ]
    }));
    setActiveQuestionIndex(formData.preguntas.length);
  };

  // Eliminar pregunta
  const removeQuestion = (index) => {
    if (formData.preguntas.length <= 1) {
      alert('Debe haber al menos una pregunta');
      return;
    }

    const newQuestions = formData.preguntas.filter((_, i) => i !== index)
      .map((q, i) => ({ ...q, orden: i + 1 }));

    setFormData(prev => ({
      ...prev,
      preguntas: newQuestions
    }));

    if (activeQuestionIndex >= newQuestions.length) {
      setActiveQuestionIndex(newQuestions.length - 1);
    }
  };

  // Actualizar pregunta
  const updateQuestion = (index, field, value) => {
    const newQuestions = [...formData.preguntas];
    
    // Si cambia el tipo de pregunta, limpiar opciones si es necesario
    if (field === 'tipo_pregunta') {
      if (value !== 'seleccion_unica' && value !== 'opcion_multiple') {
        newQuestions[index].opciones = [];
      }
    }
    
    newQuestions[index][field] = value;
    
    setFormData(prev => ({
      ...prev,
      preguntas: newQuestions
    }));
  };

  // Agregar opción a pregunta
  const addOption = (questionIndex) => {
    const newQuestions = [...formData.preguntas];
    const currentOptions = newQuestions[questionIndex].opciones || [];
    
    newQuestions[questionIndex].opciones = [
      ...currentOptions,
      {
        texto_opcion: '',
        valor: `opcion_${currentOptions.length + 1}`,
        orden: currentOptions.length + 1
      }
    ];
    
    setFormData(prev => ({
      ...prev,
      preguntas: newQuestions
    }));
  };

  // Actualizar opción
  const updateOption = (questionIndex, optionIndex, field, value) => {
    const newQuestions = [...formData.preguntas];
    newQuestions[questionIndex].opciones[optionIndex][field] = value;
    
    setFormData(prev => ({
      ...prev,
      preguntas: newQuestions
    }));
  };

  // Eliminar opción
  const removeOption = (questionIndex, optionIndex) => {
    const newQuestions = [...formData.preguntas];
    newQuestions[questionIndex].opciones = newQuestions[questionIndex]
      .opciones.filter((_, i) => i !== optionIndex)
      .map((opt, i) => ({ ...opt, orden: i + 1 }));
    
    setFormData(prev => ({
      ...prev,
      preguntas: newQuestions
    }));
  };

  // Formatear fecha para backend
  const formatDateTimeForBackend = (datetimeString) => {
    if (!datetimeString) return null;
    
    // Convertir de "YYYY-MM-DDTHH:MM" a "YYYY-MM-DD HH:MM:SS"
    const [datePart, timePart] = datetimeString.split('T');
    
    if (datePart && timePart) {
      // Asegurar que tenga formato completo HH:MM:SS
      const timeWithSeconds = timePart.includes(':') && timePart.split(':').length === 2
        ? `${timePart}:00`
        : timePart;
      
      return `${datePart} ${timeWithSeconds}`;
    }
    
    return null;
  };

  // Obtener fecha mínima (hoy + 1 día)
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().slice(0, 16); // Formato YYYY-MM-DDTHH:MM
  };

  // Obtener fecha máxima (1 mes desde hoy)
  const getMaxDate = () => {
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    return nextMonth.toISOString().slice(0, 16);
  };

  // Manejar envío del formulario
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validaciones
    if (!formData.titulo.trim()) {
      setError('El título es obligatorio');
      setLoading(false);
      return;
    }

    // Validar que haya al menos una pregunta
    if (formData.preguntas.length === 0) {
      setError('Debe agregar al menos una pregunta');
      setLoading(false);
      return;
    }

    // Validar preguntas
    for (let i = 0; i < formData.preguntas.length; i++) {
      const q = formData.preguntas[i];
      
      if (!q.texto_pregunta.trim()) {
        setError(`La pregunta ${i + 1} no tiene texto`);
        setLoading(false);
        return;
      }

      if (q.tipo_pregunta === 'seleccion_unica' || q.tipo_pregunta === 'opcion_multiple') {
        if (q.opciones.length < 2) {
          setError(`La pregunta "${q.texto_pregunta}" necesita al menos 2 opciones`);
          setLoading(false);
          return;
        }

        // Validar que todas las opciones tengan texto
        for (let j = 0; j < q.opciones.length; j++) {
          if (!q.opciones[j].texto_opcion.trim()) {
            setError(`La opción ${j + 1} de la pregunta "${q.texto_pregunta}" no tiene texto`);
            setLoading(false);
            return;
          }
        }
      }

      if (q.tipo_pregunta === 'escala' && q.escala_max <= q.escala_min) {
        setError(`La escala máxima debe ser mayor que la mínima en la pregunta "${q.texto_pregunta}"`);
        setLoading(false);
        return;
      }
    }

    // Validar fecha de cierre si se proporciona
    if (formData.fecha_cierre) {
      const selectedDate = new Date(formData.fecha_cierre);
      const now = new Date();
      
      if (selectedDate <= now) {
        setError('La fecha de cierre debe ser mayor a la fecha actual');
        setLoading(false);
        return;
      }
    }

    // Validar máximo de respuestas
    if (formData.max_respuestas && parseInt(formData.max_respuestas) < 1) {
      setError('El máximo de respuestas debe ser al menos 1');
      setLoading(false);
      return;
    }

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('No estás autenticado');
        setLoading(false);
        return;
      }

      // Preparar datos para enviar
      const requestData = {
        titulo: formData.titulo.trim(),
        descripcion: formData.descripcion?.trim() || null,
        tipo_encuesta: formData.tipo_encuesta,
        preguntas: formData.preguntas.map(q => ({
          texto_pregunta: q.texto_pregunta.trim(),
          tipo_pregunta: q.tipo_pregunta,
          orden: q.orden,
          obligatoria: q.obligatoria,
          max_longitud: q.max_longitud,
          instrucciones: q.instrucciones?.trim() || null,
          opciones: (q.tipo_pregunta === 'texto_libre' || q.tipo_pregunta === 'escala') 
            ? [] 
            : q.opciones.map(opt => ({
                texto_opcion: opt.texto_opcion.trim(),
                valor: opt.valor,
                orden: opt.orden
              })),
          escala_min: q.escala_min,
          escala_max: q.escala_max,
          escala_etiqueta_min: q.escala_etiqueta_min,
          escala_etiqueta_max: q.escala_etiqueta_max
        })),
        fecha_cierre: formData.fecha_cierre ? formatDateTimeForBackend(formData.fecha_cierre) : null,
        usuarios_permitidos: formData.usuarios_permitidos,
        permite_anonimo: formData.permite_anonimo,
        es_obligatoria: formData.es_obligatoria,
        max_respuestas: formData.max_respuestas ? parseInt(formData.max_respuestas) : null,
        mostrar_resultados: formData.mostrar_resultados
      };

      console.log('Enviando datos:', JSON.stringify(requestData, null, 2));

      const response = await fetch(`${apiUrl}/api/v1/surveys`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });

      const responseData = await response.json();

      if (response.ok) {
        alert('Encuesta creada exitosamente');
        onSuccess();
        onClose();
      } else {
        setError(responseData.detail || `Error ${response.status}: No se pudo crear la encuesta`);
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Error de conexión. Verifica que el servidor esté funcionando.');
    } finally {
      setLoading(false);
    }
  };

  // Efecto para resetear el formulario cuando se abre
  useEffect(() => {
    if (isOpen) {
      setFormData({
        titulo: '',
        descripcion: '',
        tipo_encuesta: 'multiple',
        preguntas: [
          {
            texto_pregunta: '',
            tipo_pregunta: 'texto_libre',
            orden: 1,
            obligatoria: false,
            max_longitud: 2000,
            instrucciones: '',
            opciones: [],
            escala_min: 1,
            escala_max: 5,
            escala_etiqueta_min: 'Muy insatisfecho',
            escala_etiqueta_max: 'Muy satisfecho'
          }
        ],
        fecha_cierre: '',
        usuarios_permitidos: ['educativo', 'tutor'],
        permite_anonimo: false,
        es_obligatoria: false,
        max_respuestas: '',
        mostrar_resultados: true
      });
      setActiveQuestionIndex(-1);
      setShowAdvancedSettings(false);
      setError('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentQuestion = activeQuestionIndex >= 0 ? formData.preguntas[activeQuestionIndex] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-gradient-to-b from-night-900 to-night-800 rounded-2xl border border-white/20 shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-twine-600 to-twine-800 px-6 py-4 border-b border-white/20 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-patria font-bold text-white">
                Crear Encuesta Avanzada
              </h3>
              <p className="text-white/80 text-sm font-patria">
                {formData.preguntas.length} pregunta(s) • {formData.usuarios_permitidos.length} tipo(s) de usuario(s)
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all"
              disabled={loading}
            >
              <XMarkIcon className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar - Lista de preguntas */}
          <div className="w-64 bg-night-800/50 border-r border-white/10 flex flex-col">
            <div className="p-4 border-b border-white/10">
              <h4 className="text-white font-patria font-semibold text-sm mb-3">
                Preguntas ({formData.preguntas.length})
              </h4>
              <div className="space-y-2">
                <button
                  onClick={() => setActiveQuestionIndex(-1)}
                  className={`w-full py-2 rounded-xl font-patria transition-all text-sm flex items-center justify-center space-x-2 ${
                    activeQuestionIndex === -1
                      ? 'bg-twine-600 text-white'
                      : 'bg-white/5 text-white hover:bg-white/10'
                  }`}
                >
                  <InformationCircleIcon className="w-4 h-4" />
                  <span>Configuración General</span>
                </button>
                <button
                  onClick={addQuestion}
                  className="w-full py-2 bg-twine-600/30 hover:bg-twine-600/50 text-white rounded-xl border border-twine-500/30 flex items-center justify-center space-x-2 transition-all text-sm"
                >
                  <PlusIcon className="w-4 h-4" />
                  <span>Agregar Pregunta</span>
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2">
              {formData.preguntas.map((q, index) => (
                <div
                  key={index}
                  className={`p-3 mb-2 rounded-xl cursor-pointer transition-all ${
                    activeQuestionIndex === index
                      ? 'bg-twine-600/30 border border-twine-500/50'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                  }`}
                  onClick={() => setActiveQuestionIndex(index)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 bg-twine-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-bold">{index + 1}</span>
                      </div>
                      <span className="text-white text-sm font-patria truncate">
                        {q.texto_pregunta || `Pregunta ${index + 1}`}
                      </span>
                    </div>
                    {formData.preguntas.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeQuestion(index);
                        }}
                        className="w-6 h-6 bg-red-500/20 hover:bg-red-500/30 rounded flex items-center justify-center"
                        disabled={loading}
                      >
                        <TrashIcon className="w-3 h-3 text-red-300" />
                      </button>
                    )}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    <span className="text-xs px-2 py-1 rounded-full bg-night-700 text-white/80 font-patria">
                      {questionTypeOptions.find(t => t.value === q.tipo_pregunta)?.label}
                    </span>
                    {q.obligatoria && (
                      <span className="text-xs px-2 py-1 rounded-full bg-red-500/20 text-red-300 font-patria">
                        Obligatoria
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contenido principal - Editor */}
          <div className="flex-1 overflow-y-auto p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Configuración general de la encuesta */}
              {activeQuestionIndex === -1 ? (
                <div className="space-y-6">
                  <div>
                    <label className="block text-white font-patria mb-2">
                      <DocumentTextIcon className="w-4 h-4 inline mr-2 text-twine-300" />
                      Título de la encuesta *
                    </label>
                    <input
                      type="text"
                      value={formData.titulo}
                      onChange={(e) => setFormData({...formData, titulo: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-twine-400 transition-all"
                      placeholder="Ej: Encuesta de satisfacción del curso 2024"
                      required
                      disabled={loading}
                    />
                  </div>

                  <div>
                    <label className="block text-white font-patria mb-2">
                      <InformationCircleIcon className="w-4 h-4 inline mr-2 text-twine-300" />
                      Descripción (opcional)
                    </label>
                    <textarea
                      value={formData.descripcion}
                      onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-twine-400 transition-all h-32"
                      placeholder="Describe el propósito de esta encuesta..."
                      disabled={loading}
                    />
                  </div>

                  <div>
                    <label className="block text-white font-patria mb-3">
                      <UserGroupIcon className="w-4 h-4 inline mr-2 text-twine-300" />
                      ¿Quién puede responder? *
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {userTypeOptions.map((type) => (
                        <label
                          key={type.value}
                          className={`p-3 rounded-xl border cursor-pointer transition-all ${
                            formData.usuarios_permitidos.includes(type.value)
                              ? 'bg-white/10 border-white/30'
                              : 'bg-white/5 border-white/10 hover:bg-white/10'
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                              formData.usuarios_permitidos.includes(type.value)
                                ? 'bg-twine-500 border-twine-500'
                                : 'bg-night-700 border-white/30'
                            }`}>
                              {formData.usuarios_permitidos.includes(type.value) && (
                                <CheckCircleIcon className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <div className="flex items-center space-x-2">
                              <div className={`w-3 h-3 rounded-full ${type.color}`}></div>
                              <span className="text-white text-sm font-patria">{type.label}</span>
                            </div>
                          </div>
                          <input
                            type="checkbox"
                            checked={formData.usuarios_permitidos.includes(type.value)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({
                                  ...formData,
                                  usuarios_permitidos: [...formData.usuarios_permitidos, type.value]
                                });
                              } else {
                                setFormData({
                                  ...formData,
                                  usuarios_permitidos: formData.usuarios_permitidos.filter(t => t !== type.value)
                                });
                              }
                            }}
                            className="hidden"
                            disabled={loading}
                          />
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Sección de configuración avanzada */}
                  <div>
                    <button
                      type="button"
                      onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
                      className="flex items-center text-white font-patria text-sm mb-3 hover:text-twine-300 transition-colors"
                    >
                      <ArrowRightIcon className={`w-4 h-4 mr-2 transition-transform ${showAdvancedSettings ? 'rotate-90' : ''}`} />
                      Configuración Avanzada
                    </button>
                    
                    {showAdvancedSettings && (
                      <div className="space-y-4 p-4 bg-white/5 rounded-xl border border-white/10">
                        {/* Fecha de cierre */}
                        <div>
                          <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                            <CalendarDaysIcon className="w-4 h-4 text-twine-300" />
                            <span>Fecha de cierre (opcional)</span>
                          </label>
                          <input
                            type="datetime-local"
                            value={formData.fecha_cierre}
                            onChange={(e) => setFormData({...formData, fecha_cierre: e.target.value})}
                            min={getMinDate()}
                            max={getMaxDate()}
                            className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                            disabled={loading}
                          />
                          {formData.fecha_cierre && (
                            <p className="text-twine-300 text-xs mt-1 font-patria flex items-center space-x-1">
                              <ClockIcon className="w-3 h-3" />
                              <span>Se cerrará el: {new Date(formData.fecha_cierre).toLocaleString()}</span>
                            </p>
                          )}
                        </div>

                        {/* Máximo de respuestas */}
                        <div>
                          <label className="flex items-center space-x-2 text-white font-patria mb-2 text-sm">
                            <UsersIcon className="w-4 h-4 text-twine-300" />
                            <span>Límite de respuestas (opcional)</span>
                          </label>
                          <input
                            type="number"
                            min="1"
                            value={formData.max_respuestas}
                            onChange={(e) => setFormData({...formData, max_respuestas: e.target.value})}
                            className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                            placeholder="Sin límite"
                            disabled={loading}
                          />
                        </div>

                        {/* Opciones adicionales */}
                        <div className="space-y-3">
                          <label className="flex items-center cursor-pointer">
                            <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center ${
                              formData.permite_anonimo ? 'bg-twine-500 border-twine-500' : 'bg-white/10 border-white/30'
                            }`}>
                              {formData.permite_anonimo && (
                                <CheckCircleIcon className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <div>
                              <span className="text-white font-patria text-sm">
                                Permitir respuestas anónimas
                              </span>
                              <p className="text-white/60 text-xs font-patria">
                                Los usuarios podrán responder sin revelar su identidad
                              </p>
                            </div>
                            <input
                              type="checkbox"
                              checked={formData.permite_anonimo}
                              onChange={(e) => setFormData({...formData, permite_anonimo: e.target.checked})}
                              className="hidden"
                              disabled={loading}
                            />
                          </label>

                          <label className="flex items-center cursor-pointer">
                            <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center ${
                              formData.mostrar_resultados ? 'bg-twine-500 border-twine-500' : 'bg-white/10 border-white/30'
                            }`}>
                              {formData.mostrar_resultados && (
                                <CheckCircleIcon className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <div>
                              <span className="text-white font-patria text-sm">
                                Mostrar resultados después de responder
                              </span>
                              <p className="text-white/60 text-xs font-patria">
                                Los usuarios podrán ver los resultados después de enviar su respuesta
                              </p>
                            </div>
                            <input
                              type="checkbox"
                              checked={formData.mostrar_resultados}
                              onChange={(e) => setFormData({...formData, mostrar_resultados: e.target.checked})}
                              className="hidden"
                              disabled={loading}
                            />
                          </label>

                          <label className="flex items-center cursor-pointer">
                            <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center ${
                              formData.es_obligatoria ? 'bg-twine-500 border-twine-500' : 'bg-white/10 border-white/30'
                            }`}>
                              {formData.es_obligatoria && (
                                <ExclamationTriangleIcon className="w-3 h-3 text-red-300" />
                              )}
                            </div>
                            <div>
                              <span className="text-white font-patria text-sm">
                                Encuesta obligatoria
                              </span>
                              <p className="text-white/60 text-xs font-patria">
                                Los usuarios deben responder para acceder a ciertas funciones
                              </p>
                            </div>
                            <input
                              type="checkbox"
                              checked={formData.es_obligatoria}
                              onChange={(e) => setFormData({...formData, es_obligatoria: e.target.checked})}
                              className="hidden"
                              disabled={loading}
                            />
                          </label>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                /* Editor de pregunta específica */
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-patria font-bold text-white">
                      Pregunta {currentQuestion.orden}
                    </h3>
                    <div className="flex items-center space-x-3">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                          currentQuestion.obligatoria
                            ? 'bg-red-500/20 border-red-400'
                            : 'bg-white/10 border-white/30'
                        }`}>
                          {currentQuestion.obligatoria && (
                            <ExclamationTriangleIcon className="w-3 h-3 text-red-300" />
                          )}
                        </div>
                        <span className="text-white text-sm font-patria">Obligatoria</span>
                        <input
                          type="checkbox"
                          checked={currentQuestion.obligatoria}
                          onChange={(e) => updateQuestion(activeQuestionIndex, 'obligatoria', e.target.checked)}
                          className="hidden"
                          disabled={loading}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Texto de la pregunta */}
                  <div>
                    <label className="block text-white font-patria mb-2">Texto de la pregunta *</label>
                    <input
                      type="text"
                      value={currentQuestion.texto_pregunta}
                      onChange={(e) => updateQuestion(activeQuestionIndex, 'texto_pregunta', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-twine-400 transition-all"
                      placeholder="Ej: ¿Cómo calificarías el contenido del curso?"
                      required
                      disabled={loading}
                    />
                  </div>

                  {/* Tipo de pregunta */}
                  <div>
                    <label className="block text-white font-patria mb-3">Tipo de respuesta</label>
                    <div className="grid grid-cols-2 gap-3">
                      {questionTypeOptions.map((type) => {
                        const Icon = type.icon;
                        return (
                          <label
                            key={type.value}
                            className={`p-4 rounded-xl border cursor-pointer transition-all ${
                              currentQuestion.tipo_pregunta === type.value
                                ? 'bg-white/10 border-white/30'
                                : 'bg-white/5 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <Icon className="w-5 h-5 text-twine-300" />
                              <span className="text-white text-sm font-patria">{type.label}</span>
                            </div>
                            <input
                              type="radio"
                              value={type.value}
                              checked={currentQuestion.tipo_pregunta === type.value}
                              onChange={(e) => updateQuestion(activeQuestionIndex, 'tipo_pregunta', e.target.value)}
                              className="hidden"
                              disabled={loading}
                            />
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Opciones para selección única/múltiple */}
                  {(currentQuestion.tipo_pregunta === 'seleccion_unica' || 
                    currentQuestion.tipo_pregunta === 'opcion_multiple') && (
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <label className="text-white font-patria">
                          Opciones de respuesta *
                          <span className="text-white/60 text-xs ml-2">
                            (Mínimo 2)
                          </span>
                        </label>
                        <button
                          type="button"
                          onClick={() => addOption(activeQuestionIndex)}
                          className="px-3 py-1 bg-twine-600/50 hover:bg-twine-600/70 text-white rounded-lg text-sm font-patria transition-all disabled:opacity-50"
                          disabled={loading}
                        >
                          + Agregar opción
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        {currentQuestion.opciones.map((option, index) => (
                          <div key={index} className="flex items-center space-x-3">
                            <div className="flex-1">
                              <input
                                type="text"
                                value={option.texto_opcion}
                                onChange={(e) => updateOption(activeQuestionIndex, index, 'texto_opcion', e.target.value)}
                                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                                placeholder={`Opción ${index + 1}`}
                                required
                                disabled={loading}
                              />
                            </div>
                            {currentQuestion.opciones.length > 2 && (
                              <button
                                type="button"
                                onClick={() => removeOption(activeQuestionIndex, index)}
                                className="w-8 h-8 bg-red-500/20 hover:bg-red-500/30 rounded-lg flex items-center justify-center disabled:opacity-50"
                                disabled={loading}
                              >
                                <TrashIcon className="w-4 h-4 text-red-300" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Configuración para escala */}
                  {currentQuestion.tipo_pregunta === 'escala' && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white font-patria mb-2">Valor mínimo</label>
                        <input
                          type="number"
                          min="1"
                          max="10"
                          value={currentQuestion.escala_min}
                          onChange={(e) => updateQuestion(activeQuestionIndex, 'escala_min', parseInt(e.target.value))}
                          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                          disabled={loading}
                        />
                      </div>
                      <div>
                        <label className="block text-white font-patria mb-2">Valor máximo</label>
                        <input
                          type="number"
                          min="2"
                          max="10"
                          value={currentQuestion.escala_max}
                          onChange={(e) => updateQuestion(activeQuestionIndex, 'escala_max', parseInt(e.target.value))}
                          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                          disabled={loading}
                        />
                      </div>
                      <div>
                        <label className="block text-white font-patria mb-2">Etiqueta mínima</label>
                        <input
                          type="text"
                          value={currentQuestion.escala_etiqueta_min}
                          onChange={(e) => updateQuestion(activeQuestionIndex, 'escala_etiqueta_min', e.target.value)}
                          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                          disabled={loading}
                        />
                      </div>
                      <div>
                        <label className="block text-white font-patria mb-2">Etiqueta máxima</label>
                        <input
                          type="text"
                          value={currentQuestion.escala_etiqueta_max}
                          onChange={(e) => updateQuestion(activeQuestionIndex, 'escala_etiqueta_max', e.target.value)}
                          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                          disabled={loading}
                        />
                      </div>
                    </div>
                  )}

                  {/* Instrucciones adicionales */}
                  <div>
                    <label className="block text-white font-patria mb-2">Instrucciones (opcional)</label>
                    <textarea
                      value={currentQuestion.instrucciones}
                      onChange={(e) => updateQuestion(activeQuestionIndex, 'instrucciones', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all h-20"
                      placeholder="Instrucciones específicas para esta pregunta..."
                      disabled={loading}
                    />
                  </div>

                  {/* Configuración específica por tipo */}
                  {currentQuestion.tipo_pregunta === 'texto_libre' && (
                    <div>
                      <label className="block text-white font-patria mb-2">
                        Límite de caracteres
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="5000"
                        value={currentQuestion.max_longitud}
                        onChange={(e) => updateQuestion(activeQuestionIndex, 'max_longitud', parseInt(e.target.value))}
                        className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-twine-400 transition-all"
                        disabled={loading}
                      />
                      <p className="text-white/60 text-xs mt-1 font-patria">
                        Máximo de caracteres permitidos en la respuesta
                      </p>
                    </div>
                  )}
                </div>
              )}

              {error && (
                <div className="mb-4 p-4 bg-red-500/20 border border-red-400/30 rounded-xl flex items-start space-x-3">
                  <div className="w-5 h-5 bg-red-500/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <ExclamationTriangleIcon className="w-3 h-3 text-red-200" />
                  </div>
                  <p className="text-red-200 text-sm font-patria">{error}</p>
                </div>
              )}

              {/* Footer con botones de navegación y acción */}
              <div className="flex items-center justify-between pt-6 border-t border-white/10">
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setActiveQuestionIndex(-1)}
                    className={`px-4 py-2 rounded-xl font-patria transition-all disabled:opacity-50 ${
                      activeQuestionIndex === -1
                        ? 'bg-twine-600 text-white'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                    disabled={loading}
                  >
                    <InformationCircleIcon className="w-4 h-4 inline mr-2" />
                    Configuración General
                  </button>
                </div>
                
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-patria transition-all border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={loading}
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-6 py-2 bg-gradient-to-r from-twine-500 to-twine-600 hover:from-twine-600 hover:to-twine-700 text-white rounded-xl font-patria transition-all border border-twine-400 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>Creando...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircleIcon className="w-4 h-4" />
                        <span>Crear Encuesta</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateSurveyModal;