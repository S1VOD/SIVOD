import React, { useState, useEffect } from 'react';
import { ScaleIcon } from '@heroicons/react/24/outline';

const RespondSurveyModal = ({ isOpen, onClose, onSuccess, apiUrl = 'http://localhost:8000', survey }) => {
  const [respuestas, setRespuestas] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentStep, setCurrentStep] = useState(0);
  const [anonimo, setAnonimo] = useState(false);

  useEffect(() => {
    if (isOpen && survey) {
      // Inicializar respuestas vacías
      const initialRespuestas = {};
      survey.preguntas.forEach(pregunta => {
        if (pregunta.tipo_pregunta === 'seleccion_unica') {
          initialRespuestas[pregunta.id_pregunta] = { opciones_seleccionadas: [] };
        } else if (pregunta.tipo_pregunta === 'opcion_multiple') {
          initialRespuestas[pregunta.id_pregunta] = { opciones_seleccionadas: [] };
        } else if (pregunta.tipo_pregunta === 'escala') {
          initialRespuestas[pregunta.id_pregunta] = { valor_escala: null };
        } else {
          initialRespuestas[pregunta.id_pregunta] = { respuesta_texto: '' };
        }
      });
      setRespuestas(initialRespuestas);
      setCurrentStep(0);
      setAnonimo(false);
      setError('');
    }
  }, [isOpen, survey]);

  const handleTextChange = (preguntaId, value) => {
    setRespuestas(prev => ({
      ...prev,
      [preguntaId]: { ...prev[preguntaId], respuesta_texto: value }
    }));
  };

  const handleScaleChange = (preguntaId, value) => {
    setRespuestas(prev => ({
      ...prev,
      [preguntaId]: { ...prev[preguntaId], valor_escala: parseInt(value) }
    }));
  };

  const handleOptionToggle = (preguntaId, optionId, isMultiple) => {
    setRespuestas(prev => {
      const current = prev[preguntaId]?.opciones_seleccionadas || [];
      
      if (isMultiple) {
        // Para opción múltiple
        const newSelection = current.includes(optionId)
          ? current.filter(id => id !== optionId)
          : [...current, optionId];
        
        return {
          ...prev,
          [preguntaId]: { ...prev[preguntaId], opciones_seleccionadas: newSelection }
        };
      } else {
        // Para selección única
        return {
          ...prev,
          [preguntaId]: { ...prev[preguntaId], opciones_seleccionadas: [optionId] }
        };
      }
    });
  };

  const validateCurrentStep = () => {
    const currentPregunta = survey.preguntas[currentStep];
    const respuesta = respuestas[currentPregunta.id_pregunta];

    if (currentPregunta.obligatoria) {
      if (currentPregunta.tipo_pregunta === 'texto_libre') {
        if (!respuesta?.respuesta_texto?.trim()) {
          setError(`La pregunta "${currentPregunta.texto_pregunta}" es obligatoria`);
          return false;
        }
      } else if (currentPregunta.tipo_pregunta === 'escala') {
        if (!respuesta?.valor_escala) {
          setError(`Debes seleccionar un valor para "${currentPregunta.texto_pregunta}"`);
          return false;
        }
      } else if (['seleccion_unica', 'opcion_multiple'].includes(currentPregunta.tipo_pregunta)) {
        if (!respuesta?.opciones_seleccionadas?.length) {
          setError(`Debes seleccionar al menos una opción para "${currentPregunta.texto_pregunta}"`);
          return false;
        }
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateCurrentStep()) {
      setError('');
      if (currentStep < survey.preguntas.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        handleSubmit();
      }
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      setError('');
    }
  };

  const handleSubmit = async () => {
    if (!validateCurrentStep()) return;

    setLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('No estás autenticado');
        setLoading(false);
        return;
      }

      // Preparar respuestas en formato requerido
      const respuestasFormatted = Object.keys(respuestas).map(preguntaId => {
        const preguntaIdNum = parseInt(preguntaId);
        const respuesta = respuestas[preguntaId];
        
        // Encontrar la pregunta correspondiente
        const pregunta = survey.preguntas.find(p => p.id_pregunta === preguntaIdNum);
        
        if (!pregunta) {
          console.error(`Pregunta no encontrada: ${preguntaId}`);
          return null;
        }

        return {
          id_pregunta: preguntaIdNum,
          respuesta_texto: respuesta.respuesta_texto || null,
          opciones_seleccionadas: respuesta.opciones_seleccionadas || [],
          valor_escala: respuesta.valor_escala || null
        };
      }).filter(r => r !== null);

      const responseData = {
        respuestas: respuestasFormatted,
        anonimo: anonimo
      };

      console.log('Enviando respuestas:', responseData);

      const response = await fetch(`${apiUrl}/api/v1/surveys/${survey.id}/respond`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(responseData)
      });

      const data = await response.json();

      if (response.ok) {
        alert('¡Gracias por responder la encuesta!');
        onSuccess();
        onClose();
      } else {
        console.error('Error del servidor:', data);
        setError(data.detail || `Error ${response.status}: No se pudo enviar la respuesta`);
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Error de conexión con el servidor');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !survey || !survey.preguntas || !Array.isArray(survey.preguntas)) {
    console.log('Modal no está listo:', { isOpen, survey, tienePreguntas: survey?.preguntas?.length });
    return null;
  }

  if (survey.preguntas.length === 0) {
    console.error('La encuesta no tiene preguntas:', survey);
    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 z-50">
        <div className="bg-gradient-to-br from-night-900 to-night-800 border border-white/20 rounded-2xl w-full max-w-2xl p-6">
          <h2 className="text-xl font-patria font-bold text-white mb-4">Error</h2>
          <p className="text-twine-300 mb-4">Esta encuesta no tiene preguntas configuradas.</p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-patria transition-all"
          >
            Cerrar
          </button>
        </div>
      </div>
    );
  }

  const currentPregunta = survey.preguntas[currentStep];
  const currentRespuesta = respuestas[currentPregunta?.id_pregunta] || {};
  const totalSteps = survey.preguntas.length;

  // Valores por defecto para escala
  const escala_min = currentPregunta?.escala_min || 1;
  const escala_max = currentPregunta?.escala_max || 5;
  const escala_etiqueta_min = currentPregunta?.escala_etiqueta_min || 'Mínimo';
  const escala_etiqueta_max = currentPregunta?.escala_etiqueta_max || 'Máximo';

  console.log('Pregunta actual:', {
    tipo: currentPregunta?.tipo_pregunta,
    id: currentPregunta?.id_pregunta,
    escala_min,
    escala_max,
    escala_etiqueta_min,
    escala_etiqueta_max
  });

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 z-50">
      <div className="bg-gradient-to-br from-night-900 to-night-800 border border-white/20 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-white/20">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-xl font-patria font-bold text-white">
                {survey.titulo}
              </h2>
              <p className="text-twine-300 text-sm font-patria mt-1">
                Pregunta {currentStep + 1} de {totalSteps}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-twine-300 hover:text-white text-2xl"
              disabled={loading}
            >
              ×
            </button>
          </div>

          {/* Barra de progreso */}
          <div className="w-full bg-white/10 rounded-full h-2">
            <div
              className="bg-twine-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Contenido */}
        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-400/30 rounded-xl">
              <p className="text-red-200 text-sm font-patria">{error}</p>
            </div>
          )}

          {/* Pregunta actual */}
          <div className="mb-8">
            <h3 className="text-lg font-patria font-semibold text-white mb-3">
              {currentPregunta?.texto_pregunta || 'Pregunta sin texto'}
              {currentPregunta?.obligatoria && (
                <span className="text-red-400 ml-1">*</span>
              )}
            </h3>
            
            {currentPregunta?.instrucciones && (
              <p className="text-twine-300 text-sm font-patria mb-4 italic">
                {currentPregunta.instrucciones}
              </p>
            )}

            {/* Renderizar tipo de respuesta */}
            {currentPregunta?.tipo_pregunta === 'texto_libre' && (
              <div>
                <textarea
                  value={currentRespuesta.respuesta_texto || ''}
                  onChange={(e) => handleTextChange(currentPregunta.id_pregunta, e.target.value)}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white font-patria placeholder-twine-300 focus:outline-none focus:border-twine-400 focus:bg-white/15 transition-all duration-300 h-32"
                  placeholder="Escribe tu respuesta aquí..."
                  maxLength={currentPregunta.max_longitud || 2000}
                />
                <p className="text-twine-300 text-xs mt-1 font-patria">
                  {currentRespuesta.respuesta_texto?.length || 0} / {currentPregunta.max_longitud || 2000} caracteres
                </p>
              </div>
            )}

            {currentPregunta?.tipo_pregunta === 'escala' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <ScaleIcon className="w-5 h-5 text-twine-300" />
                    <span className="text-twine-300 text-sm font-patria">Escala de evaluación</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center px-4">
                  <div className="text-center">
                    <span className="text-twine-300 text-sm block mb-1">{escala_etiqueta_min}</span>
                    <span className="text-white font-bold">{escala_min}</span>
                  </div>
                  
                  <div className="flex-1 mx-6">
                    <div className="flex justify-between">
                      {Array.from(
                        { length: escala_max - escala_min + 1 },
                        (_, i) => escala_min + i
                      ).map(value => (
                        <label 
                          key={value} 
                          className="flex flex-col items-center cursor-pointer group"
                          title={`Seleccionar ${value}`}
                        >
                          <div 
                            className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all duration-200 transform group-hover:scale-110 ${
                              currentRespuesta.valor_escala === value
                                ? 'bg-gradient-to-r from-twine-500 to-twine-600 border-2 border-twine-400 shadow-lg'
                                : 'bg-white/10 border border-white/20 hover:bg-white/20'
                            }`}
                          >
                            <span className="text-white font-patria font-bold text-sm">{value}</span>
                          </div>
                          <input
                            type="radio"
                            name={`scale_${currentPregunta.id_pregunta}`}
                            value={value}
                            checked={currentRespuesta.valor_escala === value}
                            onChange={() => handleScaleChange(currentPregunta.id_pregunta, value)}
                            className="hidden"
                          />
                        </label>
                      ))}
                    </div>
                    
                    {/* Línea de conexión visual */}
                    <div className="relative mt-4">
                      <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-white/10 -translate-y-1/2"></div>
                      <div 
                        className="absolute left-0 h-0.5 bg-gradient-to-r from-twine-400 to-twine-600 -translate-y-1/2 transition-all duration-300"
                        style={{ 
                          width: currentRespuesta.valor_escala 
                            ? `${((currentRespuesta.valor_escala - escala_min) / (escala_max - escala_min)) * 100}%` 
                            : '0%' 
                        }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <span className="text-twine-300 text-sm block mb-1">{escala_etiqueta_max}</span>
                    <span className="text-white font-bold">{escala_max}</span>
                  </div>
                </div>
                
                {currentRespuesta.valor_escala && (
                  <div className="text-center mt-4 p-3 bg-gradient-to-r from-twine-500/10 to-twine-600/10 rounded-xl border border-twine-400/20">
                    <p className="text-white font-patria">
                      Seleccionado: <span className="font-bold text-twine-300">{currentRespuesta.valor_escala}</span>
                    </p>
                  </div>
                )}
              </div>
            )}

            {(currentPregunta?.tipo_pregunta === 'seleccion_unica' || 
              currentPregunta?.tipo_pregunta === 'opcion_multiple') && (
              <div className="space-y-3">
                {currentPregunta.opciones?.map(opcion => (
                  <label
                    key={opcion.id_opcion}
                    className={`flex items-center p-4 rounded-xl cursor-pointer transition-all duration-200 ${
                      currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion)
                        ? 'bg-twine-500/20 border border-twine-400/50'
                        : 'bg-white/5 border border-white/20 hover:bg-white/10'
                    }`}
                  >
                    {currentPregunta.tipo_pregunta === 'seleccion_unica' ? (
                      <div className={`w-5 h-5 rounded-full border mr-3 flex items-center justify-center transition-all ${
                        currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion)
                          ? 'bg-twine-500 border-twine-500'
                          : 'bg-white/10 border-white/30'
                      }`}>
                        {currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion) && (
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        )}
                      </div>
                    ) : (
                      <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center transition-all ${
                        currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion)
                          ? 'bg-twine-500 border-twine-500'
                          : 'bg-white/10 border-white/30'
                      }`}>
                        {currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion) && (
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    )}
                    <span className="text-white font-patria flex-1">{opcion.texto_opcion}</span>
                    <input
                      type={currentPregunta.tipo_pregunta === 'seleccion_unica' ? 'radio' : 'checkbox'}
                      name={`question_${currentPregunta.id_pregunta}`}
                      checked={currentRespuesta.opciones_seleccionadas?.includes(opcion.id_opcion) || false}
                      onChange={() => handleOptionToggle(
                        currentPregunta.id_pregunta,
                        opcion.id_opcion,
                        currentPregunta.tipo_pregunta === 'opcion_multiple'
                      )}
                      className="hidden"
                    />
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Opción anónima */}
          {survey.permite_anonimo && (
            <div className="mb-6">
              <label className="flex items-center cursor-pointer">
                <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center transition-all ${
                  anonimo ? 'bg-twine-500 border-twine-500' : 'bg-white/10 border-white/30'
                }`}>
                  {anonimo && (
                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <span className="text-white font-patria text-sm">
                  Responder de forma anónima
                </span>
                <input
                  type="checkbox"
                  checked={anonimo}
                  onChange={(e) => setAnonimo(e.target.checked)}
                  className="hidden"
                />
              </label>
              <p className="text-twine-300 text-xs mt-1 ml-8 font-patria">
                Tu respuesta no será asociada con tu nombre
              </p>
            </div>
          )}
        </div>

        {/* Footer con botones de navegación */}
        <div className="p-6 border-t border-white/20">
          <div className="flex justify-between items-center">
            <div>
              {currentStep > 0 && (
                <button
                  type="button"
                  onClick={handlePrev}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-patria transition-all disabled:opacity-50 flex items-center space-x-2"
                  disabled={loading}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                  </svg>
                  <span>Anterior</span>
                </button>
              )}
            </div>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-patria transition-all disabled:opacity-50"
                disabled={loading}
              >
                Cancelar
              </button>
              
              <button
                type="button"
                onClick={handleNext}
                disabled={loading}
                className="px-6 py-2 bg-gradient-to-r from-twine-500 to-twine-600 hover:from-twine-600 hover:to-twine-700 text-white rounded-xl font-patria transition-all border border-twine-400 flex items-center justify-center min-w-[120px] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                    <span>Enviando...</span>
                  </>
                ) : currentStep === totalSteps - 1 ? (
                  'Enviar Respuesta'
                ) : (
                  <>
                    <span>Siguiente</span>
                    <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                    </svg>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Indicador de progreso */}
          <div className="flex justify-center mt-4">
            <div className="flex space-x-2">
              {Array.from({ length: totalSteps }, (_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    // Solo permitir navegación si no está cargando
                    if (!loading) {
                      setCurrentStep(i);
                      setError('');
                    }
                  }}
                  className={`w-8 h-2 rounded-full transition-all duration-300 ${
                    i === currentStep
                      ? 'bg-twine-400'
                      : i < currentStep
                      ? 'bg-twine-600'
                      : 'bg-white/10 hover:bg-white/20'
                  }`}
                  disabled={loading}
                  title={`Ir a pregunta ${i + 1}`}
                ></button>
              ))}
            </div>
          </div>
          
          {/* Indicador visual del progreso */}
          <div className="text-center mt-2">
            <p className="text-twine-300 text-xs font-patria">
              {currentStep + 1} de {totalSteps} preguntas
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RespondSurveyModal;