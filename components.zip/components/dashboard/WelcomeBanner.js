import React, { useState } from 'react';
import {
  XMarkIcon,
  ArrowRightIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  DocumentTextIcon,
  ClockIcon,
  IdentificationIcon,
  AcademicCapIcon,
  UserGroupIcon,
  ShieldCheckIcon,
  InformationCircleIcon,
  UserIcon
} from '@heroicons/react/24/outline';

const WelcomeBanner = ({ userProfile, onClose, onVerifyClick }) => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleClose = () => {
    setIsVisible(false);
    if (onClose) onClose();
  };

  const handleVerify = () => {
    setIsVisible(false);
    if (onVerifyClick) onVerifyClick();
  };

  // Obtener tipo de usuario específico
  const getUserTypeLabel = () => {
    const userType = localStorage.getItem('userType');
    switch(userType) {
      case 'educativo': return 'Personal Educativo';
      case 'administrativo': return 'Personal Administrativo';
      case 'tutor': return 'Tutor/Padre de Familia';
      case 'alumno': return 'Estudiante';
      default: return 'Usuario';
    }
  };

  // Documentos requeridos según tipo de usuario
  const getRequiredDocuments = () => {
    const userType = localStorage.getItem('userType');
    switch(userType) {
      case 'educativo':
        return [
          'Constancia de trabajo emitida por la escuela',
          'Cédula profesional (opcional)',
          'Identificación oficial (INE, pasaporte)'
        ];
      case 'administrativo':
        return [
          'Constancia de trabajo administrativo',
          'Nómina o comprobante de empleo',
          'Identificación oficial'
        ];
      case 'tutor':
        return [
          'Identificación oficial (INE, pasaporte)',
          'Comprobante de domicilio',
          'Acta de nacimiento del alumno (opcional)'
        ];
      case 'alumno':
        return [
          'Acta de nacimiento',
          'Certificado de estudios anterior',
          'Identificación oficial (opcional)'
        ];
      default:
        return ['Documento de identificación oficial'];
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={handleClose}
    >
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header del banner */}
        <div className="bg-gradient-to-r from-twine-600/80 to-night-700/80 px-6 py-5 border-b border-white/20 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
                <ShieldCheckIcon className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-patria font-bold text-white">Verificación de Identidad Requerida</h3>
                <p className="text-white/80 text-sm font-patria">
                  {userProfile?.nombre || 'Usuario'}, necesitamos validar tu información
                </p>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              <XMarkIcon className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        {/* Contenido principal */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {/* Información del usuario */}
            <div className="bg-gradient-to-r from-twine-600/20 to-night-700/20 rounded-xl p-5 border border-white/10">
              <div className="flex items-start space-x-4">
                <UserIcon className="w-6 h-6 text-twine-300 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-white font-patria font-semibold text-lg mb-2">
                    Información del Registro
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-twine-200 text-sm font-patria">Tipo de Usuario:</p>
                      <p className="text-white font-medium font-patria">{getUserTypeLabel()}</p>
                    </div>
                    <div>
                      <p className="text-twine-200 text-sm font-patria">Nombre:</p>
                      <p className="text-white font-medium font-patria">
                        {userProfile?.nombre || ''} {userProfile?.ape_pa || ''}
                      </p>
                    </div>
                    <div>
                      <p className="text-twine-200 text-sm font-patria">Correo:</p>
                      <p className="text-white font-medium font-patria">{userProfile?.correo || ''}</p>
                    </div>
                    <div>
                      <p className="text-twine-200 text-sm font-patria">Estado:</p>
                      <span className="inline-flex items-center px-2 py-1 rounded-full bg-red-500/20 text-red-200 text-xs font-medium">
                        No Verificado
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Estado de la cuenta */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <ExclamationTriangleIcon className="w-5 h-5 text-yellow-300" />
                <h4 className="text-white font-patria font-semibold text-lg">Cuenta Pendiente de Activación</h4>
              </div>
              <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
                <p className="text-yellow-100 font-patria text-sm leading-relaxed">
                  Tu cuenta se encuentra <span className="font-bold">INACTIVA</span> hasta que se verifique tu identidad y cargo.
                  Esto es un requisito de seguridad del sistema SIVOD.
                </p>
              </div>
            </div>

            {/* Documentos requeridos */}
            <div className="bg-gradient-to-r from-twine-600/20 to-night-700/20 rounded-xl p-5 border border-white/10">
              <div className="flex items-center space-x-3 mb-4">
                <DocumentTextIcon className="w-6 h-6 text-white" />
                <h4 className="text-white font-patria font-semibold text-lg">Documentos Requeridos</h4>
              </div>
              <ul className="space-y-3">
                {getRequiredDocuments().map((doc, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-white/10 rounded-full flex items-center justify-center border border-white/20 flex-shrink-0">
                      <span className="text-white text-xs font-bold">{index + 1}</span>
                    </div>
                    <span className="text-white font-patria text-sm">{doc}</span>
                  </li>
                ))}
              </ul>
              <p className="text-twine-200 text-xs mt-4 font-patria flex items-center">
                <InformationCircleIcon className="w-3 h-3 mr-1" />
                Sube al menos un documento oficial para validar tu identidad y cargo.
              </p>
            </div>

            {/* Pasos del proceso */}
            <div>
              <h4 className="text-white font-patria font-semibold text-lg mb-4">Proceso de Verificación</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                  <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30 mx-auto mb-3">
                    <span className="text-white font-bold">1</span>
                  </div>
                  <p className="text-white font-patria text-sm">Sube documento oficial</p>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                  <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30 mx-auto mb-3">
                    <span className="text-white font-bold">2</span>
                  </div>
                  <p className="text-white font-patria text-sm">Nuestra IA lo valida</p>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                  <div className="w-10 h-10 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30 mx-auto mb-3">
                    <span className="text-white font-bold">3</span>
                  </div>
                  <p className="text-white font-patria text-sm">Cuenta activada</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer con botones */}
        <div className="bg-gradient-to-r from-twine-600/40 to-night-700/40 border-t border-white/20 px-6 py-5 flex-shrink-0">
          <div className="text-center">
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleClose}
                className="flex-1 bg-white/10 backdrop-blur-sm border border-white/30 text-white px-6 py-3 rounded-xl hover:bg-white/20 transition-all duration-300 font-patria"
              >
                Verificar más tarde
              </button>
              <button
                onClick={handleVerify}
                className="flex-1 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-6 py-3 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria font-semibold flex items-center justify-center space-x-2 group"
              >
                <span>Iniciar Verificación</span>
                <ArrowRightIcon className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
            <p className="text-white/60 text-xs mt-4 font-patria">
              Esta verificación es obligatoria para acceder a todas las funciones del sistema
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeBanner;