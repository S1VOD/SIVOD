import React, { useState } from 'react';

const EvaluationForm = ({ teacher, onBack }) => {
  const [evaluation, setEvaluation] = useState({
    desempeno: 0,
    etica: 0,
    innovacion: 0,
    comentarios: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí iría la lógica para enviar la evaluación
    alert('Evaluación enviada exitosamente');
    onBack();
  };

  const renderStarRating = (criteria, value) => {
    return (
      <div className="rating-stars">
        {[1, 2, 3, 4, 5].map(star => (
          <button
            key={star}
            type="button"
            className={`star-btn ${value >= star ? 'active' : ''}`}
            onClick={() => setEvaluation({...evaluation, [criteria]: star})}
          >
            ★
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="card">
      <button className="btn btn-outline-secondary mb-3" onClick={onBack}>
        ← Volver a la lista
      </button>

      <div className="card-header">
        <h2>Evaluando a: {teacher?.nombre}</h2>
        <p className="text-gray-600">{teacher?.materia}</p>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="evaluation-criteria">
          <h3>Desempeño Académico</h3>
          <p>Claridad en explicaciones, dominio de la materia, preparación de clases</p>
          {renderStarRating('desempeno', evaluation.desempeno)}
        </div>

        <div className="evaluation-criteria">
          <h3>Ética Profesional</h3>
          <p>Respeto, puntualidad, imparcialidad, trato a estudiantes</p>
          {renderStarRating('etica', evaluation.etica)}
        </div>

        <div className="evaluation-criteria">
          <h3>Innovación Educativa</h3>
          <p>Uso de tecnología, creatividad en clases, motivación a estudiantes</p>
          {renderStarRating('innovacion', evaluation.innovacion)}
        </div>

        <div className="form-group">
          <label className="form-label">Comentarios Constructivos</label>
          <textarea
            value={evaluation.comentarios}
            onChange={(e) => setEvaluation({...evaluation, comentarios: e.target.value})}
            className="form-control"
            placeholder="Comparte tus comentarios de manera respetuosa y constructiva..."
            rows="4"
          />
        </div>

        <button type="submit" className="btn btn-flat-primary w-100">
          Enviar Evaluación Anónima
        </button>
      </form>
    </div>
  );
};

export default EvaluationForm;