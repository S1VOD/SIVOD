import React from 'react';

const EvaluationList = ({ onSelectTeacher }) => {
  // Datos de ejemplo - en producción vendrían de una API
  const teachers = [
    { id: 1, nombre: 'María González', materia: 'Matemáticas', escuela: 'Escuela Primaria Federal' },
    { id: 2, nombre: 'Carlos Rodríguez', materia: 'Español', escuela: 'Escuela Primaria Federal' },
    { id: 3, nombre: 'Ana Martínez', materia: 'Ciencias', escuela: 'Escuela Primaria Federal' }
  ];

  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">Docentes por Evaluar</h3>
        <p>Selecciona un docente para comenzar la evaluación</p>
      </div>
      <div className="teachers-list">
        {teachers.map(teacher => (
          <div key={teacher.id} className="teacher-card card">
            <div className="teacher-info">
              <h4>{teacher.nombre}</h4>
              <p className="text-gray-600">{teacher.materia} - {teacher.escuela}</p>
            </div>
            <button 
              className="btn btn-flat-primary"
              onClick={() => onSelectTeacher(teacher)}
            >
              Evaluar Docente
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EvaluationList;