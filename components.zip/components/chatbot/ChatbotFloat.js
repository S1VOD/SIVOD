import React, { useState, useRef, useEffect } from 'react';

// Importar todos los GIFs del chatbot
import chatbotAsustado from '../../assets/Chatbot-States/ChatBot-Asustado.gif';
import chatbotBienvenida from '../../assets/Chatbot-States/ChatBot-Bienvenida.gif';
import chatbotBostezo from '../../assets/Chatbot-States/ChatBot-Bostezo.gif';
import chatbotEsperar from '../../assets/Chatbot-States/ChatBot-Esperar.gif';
import chatbotHablar from '../../assets/Chatbot-States/ChatBot-Hablar.gif';
import chatbotNo from '../../assets/Chatbot-States/ChatBot-No.gif';
import chatbotPensando from '../../assets/Chatbot-States/ChatBot-Pensando.gif';
import chatbotSaludar from '../../assets/Chatbot-States/ChatBot-Saludar.gif';
import chatbotSinRespuesta from '../../assets/Chatbot-States/ChatBot-SinRespuesta.gif';

const ChatbotFloat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatbotState, setChatbotState] = useState('esperar');
  const [hasConnectionError, setHasConnectionError] = useState(false);
  const [windowHeight, setWindowHeight] = useState(window.innerHeight);
  const messagesEndRef = useRef(null);
  const modalRef = useRef(null);
  const inputRef = useRef(null);
  const inactivityTimerRef = useRef(null);
  const bostezoTimerRef = useRef(null);

  // Mapeo de estados a GIFs
  const gifStates = {
    asustado: chatbotAsustado,
    bienvenida: chatbotBienvenida,
    bostezo: chatbotBostezo,
    esperar: chatbotEsperar,
    hablar: chatbotHablar,
    no: chatbotNo,
    pensando: chatbotPensando,
    saludar: chatbotSaludar,
    sinrespuesta: chatbotSinRespuesta,
  };

  // Actualizar altura de ventana
  useEffect(() => {
    const handleResize = () => {
      setWindowHeight(window.innerHeight);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Efecto para rotación automática de estados en inactividad
  useEffect(() => {
    if (bostezoTimerRef.current) {
      clearTimeout(bostezoTimerRef.current);
    }

    if (isOpen && !isLoading && messages.length === 0) {
      bostezoTimerRef.current = setTimeout(() => {
        setChatbotState('bostezo');
        
        setTimeout(() => {
          setChatbotState('esperar');
        }, 3000);
      }, 15000);
    }

    return () => {
      if (bostezoTimerRef.current) {
        clearTimeout(bostezoTimerRef.current);
      }
    };
  }, [isOpen, isLoading, messages.length]);

  // Efecto para cambiar estados del chatbot
  useEffect(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
    }

    if (isLoading) {
      setChatbotState('pensando');
    } else if (messages.length === 0 && isOpen) {
      setChatbotState('bienvenida');
    } else if (messages.length > 0 && !isLoading) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.sender === 'user') {
        setChatbotState('hablar');
      } else {
        setChatbotState('saludar');
      }
    }

    if (hasConnectionError && !isLoading) {
      const errorStates = ['asustado', 'no', 'sinrespuesta'];
      const randomIndex = Math.floor(Math.random() * errorStates.length);
      setChatbotState(errorStates[randomIndex]);
    }

    if (!isLoading && isOpen && !hasConnectionError) {
      inactivityTimerRef.current = setTimeout(() => {
        setChatbotState('esperar');
      }, 30000);
    }

    return () => {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
      }
    };
  }, [messages, isLoading, isOpen, hasConnectionError]);

  // Cerrar modal al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleSend = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = { text: inputMessage, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);
    setChatbotState('pensando');
    setHasConnectionError(false);

    try {
      const response = await fetch('http://localhost:8000/api/v1/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: inputMessage }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}`);
      }

      const data = await response.json();

      if (data.response) {
        const botMessage = { text: data.response, sender: 'bot' };
        setMessages(prev => [...prev, botMessage]);
        setChatbotState('hablar');
      } else {
        throw new Error('Respuesta vacía del servidor');
      }

    } catch (error) {
      console.error('Error en el chatbot:', error);

      let errorText = 'Lo siento, el servicio de asistente no está disponible en este momento. ';
      errorText += 'Puedes intentar: 1) Recargar la página, 2) Verificar tu conexión, 3) Contactar soporte si el problema persiste.';

      const errorMessage = {
        text: errorText,
        sender: 'bot'
      };
      setMessages(prev => [...prev, errorMessage]);
      setChatbotState('asustado');
      setHasConnectionError(true);
      
      const errorInterval = setInterval(() => {
        const errorStates = ['asustado', 'no', 'sinrespuesta'];
        const randomIndex = Math.floor(Math.random() * errorStates.length);
        setChatbotState(errorStates[randomIndex]);
      }, 5000);

      setTimeout(() => {
        clearInterval(errorInterval);
        setHasConnectionError(false);
        setChatbotState('esperar');
      }, 20000);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setChatbotState('bienvenida');
    setHasConnectionError(false);
  };

  const handleOpenChat = () => {
    setIsOpen(true);
    setChatbotState('bienvenida');
    setHasConnectionError(false);
  };

  // Calcular altura máxima basada en la ventana
  const maxChatHeight = Math.min(580, windowHeight - 120);
  const chatHeight = Math.min(480, maxChatHeight);

  return (
    <>
      {/* Botón flotante - SOLO el GIF transparente sin fondo */}
      <div
        className={`fixed z-[9999] cursor-pointer hover:scale-110 transition-all duration-300 ${
          isOpen ? 'hidden' : ''
        } 
        bottom-4 right-4 w-16 h-16
        sm:bottom-5 sm:right-5 sm:w-20 sm:h-20
        md:bottom-6 md:right-6 md:w-24 md:h-24
        lg:bottom-8 lg:right-8 lg:w-28 lg:h-28`}
        onClick={handleOpenChat}
      >
        {/* SOLO el GIF transparente - sin contenedor glass */}
        <img 
          src={gifStates[chatbotState]} 
          alt="Chatbot SIVOD"
          className="w-full h-full object-contain drop-shadow-2xl filter brightness-110 contrast-110 hover:brightness-125 transition-all duration-300"
          style={{
            // Forzar transparencia del GIF si tiene fondo
            mixBlendMode: 'multiply'
          }}
        />
        
        {messages.length > 0 && !isOpen && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse shadow-lg"></div>
        )}
      </div>

      {/* Chatbot modal - Fondo oscuro con toques dorados y vino fuerte */}
      {isOpen && (
        <div className="fixed inset-0 z-[10000] flex items-end justify-end p-2 sm:p-4 md:p-6 pointer-events-none">
          <div 
            ref={modalRef}
            className="pointer-events-auto bg-gradient-to-br from-night-1000/95 via-night-900/95 to-night-800/95 backdrop-blur-xl rounded-3xl border-2 border-twine-700/30 shadow-2xl flex overflow-hidden transform transition-all duration-300 ease-out
            w-full max-w-[340px]
            sm:max-w-[360px]
            md:max-w-[400px]
            animate-[slideUp_0.3s_ease]"
            style={{
              height: `${chatHeight}px`,
              maxHeight: `${maxChatHeight}px`
            }}
          >
            {/* Sección izquierda: GIF del chatbot - Con fondo dorado */}
            <div className="w-1/3 flex-shrink-0 bg-gradient-to-b from-twine-700/80 via-twine-800/90 to-twine-900/90 backdrop-blur-lg border-r border-twine-600/40 flex flex-col items-center justify-center p-3 relative overflow-hidden">
              {/* Patrón decorativo con líneas doradas sutiles */}
              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-twine-600/10 to-transparent"></div>
              {/* Brillo en las esquinas */}
              <div className="absolute top-0 left-0 w-12 h-12 bg-gradient-to-br from-twine-500/20 to-transparent rounded-br-full"></div>
              <div className="absolute bottom-0 right-0 w-12 h-12 bg-gradient-to-tl from-twine-500/20 to-transparent rounded-tl-full"></div>
              
              {/* Contenedor del GIF con borde dorado */}
              <div className="relative w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-twine-600/80 to-twine-700/90 backdrop-blur-sm border-2 border-twine-500/60 shadow-2xl overflow-hidden z-10">
                <img 
                  src={gifStates[chatbotState]} 
                  alt="Quetzalli"
                  className="w-full h-full object-cover scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-twine-500/30 via-transparent to-twine-600/30"></div>
              </div>
              
              {/* Nombre y estado - Texto dorado */}
              <div className="mt-2 text-center z-10">
                <h3 className="text-twine-200 font-bold text-xs sm:text-sm font-patria drop-shadow-lg">
                  Quetzalli
                </h3>
                <p className="text-twine-300/90 text-[10px] sm:text-xs font-patria mt-0.5">
                  {chatbotState === 'pensando' ? 'Pensando...' :
                   chatbotState === 'hablar' ? 'Respondiendo...' :
                   chatbotState === 'bienvenida' ? '¡Hola!' :
                   chatbotState === 'saludar' ? 'Lista' :
                   chatbotState === 'asustado' ? '¡Oh!' :
                   chatbotState === 'bostezo' ? 'Zzz...' :
                   chatbotState === 'sinrespuesta' ? 'Sin respuesta' :
                   chatbotState === 'no' ? 'No disponible' :
                   'En espera'}
                </p>
              </div>
              
              {/* Botón de papelera (clear chat) - Dorado */}
              <button
                className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-twine-700/80 backdrop-blur-sm border border-twine-500/50 text-twine-100 flex items-center justify-center hover:bg-twine-600/90 hover:scale-105 hover:text-white transition-all duration-300 z-20 shadow-md"
                onClick={clearChat}
                title="Limpiar chat"
              >
                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>

            {/* Sección derecha: Chat - Fondo vino fuerte con detalles dorados */}
            <div className="w-2/3 flex flex-col">
              {/* Header del chat - Degradé vino con borde dorado */}
              <div className="bg-gradient-to-r from-night-1000/90 via-night-900 to-night-800/90 px-2 py-1.5 border-b border-twine-600/30 flex justify-between items-center min-h-[35px] flex-shrink-0">
                <div className="flex items-center gap-1">
                  <div className={`w-1.5 h-1.5 rounded-full ${
                    hasConnectionError ? 'bg-red-500' : 'bg-green-500'
                  } animate-pulse`}></div>
                  <span className="text-twine-100 font-patria text-[10px] sm:text-xs drop-shadow">Asistente SIVOD</span>
                </div>
                
                {/* Botón de cerrar (X) - Dorado */}
                <button
                  className="w-4 h-4 rounded bg-twine-700/80 backdrop-blur-sm border border-twine-500/50 text-twine-100 flex items-center justify-center hover:bg-twine-600/90 hover:scale-105 hover:text-white transition-all duration-300 shadow-sm"
                  onClick={() => setIsOpen(false)}
                  title="Cerrar chat"
                >
                  <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Área de mensajes - Fondo vino oscuro con toques dorados */}
              <div 
                className="flex-1 p-1.5 overflow-y-auto flex flex-col gap-1.5 min-h-0 bg-gradient-to-b from-night-1000/80 via-night-900/90 to-night-800/95
                [&::-webkit-scrollbar]:w-1
                [&::-webkit-scrollbar-track]:bg-night-900/40
                [&::-webkit-scrollbar-thumb]:bg-twine-700/60
                [&::-webkit-scrollbar-thumb]:rounded-full
                [&::-webkit-scrollbar-thumb:hover]:bg-twine-600/70"
              >
                {messages.length === 0 && (
                  <div className="animate-fadeIn">
                    <div className="text-center py-3">
                      <div className="inline-block bg-gradient-to-r from-twine-800/40 to-twine-900/50 backdrop-blur-md px-2 py-1.5 rounded-xl border border-twine-600/40">
                        <p className="text-twine-100 font-patria text-[10px] sm:text-xs">
                          ¡Hola! ¿En qué puedo ayudarte?
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {messages.map((message, index) => (
                  <div 
                    key={index} 
                    className={`animate-fadeIn ${
                      message.sender === 'user' 
                        ? 'text-right ml-auto' 
                        : 'text-left mr-auto'
                    } max-w-[90%]`}
                  >
                    <div className={`inline-block px-2 py-1.5 rounded-xl backdrop-blur-md font-patria text-[10px] sm:text-xs leading-relaxed shadow-sm ${
                      message.sender === 'user' 
                        ? 'bg-gradient-to-r from-twine-700/70 to-twine-800/80 text-white border border-twine-500/50' 
                        : 'bg-gradient-to-r from-night-800/60 to-night-900/70 text-twine-100 border border-twine-600/30'
                    }`}>
                      {message.text}
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="animate-fadeIn text-left mr-auto max-w-[90%]">
                    <div className="inline-block bg-gradient-to-r from-night-800/60 to-night-900/70 backdrop-blur-md px-2 py-1.5 rounded-xl border border-twine-600/30">
                      <div className="flex gap-1 items-center">
                        <div className="flex gap-0.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-twine-400 animate-pulse"></div>
                          <div className="w-1.5 h-1.5 rounded-full bg-twine-400 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                          <div className="w-1.5 h-1.5 rounded-full bg-twine-400 animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                        </div>
                        <span className="text-twine-300/90 text-[10px]">Escribiendo...</span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Área de input - Fondo vino con borde dorado */}
              <div className="p-1.5 border-t border-twine-600/30 bg-gradient-to-t from-night-1000/90 via-night-900 to-transparent flex-shrink-0">
                <div className="flex gap-1.5">
                  <div className="flex-1 relative">
                    <textarea
                      ref={inputRef}
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Escribe aquí..."
                      rows="1"
                      disabled={isLoading}
                      className="w-full px-2 py-1.5 bg-night-900/70 backdrop-blur-md border border-twine-600/40 rounded-xl resize-none font-patria text-[10px] sm:text-xs text-twine-100 placeholder-twine-300/60 focus:outline-none focus:border-twine-500 focus:ring-1 focus:ring-twine-500/40 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed pr-8"
                    />
                    <div className="absolute right-1.5 top-1/2 transform -translate-y-1/2 text-twine-400/60">
                      <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                  </div>
                  <button
                    onClick={handleSend}
                    disabled={isLoading || !inputMessage.trim()}
                    className="px-2 py-1.5 bg-gradient-to-r from-twine-600 to-twine-700 text-white border border-twine-500/50 rounded-xl cursor-pointer font-patria transition-all duration-300 hover:from-twine-500 hover:to-twine-600 hover:scale-105 hover:border-twine-400 disabled:opacity-30 disabled:cursor-not-allowed disabled:transform-none min-w-[35px] backdrop-blur-sm flex items-center justify-center shadow-md"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  </button>
                </div>
                <p className="text-twine-400/60 text-[9px] font-patria mt-0.5 text-center">
                  Enter para enviar
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from {
            transform: translateY(10px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(5px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.2s ease forwards;
        }
      `}</style>
    </>
  );
};

export default ChatbotFloat;