import React from 'react';

const ValidationResult = ({ result }) => {
  const getStatusConfig = () => {
    if (result.documentType === 'no-oficial' || result.documentType === 'error') {
      return {
        color: 'red',
        text: 'Documento No Oficial',
        bgColor: 'bg-red-500/40',
        borderColor: 'border-red-400/50',
        textColor: 'text-red-200',
        iconBg: 'bg-red-500/40',
        iconBorder: 'border-red-400/50',
        iconColor: 'bg-red-200'
      };
    }
    if (result.isValid) {
      return {
        color: 'green',
        text: 'Documento Válido',
        bgColor: 'bg-green-500/40',
        borderColor: 'border-green-400/50',
        textColor: 'text-green-200',
        iconBg: 'bg-green-500/40',
        iconBorder: 'border-green-400/50',
        iconColor: 'bg-green-200'
      };
    }
    return {
      color: 'yellow',
      text: 'Documento No Válido',
      bgColor: 'bg-yellow-500/40',
      borderColor: 'border-yellow-400/50',
      textColor: 'text-yellow-200',
      iconBg: 'bg-yellow-500/40',
      iconBorder: 'border-yellow-400/50',
      iconColor: 'bg-yellow-200'
    };
  };

  const getStatusIcon = (config) => {
    return (
      <div className={`w-8 h-8 ${config.iconBg} rounded-full flex items-center justify-center border ${config.iconBorder}`}>
        <div className={`w-3 h-3 ${config.iconColor} rounded-full`}></div>
      </div>
    );
  };

  const getAlertIcon = () => {
    return (
      <div className="w-6 h-6 bg-yellow-500/40 rounded-full flex items-center justify-center border border-yellow-400/50">
        <div className="w-2 h-2 bg-yellow-200 rounded-full"></div>
      </div>
    );
  };

  const getSuccessIcon = () => {
    return (
      <div className="w-6 h-6 bg-green-500/40 rounded-full flex items-center justify-center border border-green-400/50">
        <div className="w-2 h-2 bg-green-200 rounded-full"></div>
      </div>
    );
  };

  const getWarningIcon = () => {
    return (
      <div className="w-6 h-6 bg-yellow-500/40 rounded-full flex items-center justify-center border border-yellow-400/50">
        <div className="w-2 h-2 bg-yellow-200 rounded-full"></div>
      </div>
    );
  };

  const statusConfig = getStatusConfig();

  return (
    <div className={`bg-white/15 backdrop-blur-md rounded-2xl p-6 border-2 ${statusConfig.borderColor} mb-6`}>
      {/* Header del resultado */}
      <div className="flex items-center space-x-4 mb-6">
        {getStatusIcon(statusConfig)}
        <div>
          <h3 className="text-xl font-patria font-bold text-white">Resultado de Validación</h3>
          <p className="text-twine-200 text-sm font-patria">Análisis completado del documento</p>
        </div>
      </div>
      
      {/* Grid de resultados */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="text-sm text-twine-200 font-patria mb-2">Estado</div>
          <div className={`text-lg font-semibold font-patria ${statusConfig.textColor}`}>
            {statusConfig.text}
          </div>
        </div>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="text-sm text-twine-200 font-patria mb-2">Tipo de Documento</div>
          <div className="text-lg font-semibold text-white font-patria">
            {result.documentType || 'No identificado'}
          </div>
        </div>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
          <div className="text-sm text-twine-200 font-patria mb-2">Nivel de Confianza</div>
          <div className="text-lg font-semibold text-white font-patria">
            {result.confidence}%
          </div>
        </div>
      </div>

      {/* Mensaje de alerta para documentos no válidos */}
      {(result.documentType === 'no-oficial' || result.documentType === 'error') && (
        <div className={`${statusConfig.bgColor} backdrop-blur-sm rounded-xl p-4 border ${statusConfig.borderColor}`}>
          <div className="flex items-start space-x-4">
            {getAlertIcon()}
            <div className="flex-1">
              <div className="font-semibold text-white font-patria mb-2">
                Atención - Documento No Válido
              </div>
              <p className="text-white/90 font-patria">
                Este documento no ha pasado la validación. Por favor, sube un documento oficial válido usando el selector de archivos.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Información adicional para documentos válidos */}
      {result.isValid && result.documentType !== 'no-oficial' && result.documentType !== 'error' && (
        <div className="bg-green-500/30 backdrop-blur-sm rounded-xl p-4 border border-green-400/40">
          <div className="flex items-start space-x-4">
            {getSuccessIcon()}
            <div className="flex-1">
              <div className="font-semibold text-green-200 font-patria mb-2">
                Validación Exitosa
              </div>
              <p className="text-green-100 font-patria">
                El documento ha sido verificado exitosamente y es válido para su uso en el sistema SIVOD.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Información para documentos con advertencia */}
      {!result.isValid && result.documentType !== 'no-oficial' && result.documentType !== 'error' && (
        <div className="bg-yellow-500/30 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/40">
          <div className="flex items-start space-x-4">
            {getWarningIcon()}
            <div className="flex-1">
              <div className="font-semibold text-yellow-200 font-patria mb-2">
                Requiere Revisión Adicional
              </div>
              <p className="text-yellow-100 font-patria">
                El documento presenta algunas inconsistencias que requieren verificación manual por parte del equipo administrativo.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Información general del resultado */}
      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="flex items-center space-x-3">
          <div className="w-5 h-5 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30">
            <div className="w-1.5 h-1.5 bg-twine-300 rounded-full"></div>
          </div>
          <p className="text-twine-200 text-sm font-patria">
            Resultado generado el {new Date().toLocaleDateString('es-MX')} a las {new Date().toLocaleTimeString('es-MX')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ValidationResult;