import React, { useState } from 'react';
import { useDocumentValidation } from '../../hooks/useDocumentValidation';
import ValidationResult from './ValidationResult';

const DocumentUploader = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const { 
    validateDocument, 
    validationResult, 
    isLoading, 
    error,
    fileName 
  } = useDocumentValidation();

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && file.type === 'application/pdf') {
      setSelectedFile(file);
    } else {
      alert('Por favor, selecciona un archivo PDF válido');
    }
  };

  // Mostrar el nombre del archivo seleccionado
  const displayFileName = selectedFile ? selectedFile.name : fileName;

  const handleValidation = async () => {
    if (!selectedFile) return;

    try {
      const result = await validateDocument(selectedFile);
      
      // Elimina el archivo si no es oficial
      if (result && (result.documentType === 'no-oficial' || result.documentType === 'error')) {
        setSelectedFile(null);
        document.getElementById('fileInput').value = '';
      }
    } catch (error) {
      console.error('Error en la validación:', error);
      setSelectedFile(null);
      document.getElementById('fileInput').value = '';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-patria font-bold text-white mb-2">
          Validación de Documentos Oficiales
        </h2>
        <p className="text-twine-200 font-patria">
          Verifica la autenticidad de tus documentos educativos
        </p>
      </div>
      
      {/* Sección de carga de archivos */}
      <div className="space-y-6 mb-8">
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
          <div className="space-y-4">
            {/* Input de archivo */}
            <div className="file-input-container">
              <input
                type="file"
                accept=".pdf"
                onChange={handleFileSelect}
                className="hidden"
                id="fileInput"
              />
              <label 
                htmlFor="fileInput" 
                className="block w-full bg-white/10 backdrop-blur-sm border-2 border-dashed border-white/20 rounded-2xl p-8 text-center cursor-pointer hover:bg-white/15 hover:border-white/30 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-gradient-to-r from-twine-400 to-twine-600 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-300">
                  <div className="w-5 h-5 bg-white rounded-sm"></div>
                </div>
                <div className="text-white font-patria font-semibold mb-2">
                  {selectedFile ? 'Archivo Seleccionado' : 'Seleccionar Documento PDF'}
                </div>
                <div className="text-twine-200 text-sm font-patria">
                  {selectedFile ? 'Haz clic para cambiar el archivo' : 'Haz clic aquí o arrastra tu archivo'}
                </div>
              </label>
            </div>
            
            {/* Nombre del archivo*/}
            {selectedFile && (
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-twine-500/20 rounded-lg flex items-center justify-center border border-twine-400/30">
                    <div className="w-3 h-3 bg-twine-300 rounded-sm"></div>
                  </div>
                  <div>
                    <p className="text-white font-patria font-medium">Archivo seleccionado:</p>
                    <p className="text-twine-200 text-sm font-patria">{selectedFile.name}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Botón de validación*/}
        <button 
          onClick={handleValidation} 
          disabled={!selectedFile || isLoading}
          className="w-full py-4 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-2xl hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3 font-patria"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              Validando documento...
            </>
          ) : (
            <>
              <div className="w-5 h-5 bg-gradient-to-r from-white to-twine-100 rounded-sm"></div>
              Validar Documento
            </>
          )}
        </button>
      </div>

      {/* Mensaje de error */}
      {error && (
        <div className="bg-red-500/20 backdrop-blur-sm rounded-2xl p-4 border border-red-400/30 mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-6 h-6 bg-red-500/20 rounded-lg flex items-center justify-center border border-red-400/30">
              <div className="w-2 h-2 bg-red-300 rounded-full"></div>
            </div>
            <p className="text-red-200 font-patria">{error}</p>
          </div>
        </div>
      )}

      {/* Resultado de validación */}
      {validationResult && (
        <ValidationResult result={validationResult} />
      )}

      {/* Información de documentos aceptados */}
      <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
        <h4 className="text-lg font-patria font-bold text-white mb-4 flex items-center gap-3">
          <div className="w-6 h-6 bg-gradient-to-r from-twine-400 to-twine-600 rounded-lg flex items-center justify-center">
            <div className="w-2 h-2 bg-white rounded-sm"></div>
          </div>
          Documentos Oficiales Aceptados
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            'Certificados de estudios',
            'Títulos profesionales',
            'Cédulas profesionales',
            'Identificaciones oficiales',
            'Actas oficiales',
            'Constancias oficiales'
          ].map((docType, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-gradient-to-r from-twine-300 to-twine-400 rounded-sm flex-shrink-0"></div>
              <span className="text-twine-200 text-sm font-patria">{docType}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DocumentUploader;