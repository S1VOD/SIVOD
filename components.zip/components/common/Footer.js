import React from 'react';
import { Link } from 'react-router-dom';
import logoQuetzalcoatl from '../../assets/images/LogoS.gif';


const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-night-1000 border-t border-night-900 text-white">
      <div className="container mx-auto px-4">
        {/* Sección principal del footer */}
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            
            {/* Logo y descripción */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-16 h-16 flex items-center justify-center rounded-lg">
                <img 
                  src={logoQuetzalcoatl} 
                  alt="Quetzalcóatl - Serpiente Emplumada"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    // Fallback si la imagen no carga
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                {/* Fallback en texto si la imagen no carga */}
                <div className="w-16 h-16 bg-night-800 rounded-lg flex items-center justify-center shadow-lg hidden">
                  <span className="text-white font-bold text-xl">S</span>
                </div>
                </div>
                <div>
                  <h3 className="text-xl font-patria font-bold">SIVOD</h3>
                  <p className="text-white/80 text-sm">Sistema Integral de Votación y Opinión Docente</p>
                </div>
              </div>
              <p className="text-white/70 text-sm leading-relaxed max-w-md">
                Plataforma oficial para el reconocimiento meritocrático del profesorado mexicano. 
                Donde la excelencia educativa encuentra su merecido reconocimiento.
              </p>
            </div>

            {/* Enlaces rápidos */}
            <div>
              <h4 className="font-patria font-bold text-lg mb-4">Enlaces Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <Link to="/about-sivod" className="text-white/70 hover:text-white transition-colors duration-300 text-sm">
                    Acerca de SIVOD
                  </Link>
                </li>
                <li>
                  <Link to="/report" className="text-white/70 hover:text-white transition-colors duration-300 text-sm">
                    Reportar un Problema
                  </Link>
                </li>
              </ul>
            </div>

            {/* Información de contacto */}
            <div>
              <h4 className="font-patria font-bold text-lg mb-4">Contacto</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-4 group">
                  <div className="w-12 h-12 bg-twine-700/40 backdrop-blur-sm rounded-xl flex items-center justify-center border border-twine-400/30 shadow-lg group-hover:bg-twine-700/60 transition">
                    <img src={require('../../assets/icons/icon-white/icon05.ico')} alt="Email" className="w-7 h-7 filter brightness-0 invert contrast-150 drop-shadow-2xl" />
                  </div>
                  <span className="text-twine-100 font-medium">soportesivod@gmail.com</span>
                </div>
                <div className="flex items-center space-x-4 group">
                  <div className="w-12 h-12 bg-twine-700/40 backdrop-blur-sm rounded-xl flex items-center justify-center border border-twine-400/30 shadow-lg group-hover:bg-twine-700/60 transition">
                    <img src={require('../../assets/icons/icon-white/phone.png')} alt="Teléfono" className="w-7 h-7 filter brightness-0 invert contrast-150 drop-shadow-2xl" />
                  </div>
                  <span className="text-twine-100 font-medium">(55) xxxx xxxx</span>
                </div>
                <div className="flex items-center space-x-4 group">
                  <div className="w-12 h-12 bg-twine-700/40 backdrop-blur-sm rounded-xl flex items-center justify-center border border-twine-400/30 shadow-lg group-hover:bg-twine-700/60 transition">
                    <img src={require('../../assets/icons/icon-white/organization.png')} alt="Ubicación" className="w-7 h-7 filter brightness-0 invert contrast-150 drop-shadow-2xl" />
                  </div>
                  <span className="text-twine-100 font-medium">Secretaría de Educación Pública</span>
                </div>
                <div className="flex items-center space-x-4 group">
                  <div className="w-12 h-12 bg-twine-700/40 backdrop-blur-sm rounded-xl flex items-center justify-center border border-twine-400/30 shadow-lg group-hover:bg-twine-700/60 transition">
                    <img src={require('../../assets/icons/icon-white/icon13.ico')} alt="Horario" className="w-7 h-7 filter brightness-0 invert contrast-150 drop-shadow-2xl" />
                  </div>
                  <span className="text-twine-100 font-medium">Lun - Vie: 9:00 - 18:00 hrs</span>
                </div>
                </div>
            </div>
          </div>
        </div>

        {/* Línea separadora */}
        <div className="border-t border-night-800"></div>

        {/* Sección inferior */}
        <div className="py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Derechos de autor */}
            <div className="text-white/60 text-sm text-center md:text-left">
              © {currentYear} SIVOD V2 - Sistema Integral de Votación y Opinión Docente. 
              Todos los derechos reservados.
            </div>

            {/* Enlaces legales */}
            <div className="flex flex-wrap justify-center md:justify-end space-x-6 text-sm">
              <Link to="/privacy" className="text-white/60 hover:text-white transition-colors duration-300">
                Política de Privacidad
              </Link>
              <Link to="/terms" className="text-white/60 hover:text-white transition-colors duration-300">
                Términos de Servicio
              </Link>
              <Link to="/accessibility" className="text-white/60 hover:text-white transition-colors duration-300">
                Accesibilidad
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;