import React, { useState, useRef, useEffect } from "react";
import {
  ExclamationTriangleIcon,
  UserGroupIcon,
  DocumentTextIcon,
  PaintBrushIcon,
  ShieldExclamationIcon,
  QuestionMarkCircleIcon,
  PaperAirplaneIcon,
  ArrowRightIcon,
  CheckCircleIcon,
  XMarkIcon,
  MagnifyingGlassIcon,
  LightBulbIcon,
  LinkIcon,
  DevicePhoneMobileIcon,
  LockClosedIcon
} from '@heroicons/react/24/outline';

const Report = () => {
    const [selectedOption, setSelectedOption] = useState("");
    const [formData, setFormData] = useState({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const formRef = useRef(null);

    // Objeto con configuraciones específicas para cada opción
    const optionConfigs = {
        error: {
            title: "Reporte de Error Técnico",
            icon: <ExclamationTriangleIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "errorDescription",
                    label: "Descripción del error",
                    type: "textarea",
                    placeholder: "Describe exactamente qué salió mal...",
                    icon: <ExclamationTriangleIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "stepsToReproduce",
                    label: "Pasos para reproducir",
                    type: "textarea",
                    placeholder: "1. Primero... 2. Luego...",
                    icon: <MagnifyingGlassIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "frequency",
                    label: "¿Con qué frecuencia ocurre?",
                    type: "select",
                    options: ["Siempre", "A veces", "Raramente", "Solo una vez"],
                    icon: <ArrowRightIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        },
        usabilidad: {
            title: "Problema de Usabilidad",
            icon: <UserGroupIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "task",
                    label: "¿Qué intentabas hacer?",
                    type: "text",
                    placeholder: "Ej: Completar mi perfil...",
                    icon: <UserGroupIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "confusionPoint",
                    label: "Punto de confusión",
                    type: "textarea",
                    placeholder: "¿Qué fue lo que no entendiste?",
                    icon: <QuestionMarkCircleIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "suggestion",
                    label: "Sugerencia de mejora",
                    type: "textarea",
                    placeholder: "¿Cómo crees que debería funcionar?",
                    icon: <LightBulbIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        },
        contenido: {
            title: "Contenido Incorrecto",
            icon: <DocumentTextIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "url",
                    label: "URL del contenido",
                    type: "url",
                    placeholder: "https://...",
                    icon: <LinkIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "currentContent",
                    label: "Contenido actual (incorrecto)",
                    type: "textarea",
                    icon: <DocumentTextIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "correctContent",
                    label: "Contenido correcto",
                    type: "textarea",
                    icon: <CheckCircleIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "source",
                    label: "Fuente de la información correcta",
                    type: "text",
                    placeholder: "Ej: Documentación oficial...",
                    icon: <DocumentTextIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        },
        diseño: {
            title: "Problema de Diseño",
            icon: <PaintBrushIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "element",
                    label: "Elemento con problema",
                    type: "text",
                    placeholder: "Ej: Botón de 'Enviar'...",
                    icon: <PaintBrushIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "issueType",
                    label: "Tipo de problema",
                    type: "checkbox",
                    options: ["No se ve", "Superposición", "Tamaño incorrecto", "Colores", "Otro"],
                    icon: <ExclamationTriangleIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "device",
                    label: "Dispositivo",
                    type: "select",
                    options: ["Desktop", "Mobile", "Tablet", "Todos"],
                    icon: <DevicePhoneMobileIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        },
        seguridad: {
            title: "Problema de Seguridad",
            icon: <ShieldExclamationIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "issueDetail",
                    label: "Describe la vulnerabilidad",
                    type: "textarea",
                    placeholder: "Detalla lo que encontraste...",
                    icon: <ShieldExclamationIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "impact",
                    label: "Impacto potencial",
                    type: "textarea",
                    icon: <ExclamationTriangleIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        },
        otro: {
            title: "Otro Problema",
            icon: <QuestionMarkCircleIcon className="h-6 w-6" />,
            fields: [
                {
                    id: "description",
                    label: "Describe el problema",
                    type: "textarea",
                    placeholder: "Cuéntanos en detalle...",
                    icon: <QuestionMarkCircleIcon className="h-5 w-5 text-twine-300" />
                },
                {
                    id: "category",
                    label: "¿A qué categoría se acerca más?",
                    type: "select",
                    options: ["Técnico", "Contenido", "Diseño", "Funcional", "Otro"],
                    icon: <ArrowRightIcon className="h-5 w-5 text-twine-300" />
                }
            ]
        }
    };

    const options = [
        { value: "error", label: "Error o fallo técnico", icon: <ExclamationTriangleIcon className="h-8 w-8" /> },
        { value: "usabilidad", label: "Dificultad para usar algo", icon: <UserGroupIcon className="h-8 w-8" /> },
        { value: "contenido", label: "Contenido incorrecto", icon: <DocumentTextIcon className="h-8 w-8" /> },
        { value: "diseño", label: "Problema de diseño/visual", icon: <PaintBrushIcon className="h-8 w-8" /> },
        { value: "seguridad", label: "Problema de seguridad", icon: <ShieldExclamationIcon className="h-8 w-8" /> },
        { value: "otro", label: "Otro", icon: <QuestionMarkCircleIcon className="h-8 w-8" /> }
    ];

    // Effect para hacer scroll cuando se selecciona una opción
    useEffect(() => {
        if (selectedOption && formRef.current) {
            setTimeout(() => {
                const topPosition = formRef.current.offsetTop - 100;
                window.scrollTo({
                    top: topPosition,
                    behavior: 'smooth'
                });
            }, 100);
        }
    }, [selectedOption]);

    const handleInputChange = (fieldId, value) => {
        setFormData(prev => ({
            ...prev,
            [fieldId]: value
        }));
    };

    const renderField = (field) => {
        switch (field.type) {
            case 'textarea':
                return (
                    <div className="relative">
                        <textarea
                            className="w-full p-3 pl-10 rounded-lg border border-white/20 bg-white/5 text-white focus:ring-2 focus:ring-twine-300 focus:border-transparent placeholder-white/50"
                            rows="3"
                            placeholder={field.placeholder}
                            value={formData[field.id] || ''}
                            onChange={(e) => handleInputChange(field.id, e.target.value)}
                        />
                        {field.icon && (
                            <div className="absolute left-3 top-3">
                                {field.icon}
                            </div>
                        )}
                    </div>
                );
            case 'select':
                return (
                    <div className="relative">
                        <select
                            className="w-full p-3 pl-10 rounded-lg border border-white/20 bg-white/5 text-white focus:ring-2 focus:ring-twine-300 focus:border-transparent appearance-none"
                            value={formData[field.id] || ''}
                            onChange={(e) => handleInputChange(field.id, e.target.value)}
                        >
                            <option value="" className="bg-gray-800">Selecciona...</option>
                            {field.options.map(opt => (
                                <option key={opt} value={opt} className="bg-gray-800">{opt}</option>
                            ))}
                        </select>
                        {field.icon && (
                            <div className="absolute left-3 top-3">
                                {field.icon}
                            </div>
                        )}
                        <ArrowRightIcon className="absolute right-3 top-3.5 h-5 w-5 text-white/50 transform rotate-90" />
                    </div>
                );
            case 'checkbox':
                return (
                    <div className="space-y-2">
                        <div className="relative">
                            {field.icon && (
                                <div className="absolute left-3 top-3">
                                    {field.icon}
                                </div>
                            )}
                        </div>
                        <div className="grid grid-cols-2 gap-3 mt-4">
                            {field.options.map(opt => (
                                <label key={opt} className="flex items-center p-3 rounded-lg border border-white/20 bg-white/5 hover:bg-white/10 transition-colors">
                                    <input
                                        type="checkbox"
                                        className="mr-3 h-5 w-5 text-twine-300 bg-white/10 border-white/20 rounded"
                                        checked={(formData[field.id] || []).includes(opt)}
                                        onChange={(e) => {
                                            const current = formData[field.id] || [];
                                            const newValue = e.target.checked
                                                ? [...current, opt]
                                                : current.filter(item => item !== opt);
                                            handleInputChange(field.id, newValue);
                                        }}
                                    />
                                    <span className="text-white font-noto">{opt}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                );
            default:
                return (
                    <div className="relative">
                        <input
                            type={field.type}
                            className="w-full p-3 pl-10 rounded-lg border border-white/20 bg-white/5 text-white focus:ring-2 focus:ring-twine-300 focus:border-transparent placeholder-white/50"
                            placeholder={field.placeholder}
                            value={formData[field.id] || ''}
                            onChange={(e) => handleInputChange(field.id, e.target.value)}
                        />
                        {field.icon && (
                            <div className="absolute left-3 top-3">
                                {field.icon}
                            </div>
                        )}
                    </div>
                );
        }
    };

    const handleSubmit = () => {
        const report = {
            type: selectedOption,
            ...formData,
            timestamp: new Date().toISOString()
        };
        console.log("Reporte enviado:", report);
        setIsSubmitted(true);
        
        setTimeout(() => {
            setSelectedOption("");
            setFormData({});
            setIsSubmitted(false);
        }, 3000);
    };

    const handleButtonClick = (optionValue) => {
        setSelectedOption(optionValue);
        setFormData({});
    };

    const getButtonStyle = (index, isSelected) => {
        const isYellow = index % 2 === 1;
        
        const baseClasses = `
            flex flex-col items-center justify-center
            p-6 rounded-xl font-noto transition-all duration-300
            min-h-[140px] border-2 transform
        `;

        if (isSelected) {
            return `${baseClasses} ${
                isYellow 
                ? "bg-twine-500/90 text-white shadow-xl scale-[1.02] border-twine-300" 
                : "bg-white/30 text-white shadow-xl scale-[1.02] border-white"
            }`;
        } else {
            return `${baseClasses} ${
                isYellow 
                ? "bg-twine-500/70 text-white hover:bg-twine-500/80 hover:shadow-lg border-transparent" 
                : "bg-white/20 text-white hover:bg-white/30 hover:shadow-lg border-transparent"
            }`;
        }
    };

    const resetForm = () => {
        setSelectedOption("");
        setFormData({});
        setIsSubmitted(false);
    };

    return (
        <div className="bg-transparent max-w-6xl mx-auto p-4">
            <div className="py-10 mb-8">
                {/* Encabezado con icono */}
                <div className="flex flex-col items-center mb-10">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-twine-300/20 to-white/10 rounded-full mb-4 border border-white/20">
                        <ExclamationTriangleIcon className="h-8 w-8 text-twine-300" />
                    </div>
                    <h3 className="text-3xl font-bold text-twine-300 mb-2 font-patria text-center">
                        Sistema de Reportes
                    </h3>
                    <p className="text-white/70 font-noto text-center max-w-2xl">
                        Ayúdanos a mejorar la plataforma reportando cualquier problema que encuentres
                    </p>
                </div>
                
                {/* Mensaje de éxito */}
                {isSubmitted && (
                    <div className="mb-6 bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-6 text-center">
                        <div className="flex items-center justify-center mb-3">
                            <CheckCircleIcon className="h-12 w-12 text-green-400 mr-3" />
                            <span className="text-xl font-semibold text-white font-patria">
                                ¡Reporte Enviado!
                            </span>
                        </div>
                        <p className="text-white/80 font-noto">
                            Gracias por tu contribución. Revisaremos tu reporte pronto.
                        </p>
                    </div>
                )}

                {/* Botones de selección */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
                    {options.map((option, index) => (
                        <button
                            key={option.value}
                            onClick={() => handleButtonClick(option.value)}
                            className={getButtonStyle(index, selectedOption === option.value)}
                        >
                            <div className={`mb-3 p-3 rounded-full ${
                                index % 2 === 1 ? 'bg-twine-400/30' : 'bg-white/20'
                            }`}>
                                {React.cloneElement(option.icon, { className: "h-10 w-10" })}
                            </div>
                            <span className="font-medium font-noto text-center text-lg">{option.label}</span>
                        </button>
                    ))}
                </div>

                {/* Formulario dinámico */}
                {selectedOption && optionConfigs[selectedOption] && !isSubmitted && (
                    <div 
                        ref={formRef}
                        className="bg-gradient-to-br from-white/10 to-white/5 rounded-2xl shadow-xl p-6 md:p-8 border border-white/20 backdrop-blur-sm"
                    >
                        {/* Encabezado del formulario */}
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8">
                            <div className="flex items-center mb-4 sm:mb-0">
                                <div className="mr-4 p-2 bg-twine-300/20 rounded-lg">
                                    {optionConfigs[selectedOption].icon}
                                </div>
                                <div>
                                    <h4 className="text-2xl font-bold text-twine-300 font-patria">
                                        {optionConfigs[selectedOption].title}
                                    </h4>
                                    <p className="text-white/60 text-sm font-noto">
                                        Completa los detalles del reporte
                                    </p>
                                </div>
                            </div>
                            <button
                                onClick={resetForm}
                                className="flex items-center text-white/70 hover:text-white transition-colors font-noto"
                            >
                                <XMarkIcon className="h-5 w-5 mr-1" />
                                Cambiar categoría
                            </button>
                        </div>

                        {/* Campos específicos */}
                        <div className="space-y-6">
                            {optionConfigs[selectedOption].fields.map((field) => (
                                <div key={field.id}>
                                    <div className="flex items-center mb-3">
                                        {field.icon}
                                        <label className="block text-sm font-semibold text-white ml-2 font-noto">
                                            {field.label}
                                        </label>
                                    </div>
                                    {renderField(field)}
                                </div>
                            ))}
                        </div>

                        {/* Campo común para todos */}
                        <div className="mt-10 pt-8 border-t border-white/20">
                            <div className="flex items-center mb-3">
                                <DocumentTextIcon className="h-5 w-5 text-twine-300 mr-2" />
                                <label className="block text-sm font-semibold text-white font-noto">
                                    Comentarios adicionales
                                </label>
                            </div>
                            <div className="relative">
                                <textarea
                                    className="w-full p-3 pl-10 rounded-lg border border-white/20 bg-white/5 text-white focus:ring-2 focus:ring-twine-300 focus:border-transparent placeholder-white/50"
                                    rows="3"
                                    placeholder="Algo más que quieras añadir..."
                                    value={formData.additionalComments || ''}
                                    onChange={(e) => handleInputChange('additionalComments', e.target.value)}
                                />
                                <DocumentTextIcon className="absolute left-3 top-3 h-5 w-5 text-twine-300" />
                            </div>
                        </div>

                        {/* Botón de envío */}
                        <div className="mt-10 flex justify-end">
                            <button
                                onClick={handleSubmit}
                                className="group flex items-center justify-center bg-gradient-to-r from-twine-400 to-twine-500 text-white px-10 py-4 rounded-xl font-semibold hover:from-twine-500 hover:to-twine-600 transition-all duration-300 shadow-lg hover:shadow-xl font-noto"
                            >
                                <PaperAirplaneIcon className="h-5 w-5 mr-3 group-hover:translate-x-1 transition-transform" />
                                Enviar Reporte
                            </button>
                        </div>
                    </div>
                )}

                {/* Mensaje cuando no hay opción seleccionada */}
                {!selectedOption && !isSubmitted && (
                    <div className="text-center py-12">
                        <QuestionMarkCircleIcon className="h-16 w-16 text-white/30 mx-auto mb-4" />
                        <p className="text-white/50 font-noto text-lg">
                            Selecciona una categoría para comenzar tu reporte
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Report;