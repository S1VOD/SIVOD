import React from 'react';

const InfoModal = ({ isOpen, onClose, title, description, sections, advice }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-md max-h-[85vh] bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header del modal */}
        <div className="bg-gradient-to-r from-twine-600/80 to-twine-800/80 px-6 py-4 border-b border-white/20 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/20">
                <div className="w-5 h-5 bg-gradient-to-r from-white to-twine-100 rounded-sm"></div>
              </div>
              <div>
                <h3 className="text-xl font-patria font-bold text-white">{title}</h3>
                <p className="text-white/80 text-sm font-patria">Información sobre esta sección</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              <div className="w-3 h-3 relative">
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white transform -rotate-45"></div>
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white transform rotate-45"></div>
              </div>
            </button>
          </div>
        </div>

        {/* Contenido del modal con scroll */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {/* Descripción */}
            <div>
              <h4 className="text-white font-patria font-semibold text-lg mb-3">Descripción</h4>
              <p className="text-twine-200 font-patria leading-relaxed text-sm">
                {description}
              </p>
            </div>

            {/* Secciones */}
            {sections && sections.map((section, sectionIndex) => (
              <div key={sectionIndex}>
                <h4 className="text-white font-patria font-semibold text-lg mb-3">
                  {section.title}
                </h4>
                <ul className="space-y-2">
                  {section.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start space-x-3">
                      <div className="w-5 h-5 bg-twine-500/20 rounded-full flex items-center justify-center border border-twine-400/30 mt-0.5 flex-shrink-0">
                        <div className="w-2 h-2 bg-twine-300 rounded-full"></div>
                      </div>
                      <span className="text-twine-200 font-patria leading-relaxed text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            {/* Funcionalidades (para compatibilidad con Dashboard) */}
            {!sections && (
              <div>
                <h4 className="text-white font-patria font-semibold text-lg mb-3">¿Qué puedes hacer aquí?</h4>
                <ul className="space-y-2">
                  {advice && advice.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-5 h-5 bg-twine-500/20 rounded-full flex items-center justify-center border border-twine-400/30 mt-0.5 flex-shrink-0">
                        <div className="w-2 h-2 bg-twine-300 rounded-full"></div>
                      </div>
                      <span className="text-twine-200 font-patria leading-relaxed text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Consejos */}
            <div className="bg-twine-500/10 border border-twine-400/20 rounded-xl p-4">
              <h4 className="text-white font-patria font-semibold text-lg mb-2">💡 Consejos</h4>
              <p className="text-twine-200 font-patria text-sm">
                {advice && typeof advice === 'string' 
                  ? advice 
                  : 'Explora todas las secciones para aprovechar al máximo las funcionalidades disponibles.'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Footer del modal */}
        <div className="bg-white/5 border-t border-white/10 px-6 py-4 flex-shrink-0">
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-6 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm"
            >
              Entendido
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfoModal;