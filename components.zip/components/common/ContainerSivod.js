import React from 'react';
import { 
  LightBulbIcon, 
  FlagIcon,  // Cambiado de TargetIcon a FlagIcon
  EyeIcon, 
  SparklesIcon,
  TrophyIcon,
  HeartIcon,
  ShieldCheckIcon,
  ChatBubbleLeftRightIcon
} from '@heroicons/react/24/outline';

const ContainerSivod = () => {
  return (
    <div className="bg-transparent">
      <div className="container mx-auto px-4 py-8">
        <div className="bg-gradient-to-br from-white/5 to-white/10 rounded-2xl shadow-xl backdrop-blur-sm p-8 border border-white/20">
          {/* Título Principal */}
          <div className="flex items-center justify-center mb-10">
            <TrophyIcon className="h-10 w-10 text-twine-300 mr-4" />
            <h2 className="text-4xl font-bold text-white font-patria text-center">Acerca de Sivod</h2>
          </div>
           
          {/* Que hacemos */}
          <div className="mb-10">
            <div className="relative p-8 bg-gradient-to-r from-white/10 to-white/5 rounded-xl border border-white/25 shadow-lg">
              <div className="flex items-center mb-6">
                <LightBulbIcon className="h-8 w-8 text-twine-300 mr-3" />
                <h3 className='text-2xl font-semibold text-twine-300 font-patria'>Qué Hacemos</h3>
              </div>
              <p className="text-white font-noto text-justify leading-relaxed text-lg">
                En SIVOD somos una plataforma dedicada a reconocer y valorar el esfuerzo, la dedicación y el impacto que los docentes generan en la comunidad estudiantil. Nuestro principal propósito es visibilizar su labor, resaltar su compromiso diario y otorgarles el lugar que merecen dentro del desarrollo académico y social de México.
                <br /><br />
                A través de un sistema de votación moderno, transparente y único, permitimos que estudiantes, tutores y directivos puedan expresar su reconocimiento hacia quienes inspiran, acompañan y transforman vidas dentro de las aulas.
              </p>
            </div>
          </div>
          
          {/* Misión y Visión */}
          <div className="grid md:grid-cols-2 gap-8 mb-10">
            {/* Misión */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/25 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-5">
                <FlagIcon className="h-7 w-7 text-twine-300 mr-3" /> {/* Cambiado aquí */}
                <h3 className="text-2xl font-semibold text-twine-300 font-patria">Nuestra Misión</h3>
              </div>
              <p className="text-white font-noto text-justify leading-relaxed">
                Reconocer y honrar a los docentes mexicanos que demuestran excelencia en su labor excepcional, promoviendo un sistema de votación transparente, legítima y única. Integramos un buzón de mejora continua para tener en cuenta la opinión de la comunidad educativa y padres de familia, fomentando la participación activa y el compromiso con la calidad educativa.
              </p>
            </div>

            {/* Visión */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/25 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center mb-5">
                <EyeIcon className="h-7 w-7 text-twine-300 mr-3" />
                <h3 className="text-2xl font-semibold text-twine-300 font-patria">Nuestra Visión</h3>
              </div>
              <p className="text-white font-noto leading-relaxed">
                Aspiramos a un México donde la sociedad en su conjunto celebre y respalde la labor de sus docentes, y donde la educación sea el fruto de una colaboración dinámica e innovadora entre todos los actores del proceso formativo.
              </p>
            </div>
          </div>

          {/* Valores */}
          <div className="mb-8">
            <div className="flex items-center justify-center mb-8">
              <SparklesIcon className="h-8 w-8 text-twine-300 mr-3" />
              <h3 className="text-2xl font-semibold text-twine-300 font-patria">Nuestros Valores</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Innovación */}
              <div className="group text-center p-8 bg-gradient-to-b from-white/10 to-transparent rounded-xl border border-white/25 shadow-lg hover:border-twine-300/50 transition-all duration-300">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-white/10 rounded-full mb-4 group-hover:bg-twine-300/20 transition-colors duration-300">
                  <LightBulbIcon className="h-7 w-7 text-twine-300" />
                </div>
                <h4 className="font-bold text-xl text-white mb-3 font-patria">Innovación</h4>
                <p className="text-white/90 font-noto">Siempre buscamos nuevas y mejores formas de hacer las cosas</p>
              </div>
              
              {/* Calidad */}
              <div className="group text-center p-8 bg-gradient-to-b from-white/10 to-transparent rounded-xl border border-white/25 shadow-lg hover:border-twine-300/50 transition-all duration-300">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-white/10 rounded-full mb-4 group-hover:bg-twine-300/20 transition-colors duration-300">
                  <HeartIcon className="h-7 w-7 text-twine-300" />
                </div>
                <h4 className="font-bold text-xl text-white mb-3 font-patria">Calidad</h4>
                <p className="text-white/90 font-noto">Comprometidos con la excelencia en todo lo que hacemos</p>
              </div>
              
              {/* Integridad */}
              <div className="group text-center p-8 bg-gradient-to-b from-white/10 to-transparent rounded-xl border border-white/25 shadow-lg hover:border-twine-300/50 transition-all duration-300">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-white/10 rounded-full mb-4 group-hover:bg-twine-300/20 transition-colors duration-300">
                  <ShieldCheckIcon className="h-7 w-7 text-twine-300" />
                </div>
                <h4 className="font-bold text-xl text-white mb-3 font-patria">Integridad</h4>
                <p className="text-white/90 font-noto">Actuamos con honestidad y transparencia en todas nuestras relaciones</p>
              </div>
            </div>
            
            {/* Mensaje final */}
            <div className="mt-10 pt-8 border-t border-white/20">
              <div className="flex items-center justify-center">
                <ChatBubbleLeftRightIcon className="h-6 w-6 text-twine-300 mr-3" />
                <p className="text-center text-white/80 font-noto italic">
                  "Porque construir un mañana más digno empieza por reconocer a quienes forman el presente."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContainerSivod;