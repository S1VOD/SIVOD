import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

// Importa Logo
import logoQuetzalcoatl from '../../assets/images/Logo.gif';
import logoGobierno from '../../assets/images/Logos-GobiernoV3.png';

const Header = () => {
  const location = useLocation();
  const isLoggedIn = localStorage.getItem('token');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full bg-night-1000 z-50 border-b border-night-900 shadow-lg">
      <div className="container mx-auto px-2 sm:px-4">
        <div className="flex items-center justify-between py-3 lg:py-5">
          {/* Logos del Gobierno a la izquierda */}
          <div className="flex-shrink-0 w-1/3 lg:w-auto min-w-[100px] lg:min-w-0">
            <img 
              src={logoGobierno} 
              alt="Gobierno de México"
              className="h-8 lg:h-12 object-contain max-w-[100px] lg:max-w-none"
              onError={(e) => {
                e.target.style.display = 'none';
              }}
            />
          </div>
{/* Logo SIVOD centrado */}
<div className="absolute left-1/2 transform -translate-x-1/2 flex justify-center pointer-events-auto">
  <Link 
    to={isLoggedIn ? "/dashboard" : "/"}  
    className="flex items-center justify-center group" 
    onClick={() => setIsMobileMenuOpen(false)}
  >
    <div className="relative flex items-center justify-center">
      {/* Contenedor ajustado para mostrar el logo completo */}
      <div className="h-20 lg:h-22 flex items-center justify-center overflow-visible bg-transparent mx-2">
        <img 
          src={logoQuetzalcoatl} 
          alt="Quetzalcóatl - Serpiente Emplumada"
          className="h-full w-auto object-contain max-h-14 lg:max-h-24"
          style={{ imageRendering: 'auto' }} 
          onError={(e) => {
            e.target.style.display = 'none';
            const fallback = document.createElement('div');
            fallback.className = 'h-14 lg:h-24 w-14 lg:w-24 bg-night-800 rounded-lg flex items-center justify-center shadow-lg';
            fallback.innerHTML = '<span class="text-white font-bold text-lg lg:text-xl">S</span>';
            e.target.parentNode.appendChild(fallback);
          }}
        />
      </div>
    </div>
  </Link>
</div>
          {/* Botón menú hamburguesa para móvil */}
          <div className="lg:hidden w-1/3 flex justify-end min-w-[60px]">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white p-2 focus:outline-none"
              aria-label="Menú"
            >
              <div className="w-6 h-6 flex flex-col justify-between">
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? 'rotate-45 translate-y-2.5' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? 'opacity-0' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? '-rotate-45 -translate-y-2.5' : ''}`}></span>
              </div>
            </button>
          </div>

          {/* Navegación para escritorio */}
          <nav className="hidden lg:flex items-center space-x-3">
            {isLoggedIn ? (
              <>
                <Link 
                  to="/dashboard" 
                  className={`px-4 py-2 rounded-lg transition-all duration-300 font-semibold ${
                    location.pathname === '/dashboard' 
                      ? 'bg-white text-night-1000 shadow-lg' 
                      : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                  }`}
                >
                  Inicio
                </Link>
                <Link 
                  to="/evaluation" 
                  className={`px-4 py-2 rounded-lg transition-all duration-300 font-semibold ${
                    location.pathname === '/evaluation' 
                      ? 'bg-white text-night-1000 shadow-lg' 
                      : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                  }`}
                >
                  Evaluación
                </Link>
                <Link 
                  to="/profile" 
                  className={`px-4 py-2 rounded-lg transition-all duration-300 font-semibold ${
                    location.pathname === '/profile' 
                      ? 'bg-white text-night-1000 shadow-lg' 
                      : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                  }`}
                >
                  Perfil
                </Link>
                <button 
                  className="px-4 py-2 bg-white text-night-1000 rounded-lg hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl flex items-center gap-2 border border-white"
                  onClick={() => {
                    localStorage.removeItem('token');
                    window.location.href = '/';
                  }}
                >
                  Cerrar Sesión
                </button>
              </>
            ) : (
              <div className="actions-section">
                 <a 
                   href="https://www.gob.mx/tramites" 
                   className="text-white/90 hover:text-white transition-colors duration-300 font-semibold px-4 py-2 rounded-lg hover:bg-white/10 border border-transparent"
                   target="_blank" 
                   rel="noopener noreferrer" 
                   aria-label="Ir a trámites del Gobierno de México"
                 >
                  Trámites Gobierno
                 </a>
              </div>
            )}
          </nav>
        </div>

        {/* Menú móvil */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-night-1000 border-t border-night-900 py-4">
            <nav className="flex flex-col space-y-3">
              {isLoggedIn ? (
                <>
                  <Link 
                    to="/dashboard" 
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      location.pathname === '/dashboard' 
                        ? 'bg-white text-night-1000 shadow-lg' 
                        : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Inicio
                  </Link>
                  <Link 
                    to="/evaluation" 
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      location.pathname === '/evaluation' 
                        ? 'bg-white text-night-1000 shadow-lg' 
                        : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Evaluación
                  </Link>
                  <Link 
                    to="/profile" 
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      location.pathname === '/profile' 
                        ? 'bg-white text-night-1000 shadow-lg' 
                        : 'text-white/90 hover:bg-white/10 hover:text-white border border-transparent'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Perfil
                  </Link>
                  <button 
                    className="px-4 py-3 bg-white text-night-1000 rounded-lg hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl flex items-center justify-center gap-2 border border-white"
                    onClick={() => {
                      localStorage.removeItem('token');
                      window.location.href = '/';
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Cerrar Sesión
                  </button>
                </>
              ) : (
                <div className="actions-section">
                  <a 
                    href="https://www.gob.mx/tramites" 
                    className="text-white/90 hover:text-white transition-colors duration-300 font-semibold px-4 py-3 rounded-lg hover:bg-white/10 border border-transparent text-center block"
                    target="_blank" 
                    rel="noopener noreferrer" 
                    aria-label="Ir a trámites del Gobierno de México"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Trámites Gobierno
                  </a>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;