import Swal from 'sweetalert2';

// Configuración global de SweetAlert2 con diseño glassmorphism
const createAlertConfig = (iconType = '') => ({
  customClass: {
    popup: 'glass-popup',
    title: 'glass-title',
    htmlContainer: 'glass-container',
    confirmButton: 'glass-confirm-btn',
    cancelButton: 'glass-cancel-btn',
    icon: 'glass-icon',
  },
  buttonsStyling: false,
  backdrop: 'rgba(0, 0, 0, 0.7)',
  allowOutsideClick: false,
  allowEscapeKey: true,
  showClass: {
    popup: 'animate__animated animate__fadeInUp'
  },
  hideClass: {
    popup: 'animate__animated animate__fadeOutDown'
  },
  scrollbarPadding: false
});

// Agregar estilos CSS dinámicamente para glassmorphism
const injectGlassStyles = () => {
  if (document.getElementById('glass-styles')) return;
  
  const style = document.createElement('style');
  style.id = 'glass-styles';
  style.innerHTML = `
    .glass-popup {
      background: rgba(18, 18, 30, 0.95) !important;
      backdrop-filter: blur(20px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(20px) saturate(180%) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      border-radius: 20px !important;
      box-shadow: 
        0 8px 32px rgba(0, 0, 0, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.1) !important;
      padding: 2rem !important;
    }
    
    .glass-title {
      color: white !important;
      font-family: 'Patria', serif !important;
      font-weight: bold !important;
      font-size: 1.5rem !important;
      text-align: center !important;
      margin-bottom: 1rem !important;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3) !important;
    }
    
    .glass-container {
      color: rgba(255, 255, 255, 0.85) !important;
      font-family: 'Patria', serif !important;
      font-size: 1rem !important;
      text-align: center !important;
      line-height: 1.5 !important;
      margin-bottom: 1.5rem !important;
    }
    
    .glass-confirm-btn {
      background: linear-gradient(135deg, 
        rgba(168, 125, 74, 0.9) 0%, 
        rgba(145, 100, 61, 0.9) 100%) !important;
      backdrop-filter: blur(10px) !important;
      -webkit-backdrop-filter: blur(10px) !important;
      border: 1px solid rgba(255, 255, 255, 0.2) !important;
      color: white !important;
      font-family: 'Patria', serif !important;
      font-weight: 600 !important;
      font-size: 1rem !important;
      padding: 0.75rem 2rem !important;
      border-radius: 12px !important;
      transition: all 0.3s ease !important;
      box-shadow: 
        0 4px 15px rgba(168, 125, 74, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
      margin: 0.5rem !important;
    }
    
    .glass-confirm-btn:hover {
      transform: translateY(-2px) !important;
      box-shadow: 
        0 6px 20px rgba(168, 125, 74, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
      background: linear-gradient(135deg, 
        rgba(168, 125, 74, 1) 0%, 
        rgba(145, 100, 61, 1) 100%) !important;
    }
    
    .glass-confirm-btn:active {
      transform: translateY(0) !important;
    }
    
    .glass-cancel-btn {
      background: rgba(255, 255, 255, 0.1) !important;
      backdrop-filter: blur(10px) !important;
      -webkit-backdrop-filter: blur(10px) !important;
      border: 1px solid rgba(255, 255, 255, 0.2) !important;
      color: white !important;
      font-family: 'Patria', serif !important;
      font-weight: 600 !important;
      font-size: 1rem !important;
      padding: 0.75rem 2rem !important;
      border-radius: 12px !important;
      transition: all 0.3s ease !important;
      margin: 0.5rem !important;
    }
    
    .glass-cancel-btn:hover {
      background: rgba(255, 255, 255, 0.15) !important;
      transform: translateY(-2px) !important;
      border-color: rgba(255, 255, 255, 0.3) !important;
    }
    
    .glass-icon {
      border: none !important;
      background: none !important;
      margin: 1rem auto !important;
    }
    
    /* Iconos con efecto glass */
    .swal2-success [class^=swal2-success-line] {
      background-color: #10B981 !important;
    }
    
    .swal2-error [class^=swal2-x-mark-line] {
      background-color: #EF4444 !important;
    }
    
    .swal2-warning [class^=swal2-warning-ring] {
      border-color: #F59E0B !important;
    }
    
    .swal2-info [class^=swal2-info-ring] {
      border-color: #3B82F6 !important;
    }
    
    /* Fondo del backdrop */
    .swal2-backdrop-show {
      background: rgba(0, 0, 0, 0.8) !important;
      backdrop-filter: blur(5px) !important;
      -webkit-backdrop-filter: blur(5px) !important;
    }
    
    /* Animaciones */
    @keyframes glassPulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.8; }
    }
    
    .loading-glass {
      position: relative;
      width: 80px;
      height: 80px;
      margin: 1rem auto;
    }
    
    .loading-glass::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, 
        rgba(168, 125, 74, 0.3) 0%, 
        rgba(145, 100, 61, 0.3) 100%);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border-radius: 50%;
      border: 2px solid rgba(255, 255, 255, 0.1);
      animation: glassPulse 1.5s ease-in-out infinite;
    }
    
    .loading-glass::after {
      content: '';
      position: absolute;
      top: 10px;
      left: 10px;
      right: 10px;
      bottom: 10px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }
  `;
  
  document.head.appendChild(style);
};

// Inyectar estilos cuando se importa el módulo
injectGlassStyles();

// Alertas predefinidas
export const AlertService = {
  // Alerta de éxito
  success: async (title, text, confirmButtonText = 'Entendido') => {
    return await Swal.fire({
      ...createAlertConfig('success'),
      icon: 'success',
      iconColor: '#10B981',
      title,
      text,
      confirmButtonText,
      showCancelButton: false,
    });
  },

  // Alerta de error
  error: async (title, text, confirmButtonText = 'Intentar de nuevo') => {
    return await Swal.fire({
      ...createAlertConfig('error'),
      icon: 'error',
      iconColor: '#EF4444',
      title,
      text,
      confirmButtonText,
      showCancelButton: false,
    });
  },

  // Alerta de advertencia
  warning: async (title, text, confirmButtonText = 'Entendido') => {
    return await Swal.fire({
      ...createAlertConfig('warning'),
      icon: 'warning',
      iconColor: '#F59E0B',
      title,
      text,
      confirmButtonText,
      showCancelButton: false,
    });
  },

  // Alerta de información
  info: async (title, text, confirmButtonText = 'Continuar') => {
    return await Swal.fire({
      ...createAlertConfig('info'),
      icon: 'info',
      iconColor: '#3B82F6',
      title,
      text,
      confirmButtonText,
      showCancelButton: false,
    });
  },

  // Alerta de confirmación
  confirm: async (title, text, confirmButtonText = 'Sí', cancelButtonText = 'No') => {
    return await Swal.fire({
      ...createAlertConfig('question'),
      icon: 'question',
      iconColor: '#8B5CF6',
      title,
      text,
      confirmButtonText,
      cancelButtonText,
      showCancelButton: true,
    });
  },

  // Alerta de carga
  loading: async (title = 'Procesando...', text = 'Por favor espera') => {
    return await Swal.fire({
      title: `
        <div style="text-align: center;">
          <div class="loading-glass"></div>
          <h3 style="color: white; font-family: 'Patria', serif; margin-top: 1rem; font-size: 1.25rem;">${title}</h3>
          <p style="color: rgba(255, 255, 255, 0.7); font-family: 'Patria', serif; margin-top: 0.5rem;">${text}</p>
        </div>
      `,
      customClass: {
        popup: 'glass-popup',
        title: 'glass-title',
        htmlContainer: 'glass-container',
      },
      showConfirmButton: false,
      showCancelButton: false,
      allowOutsideClick: false,
      allowEscapeKey: false,
      didOpen: () => {
        Swal.showLoading();
      },
    });
  },

  // Cerrar alerta
  close: () => {
    Swal.close();
  },

  // Toast notification
  toast: (title, icon = 'success', timer = 3000) => {
    return Swal.fire({
      toast: true,
      position: 'top-end',
      icon,
      title,
      showConfirmButton: false,
      timer,
      timerProgressBar: true,
      customClass: {
        popup: 'glass-popup',
        timerProgressBar: 'glass-confirm-btn',
      },
      background: 'rgba(18, 18, 30, 0.95)',
      backdrop: 'transparent',
      showClass: {
        popup: 'animate__animated animate__fadeInRight'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutRight'
      }
    });
  }
};

export default AlertService;