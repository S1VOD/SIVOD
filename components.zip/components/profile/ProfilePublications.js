import React, { useState, useEffect } from 'react';
import {
  HeartIcon,
  EyeIcon,
  ChatBubbleLeftRightIcon,
  ChartBarIcon,
  PencilIcon,
  TrashIcon,
  StarIcon as StarIconOutline,
  ClockIcon,
  PlusIcon,
  ExclamationCircleIcon,
  ArrowPathIcon,
  PhotoIcon,
  AcademicCapIcon,
  UserCircleIcon,
  Bars3Icon,
  XMarkIcon
} from '@heroicons/react/24/outline';
import { 
  StarIcon as StarIconSolid,
  HeartIcon as HeartIconSolid 
} from '@heroicons/react/24/solid';

const ProfilePublications = () => {
  const [activeTab, setActiveTab] = useState('todas');
  const [currentUser, setCurrentUser] = useState(null);
  const [publicaciones, setPublicaciones] = useState([]);
  const [encuestas, setEncuestas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [likingPublication, setLikingPublication] = useState(null);
  const [commentCounts, setCommentCounts] = useState({});
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const API_URL = 'http://localhost:8000';

  useEffect(() => {
    const getUserData = () => {
      try {
        const userProfileStr = localStorage.getItem('userProfile');
        if (userProfileStr) {
          const userProfile = JSON.parse(userProfileStr);
          if (userProfile && userProfile.id) {
            const userData = {
              id: userProfile.id,
              nombre: userProfile.nombre || '',
              ape_pa: userProfile.ape_pa || '',
              ape_ma: userProfile.ape_ma || '',
              userType: localStorage.getItem('userType') || userProfile.userType || 'educativo',
              role: userProfile.role || 'docente',
              escuela_id: userProfile.escuela_id || null,
              escuela_nombre: userProfile.escuela_nombre || '',
              correo: userProfile.email || userProfile.correo || ''
            };
            setCurrentUser(userData);
            return userData;
          }
        }

        const userDataStr = localStorage.getItem('userData');
        if (userDataStr) {
          const userData = JSON.parse(userDataStr);
          const enhancedUser = {
            ...userData,
            userType: localStorage.getItem('userType') || userData.userType || 'educativo',
            role: userData.role || 'docente',
            id: userData.id || userData.id_edu || userData.id_adm || userData.id_tut || userData.id_alu
          };
          setCurrentUser(enhancedUser);
          return enhancedUser;
        }
      } catch (error) {
        console.error('Error al cargar datos del usuario:', error);
      }
      return null;
    };

    const user = getUserData();
    if (user) {
      fetchUserPublications(user);
      fetchUserSurveys(user);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchUserPublications = async (user) => {
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        setError('No estás autenticado');
        setLoading(false);
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/publications`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        mode: 'cors',
        credentials: 'omit'
      });

      if (response.ok) {
        const data = await response.json();
        
        // Filtrar solo las publicaciones del usuario actual
        const userPublications = (data.publications || []).filter(pub => {
          if (pub.autor_tipo && pub.autor_id) {
            return pub.autor_tipo === user.userType && pub.autor_id === user.id;
          }
          return pub.id_educativo === user.id;
        }).map(pub => {
          const authorName = pub.autor_nombre || `${user.nombre || ''} ${user.ape_pa || ''}`.trim() || 'Usuario';
          
          return {
            id: pub.id_pub,
            type: 'publicacion',
            titulo: pub.titulo || 'Sin título',
            contenido: pub.contenido || '',
            fecha: new Date(pub.fecha_publicacion),
            likes: pub.likes || 0,
            vistas: pub.vistas || 0,
            total_comentarios: pub.total_comentarios || 0,
            etiquetas: pub.tipo_publicacion ? [pub.tipo_publicacion] : ['general'],
            imagen_url: pub.imagen_url,
            es_destacado: pub.es_destacado || pub.destacada === 1 || pub.likes >= 50,
            id_educativo: pub.id_educativo,
            autor_tipo: pub.autor_tipo,
            autor_id: pub.autor_id,
            escuela_id: pub.escuela_id,
            tipo_publicacion: pub.tipo_publicacion || 'general',
            author: {
              name: authorName,
              role: pub.role || user.role || 'Usuario',
              userType: pub.autor_tipo || user.userType || 'educativo'
            }
          };
        });

        // Ordenar por fecha (más recientes primero)
        const sortedPublications = userPublications.sort((a, b) => 
          new Date(b.fecha) - new Date(a.fecha)
        );

        setPublicaciones(sortedPublications);
      } else if (response.status === 403) {
        setError('Los usuarios administrativos no tienen acceso al sistema de publicaciones.');
      } else {
        setError('Error al cargar publicaciones');
      }
    } catch (err) {
      console.error('Error al cargar publicaciones:', err);
      setError('Error de conexión');
    }
  };

  const fetchUserSurveys = async (user) => {
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/surveys`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        mode: 'cors',
        credentials: 'omit'
      });

      if (response.ok) {
        const data = await response.json();
        
        // Filtrar solo las encuestas creadas por el usuario actual
        const userSurveys = (data.surveys || []).filter(survey => {
          return survey.tipo_creador === user.userType && survey.id_creador === user.id;
        }).map(survey => ({
          id: survey.id_encuesta || 0,
          type: 'encuesta',
          titulo: String(survey.titulo || 'Sin título'),
          descripcion: String(survey.descripcion || ''),
          pregunta: String(survey.pregunta || ''),
          fecha: new Date(survey.fecha_creacion),
          fecha_cierre: survey.fecha_cierre || null,
          total_respuestas: Number(survey.total_respuestas) || 0,
          usuario_ya_respondio: survey.usuario_ya_respondio === 1,
          esta_cerrada: survey.esta_cerrada || false,
          id_creador: survey.id_creador || null,
          tipo_creador: survey.tipo_creador || 'educativo',
          es_creador: true
        }));

        // Ordenar por fecha (más recientes primero)
        const sortedSurveys = userSurveys.sort((a, b) => 
          new Date(b.fecha) - new Date(a.fecha)
        );

        setEncuestas(sortedSurveys);
      }
    } catch (err) {
      console.error('Error al cargar encuestas:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLikePublication = async (publicationId, currentLikes) => {
    if (likingPublication === publicationId) return;

    setLikingPublication(publicationId);

    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado. Por favor, inicia sesión nuevamente.');
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}/like`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();

        setPublicaciones(prevData =>
          prevData.map(item => {
            if (item.id === publicationId) {
              return {
                ...item,
                likes: result.likes,
                es_destacado: result.es_destacado
              };
            }
            return item;
          })
        );

        if (result.es_destacado && currentLikes < 50) {
          setTimeout(() => {
            alert('¡Esta publicación ahora es destacada!');
          }, 300);
        }
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.detail || 'No se pudo dar like a la publicación'}`);
      }
    } catch (error) {
      console.error('Error al dar like:', error);
      alert('Error al dar like. Por favor, intenta nuevamente.');
    } finally {
      setLikingPublication(null);
    }
  };

  const handleDeletePublication = async (publicationId, publicationTitle) => {
    if (!window.confirm(`¿Estás seguro de que deseas eliminar la publicación "${publicationTitle || 'esta publicación'}"?\n\nEsta acción no se puede deshacer.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado. Por favor, inicia sesión nuevamente.');
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/publications/${publicationId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        alert(result.message || 'Publicación eliminada exitosamente');
        setPublicaciones(prev => prev.filter(item => item.id !== publicationId));
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.detail || 'No se pudo eliminar la publicación'}`);
      }
    } catch (error) {
      console.error('Error al eliminar publicación:', error);
      alert('Error al eliminar la publicación. Por favor, intenta nuevamente.');
    }
  };

  const handleDeleteSurvey = async (surveyId, surveyTitle) => {
    if (!window.confirm(`¿Estás seguro de que deseas eliminar la encuesta "${surveyTitle || 'esta encuesta'}"?\n\nADVERTENCIA: Esta acción eliminará:\n• Todas las respuestas asociadas\n• Los datos estadísticos\n• La encuesta completa`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado. Por favor, inicia sesión nuevamente.');
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/surveys/${surveyId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        alert(result.message || 'Encuesta eliminada exitosamente');
        setEncuestas(prev => prev.filter(item => item.id !== surveyId));
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.detail || 'No se pudo eliminar la encuesta'}`);
      }
    } catch (error) {
      console.error('Error al eliminar encuesta:', error);
      alert('Error al eliminar la encuesta. Por favor, intenta nuevamente.');
    }
  };

  const handleViewSurveyStats = async (surveyId) => {
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        alert('No estás autenticado');
        return;
      }

      const response = await fetch(`${API_URL}/api/v1/surveys/${surveyId}/responses`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        alert(`Esta encuesta tiene ${data.total_responses} respuestas.\n\nPuedes ver las respuestas detalladas en el panel de estadísticas.`);
      } else {
        const errorData = await response.json();
        alert(errorData.detail || 'No puedes ver las respuestas de esta encuesta');
      }
    } catch (error) {
      console.error('Error al obtener estadísticas:', error);
      alert('Error al obtener estadísticas');
    }
  };

  const getUserRoleLabel = (userType, role) => {
    const roleLabels = {
      'educativo': {
        'director': 'Director',
        'docente': 'Docente',
        'admin': 'Administrador'
      },
      'administrativo': {
        'administrativo': 'Administrativo'
      },
      'tutor': {
        'tutor': 'Tutor'
      },
      'alumno': {
        'alumno': 'Estudiante'
      }
    };
    return roleLabels[userType]?.[role] || 'Usuario';
  };

  const filtrarPublicaciones = (tipo) => {
    const combinedItems = [
      ...publicaciones.map(pub => ({ ...pub, combinedType: 'publicacion' })),
      ...encuestas.map(enc => ({ ...enc, combinedType: 'encuesta' }))
    ];

    if (tipo === 'todas') return combinedItems;
    if (tipo === 'publicacion') return publicaciones;
    if (tipo === 'encuesta') return encuestas;
    return combinedItems;
  };

  const handleRefresh = () => {
    setLoading(true);
    setError(null);
    if (currentUser) {
      fetchUserPublications(currentUser);
      fetchUserSurveys(currentUser);
    }
  };

  if (loading) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl lg:rounded-2xl p-4 lg:p-6 border border-white/20">
        <div className="text-center py-8 lg:py-12">
          <div className="w-12 h-12 lg:w-16 lg:h-16 bg-white/10 rounded-xl lg:rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20 animate-pulse">
            <ArrowPathIcon className="w-6 h-6 lg:w-8 lg:h-8 text-twine-400 animate-spin" />
          </div>
          <p className="text-twine-200 font-patria text-base lg:text-lg mb-2">Cargando publicaciones...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl lg:rounded-2xl p-4 lg:p-6 border border-white/20">
        <div className="text-center py-8 lg:py-12">
          <div className="w-12 h-12 lg:w-16 lg:h-16 bg-red-500/20 rounded-xl lg:rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-400/30">
            <ExclamationCircleIcon className="w-6 h-6 lg:w-8 lg:h-8 text-red-400" />
          </div>
          <p className="text-red-200 font-patria text-base lg:text-lg mb-2">Error al cargar</p>
          <p className="text-red-300 font-patria text-xs lg:text-sm mb-4">{error}</p>
          <button
            onClick={handleRefresh}
            className="flex items-center space-x-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-4 py-2 rounded-lg lg:rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm"
          >
            <ArrowPathIcon className="w-4 h-4" />
            <span>Reintentar</span>
          </button>
        </div>
      </div>
    );
  }

  const filteredItems = filtrarPublicaciones(activeTab);

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl lg:rounded-2xl p-4 lg:p-6 border border-white/20">
      {/* Header responsivo */}
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4 mb-6">
        <div className="flex justify-between items-center lg:block">
          <div>
            <h2 className="text-xl lg:text-2xl font-patria font-bold text-white">Mis Publicaciones</h2>
            <div className="flex items-center flex-wrap gap-1 lg:gap-2 mt-1">
              <div className="flex items-center space-x-1">
                <UserCircleIcon className="w-3 h-3 lg:w-4 lg:h-4 text-twine-300" />
                <p className="text-twine-200 font-patria text-xs lg:text-sm">
                  Publicaciones de <span className="text-white font-semibold truncate max-w-[120px] lg:max-w-none inline-block">
                    {currentUser?.nombre} {currentUser?.ape_pa}
                  </span>
                </p>
              </div>
              <span className="text-twine-300 hidden lg:inline">•</span>
              <div className="flex items-center space-x-1">
                <AcademicCapIcon className="w-3 h-3 lg:w-4 lg:h-4 text-twine-300" />
                <span className="text-twine-300 text-xs lg:text-sm">
                  {getUserRoleLabel(currentUser?.userType, currentUser?.role)}
                </span>
              </div>
            </div>
          </div>
          
          {/* Botón menú móvil */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center border border-white/20"
            aria-label="Menú"
          >
            {mobileMenuOpen ? (
              <XMarkIcon className="w-5 h-5 text-white" />
            ) : (
              <Bars3Icon className="w-5 h-5 text-white" />
            )}
          </button>
        </div>
        
        {/* Botones de acción - Desktop */}
        <div className="hidden lg:flex space-x-2">
          <button
            onClick={handleRefresh}
            className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-xl hover:bg-white/20 transition-all duration-300 font-patria text-sm"
          >
            <ArrowPathIcon className="w-4 h-4" />
            <span>Actualizar</span>
          </button>
        </div>
      </div>

      {/* Menú móvil desplegable */}
      {mobileMenuOpen && (
        <div className="lg:hidden mb-4 animate-fadeIn">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 space-y-2">
            <button
              onClick={handleRefresh}
              className="flex items-center justify-center space-x-2 w-full bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/20 transition-all duration-300 font-patria text-sm"
            >
              <ArrowPathIcon className="w-4 h-4" />
              <span>Actualizar publicaciones</span>
            </button>
          </div>
        </div>
      )}

      {/* Filtros responsivos */}
      <div className="flex flex-wrap gap-2 lg:space-x-4 mb-6">
        {['todas', 'publicacion', 'encuesta'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1.5 lg:px-4 lg:py-2 rounded-lg lg:rounded-xl font-patria transition-all duration-300 text-sm lg:text-base ${
              activeTab === tab
                ? tab === 'encuesta'
                  ? 'bg-yellow-500/20 text-white border border-yellow-400/30'
                  : 'bg-twine-500/20 text-white border border-twine-400/30'
                : 'bg-white/5 text-twine-200 hover:bg-white/10 hover:text-white border border-white/10'
            }`}
          >
            {tab === 'todas' && `Todas (${filteredItems.length})`}
            {tab === 'publicacion' && `Public. (${publicaciones.length})`}
            {tab === 'encuesta' && `Encuestas (${encuestas.length})`}
          </button>
        ))}
      </div>

      {/* Lista de publicaciones */}
      <div className="space-y-4 lg:space-y-6">
        {filteredItems.length === 0 ? (
          <div className="text-center py-8 lg:py-12">
            <div className="w-16 h-16 lg:w-20 lg:h-20 bg-white/10 rounded-xl lg:rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
              {activeTab === 'encuesta' ? (
                <ChartBarIcon className="w-6 h-6 lg:w-8 lg:h-8 text-twine-400" />
              ) : activeTab === 'publicacion' ? (
                <ChatBubbleLeftRightIcon className="w-6 h-6 lg:w-8 lg:h-8 text-twine-400" />
              ) : (
                <ChatBubbleLeftRightIcon className="w-6 h-6 lg:w-8 lg:h-8 text-twine-400" />
              )}
            </div>
            <p className="text-twine-200 font-patria text-base lg:text-lg mb-2">
              No hay {activeTab !== 'todas' ? activeTab + 's' : 'publicaciones'}
            </p>
            <p className="text-twine-300 font-patria text-sm lg:text-base max-w-md mx-auto px-4">
              {activeTab === 'publicacion' 
                ? 'Aún no has creado publicaciones. Comparte tus experiencias y conocimientos con la comunidad educativa.'
                : activeTab === 'encuesta'
                ? 'Aún no has creado encuestas. Crea encuestas para conocer la opinión de otros miembros de la comunidad.'
                : 'No has creado publicaciones ni encuestas todavía. ¡Comparte tu primer contenido!'
              }
            </p>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div 
              key={item.id} 
              className={`bg-white/10 backdrop-blur-md rounded-xl lg:rounded-2xl p-4 lg:p-6 border transition-all duration-300 hover:border-white/30 relative ${
                item.type === 'encuesta'
                  ? 'border-yellow-500/40 bg-gradient-to-br from-white/10 to-yellow-500/5'
                  : item.es_destacado
                    ? 'border-yellow-500/40 bg-gradient-to-br from-white/10 to-yellow-500/5'
                    : 'border-white/20'
              }`}
            >
              {/* Badge destacado o encuesta */}
              {(item.type === 'publicacion' && item.es_destacado) || item.type === 'encuesta' ? (
                <div className="absolute -top-1 -right-1 lg:-top-2 lg:-right-2 z-10">
                  <div className={`flex items-center space-x-1 px-2 py-0.5 lg:px-3 lg:py-1 rounded-full text-xs font-bold font-patria shadow-lg border ${
                    item.type === 'encuesta' 
                      ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white border-yellow-400' 
                      : 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white border-yellow-400'
                  }`}>
                    {item.type === 'encuesta' ? (
                      <>
                        <ChartBarIcon className="w-2 h-2 lg:w-3 lg:h-3" />
                        <span className="hidden sm:inline">ENCUESTA</span>
                        <span className="sm:hidden">ENC</span>
                      </>
                    ) : (
                      <>
                        <StarIconSolid className="w-2 h-2 lg:w-3 lg:h-3" />
                        <span className="hidden sm:inline">DESTACADO</span>
                        <span className="sm:hidden">DEST</span>
                      </>
                    )}
                  </div>
                </div>
              ) : null}

              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-4 gap-3">
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 lg:w-10 lg:h-10 rounded-lg lg:rounded-xl flex items-center justify-center flex-shrink-0 ${
                    item.type === 'encuesta' 
                      ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 border border-yellow-400/30' 
                      : 'bg-gradient-to-r from-twine-400/20 to-twine-600/20 border border-twine-400/30'
                  }`}>
                    {item.type === 'encuesta' ? (
                      <ChartBarIcon className="w-4 h-4 lg:w-5 lg:h-5 text-yellow-300" />
                    ) : (
                      <ChatBubbleLeftRightIcon className="w-4 h-4 lg:w-5 lg:h-5 text-twine-300" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-patria font-semibold text-base lg:text-lg truncate">
                      {item.titulo}
                    </h3>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2 text-twine-200 text-xs lg:text-sm font-patria mt-1">
                      <span className="capitalize">{item.type === 'encuesta' ? 'Encuesta' : 'Publicación'}</span>
                      <span className="hidden sm:inline">•</span>
                      <div className="flex items-center space-x-1">
                        <ClockIcon className="w-3 h-3" />
                        <span className="truncate">
                          {new Date(item.fecha).toLocaleDateString('es-MX', { 
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-patria font-bold self-start lg:self-center ${
                  item.type === 'encuesta' 
                    ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30' 
                    : 'bg-twine-500/20 text-twine-300 border border-twine-400/30'
                }`}>
                  <span className="lg:hidden">
                    {item.type === 'encuesta' ? 'Encuesta' : 'Pub.'}
                    {item.es_destacado && item.type === 'publicacion' && ' • Dest.'}
                  </span>
                  <span className="hidden lg:inline">
                    {item.type === 'encuesta' ? 'Encuesta' : 'Publicación'}
                    {item.es_destacado && item.type === 'publicacion' && ' • Destacada'}
                  </span>
                </span>
              </div>

              {item.type === 'publicacion' ? (
                <>
                  {/* Contenido de publicación */}
                  <p className="text-twine-200 font-patria mb-4 leading-relaxed whitespace-pre-line text-sm lg:text-base">
                    {item.contenido.length > 200 ? `${item.contenido.substring(0, 200)}...` : item.contenido}
                  </p>
                  
                  {/* Mostrar imagen si existe */}
                  {item.imagen_url && (
                    <div className="mb-4">
                      <img
                        src={`${API_URL}${item.imagen_url}`}
                        alt={item.titulo}
                        className="w-full h-48 lg:h-64 object-cover rounded-lg lg:rounded-xl border border-white/10"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          const placeholder = document.createElement('div');
                          placeholder.className = 'w-full h-48 lg:h-64 bg-gradient-to-r from-twine-500/20 to-twine-600/20 rounded-lg lg:rounded-xl border border-twine-400/30 flex items-center justify-center';
                          placeholder.innerHTML = `
                            <div class="text-center">
                              <div class="w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-twine-400/30 to-twine-600/30 rounded-lg flex items-center justify-center mx-auto mb-2 border border-twine-400/20">
                                <svg class="w-5 h-5 lg:w-6 lg:h-6 text-twine-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                              </div>
                              <p class="text-twine-300 text-xs lg:text-sm font-patria">Imagen no disponible</p>
                            </div>
                          `;
                          e.target.parentElement.appendChild(placeholder);
                        }}
                      />
                    </div>
                  )}

                  {item.etiquetas && item.etiquetas.length > 0 && (
                    <div className="flex flex-wrap gap-1 lg:gap-2 mb-4">
                      {item.etiquetas.map((etiqueta, index) => (
                        <span 
                          key={index}
                          className="px-2 py-0.5 lg:px-3 lg:py-1 bg-white/5 rounded-full text-xs text-twine-300 font-patria border border-white/10"
                        >
                          #{etiqueta}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-col lg:flex-row lg:items-center justify-between pt-3 lg:pt-4 border-t border-white/10 gap-3 lg:gap-0">
                    <div className="flex items-center space-x-4 lg:space-x-6">
                      <button
                        onClick={() => handleLikePublication(item.id, item.likes)}
                        disabled={likingPublication === item.id}
                        className="flex items-center space-x-1 lg:space-x-2 text-twine-200 hover:text-white transition-colors duration-300 font-patria disabled:opacity-50 text-sm"
                      >
                        {item.likes >= 50 ? (
                          <StarIconSolid className="w-4 h-4 lg:w-5 lg:h-5 text-yellow-400" />
                        ) : (
                          <HeartIcon className="w-4 h-4 lg:w-5 lg:h-5 text-twine-300 hover:text-red-400 transition-colors" />
                        )}
                        <span className={item.likes >= 50 ? 'text-yellow-300 font-bold' : ''}>
                          {item.likes}
                        </span>
                      </button>
                      <div className="flex items-center space-x-1 lg:space-x-2 text-twine-200 font-patria text-sm">
                        <EyeIcon className="w-4 h-4 lg:w-5 lg:h-5 text-blue-300" />
                        <span>{item.vistas}</span>
                      </div>
                      <div className="flex items-center space-x-1 lg:space-x-2 text-twine-200 font-patria text-sm">
                        <ChatBubbleLeftRightIcon className="w-4 h-4 lg:w-5 lg:h-5 text-green-300" />
                        <span>{item.total_comentarios || 0}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2 self-end lg:self-center">
                      <button
                        onClick={() => handleDeletePublication(item.id, item.titulo)}
                        className="flex items-center space-x-1 px-2 py-1 lg:px-3 lg:py-1 bg-red-500/20 text-red-300 rounded-lg lg:rounded-xl hover:bg-red-500/30 transition-colors duration-300 font-patria text-xs lg:text-sm border border-red-400/30"
                      >
                        <TrashIcon className="w-3 h-3" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Contenido de encuesta */}
                  <p className="text-twine-200 font-patria mb-4 leading-relaxed text-sm lg:text-base">
                    <span className="font-semibold text-yellow-300">Pregunta:</span> "
                    {item.pregunta.length > 100 ? `${item.pregunta.substring(0, 100)}...` : item.pregunta}
                    "
                  </p>

                  {item.descripcion && (
                    <p className="text-twine-200 font-patria mb-4 text-xs lg:text-sm bg-white/5 p-2 lg:p-3 rounded-lg lg:rounded-xl border border-white/10">
                      {item.descripcion.length > 150 ? `${item.descripcion.substring(0, 150)}...` : item.descripcion}
                    </p>
                  )}

                  <div className="flex flex-col lg:flex-row lg:items-center justify-between pt-3 lg:pt-4 border-t border-white/10 gap-3 lg:gap-0">
                    <div className="flex items-center space-x-4 lg:space-x-6">
                      <div className="flex items-center space-x-1 lg:space-x-2 text-twine-200 font-patria text-sm">
                        <ChartBarIcon className="w-4 h-4 lg:w-5 lg:h-5 text-yellow-300" />
                        <span>{item.total_respuestas} respuestas</span>
                      </div>
                      {item.fecha_cierre && (
                        <div className="flex items-center space-x-1 lg:space-x-2 text-twine-200 font-patria text-sm">
                          <ClockIcon className="w-4 h-4 lg:w-5 lg:h-5 text-blue-300" />
                          <span className="truncate max-w-[150px] lg:max-w-none">
                            {item.esta_cerrada ? 'Cerrada' : `Cierra: ${new Date(item.fecha_cierre).toLocaleDateString('es-MX', {
                              day: '2-digit',
                              month: 'short'
                            })}`}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex space-x-2 self-end lg:self-center">
                      <button
                        onClick={() => handleViewSurveyStats(item.id)}
                        className="flex items-center space-x-1 px-2 py-1 lg:px-3 lg:py-1 bg-yellow-500/20 text-yellow-300 rounded-lg lg:rounded-xl hover:bg-yellow-500/30 transition-colors duration-300 font-patria text-xs lg:text-sm border border-yellow-400/30"
                      >
                        <ChartBarIcon className="w-3 h-3" />
                        <span>Resultados</span>
                      </button>
                      <button
                        onClick={() => handleDeleteSurvey(item.id, item.titulo)}
                        className="flex items-center space-x-1 px-2 py-1 lg:px-3 lg:py-1 bg-red-500/20 text-red-300 rounded-lg lg:rounded-xl hover:bg-red-500/30 transition-colors duration-300 font-patria text-xs lg:text-sm border border-red-400/30"
                      >
                        <TrashIcon className="w-3 h-3" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>

      {/* Ver más - Solo mostrar si hay elementos */}
      {filteredItems.length > 0 && filteredItems.length > 3 && (
        <div className="text-center mt-4 lg:mt-6 pt-4 lg:pt-6 border-t border-white/10">
          <button className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 lg:px-6 lg:py-3 rounded-lg lg:rounded-xl hover:bg-white/20 transition-all duration-300 font-patria text-sm lg:text-base">
            Ver más publicaciones
          </button>
        </div>
      )}
    </div>
  );
};

export default ProfilePublications;