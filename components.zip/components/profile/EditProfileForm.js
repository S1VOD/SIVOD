import React, { useState } from 'react';
import ProfilePhotoUpload from '../../components/profile/ProfilePhotoUpload';

const EditProfileForm = ({ userData, onSave, onCancel, isSaving }) => {
  const [formData, setFormData] = useState({
    nombre: userData.nombre,
    apellidoPaterno: userData.apellidoPaterno,
    apellidoMaterno: userData.apellidoMaterno || '',
    telefono: userData.telefono || '',
    n_cedula: userData.n_cedula || '',
    cargo: userData.cargo || '',
    ocupacion: userData.ocupacion || '',
    grado: userData.grado || '',
    grupo: userData.grupo || '',
    n_empleado: userData.n_empleado || '',
    fechaNacimiento: userData.fecha_nac || '',
    foto: null,
  });

  const [photoChanged, setPhotoChanged] = useState(false);
  const [restoreDefaultPhoto, setRestoreDefaultPhoto] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Manejar cambio de foto
  const handlePhotoChange = (photoData) => {
    if (photoData === 'DEFAULT_FOTO_PERFIL') {
      // Usuario quiere restaurar a foto por defecto
      setFormData(prev => ({
        ...prev,
        foto: 'Fotoperfil.jpg'
      }));
      setRestoreDefaultPhoto(true);
      setPhotoChanged(true);
    } else {
      // Usuario subió una nueva foto (Base64)
      setFormData(prev => ({
        ...prev,
        foto: photoData
      }));
      setRestoreDefaultPhoto(false);
      setPhotoChanged(true);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Para alumnos, no enviar el campo teléfono (no existe en su tabla)
    const dataToSend = { ...formData };

    if (userData.userType === 'alumno') {
      delete dataToSend.telefono; // Eliminar teléfono para alumnos
      delete dataToSend.n_empleado; // Eliminar número de empleado para alumnos
    }

    // Si no se cambió la foto, no enviar el campo
    if (!photoChanged) {
      delete dataToSend.foto;
    }

    onSave(dataToSend);
  };

  // Determinar si el usuario es alumno
  const isAlumno = userData.userType === 'alumno';
  
  // Determinar si el usuario es educativo o administrativo
  const isEmpleado = userData.userType === 'educativo' || userData.userType === 'administrativo';

  // Campos específicos según el tipo de usuario
  const getUserSpecificFields = () => {
    switch (userData.userType) {
      case 'educativo':
        return (
          <>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Número de Cédula</label>
              <input
                type="text"
                name="n_cedula"
                value={formData.n_cedula}
                onChange={handleChange}
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Ej: CED123456"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Número de Empleado</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {formData.n_empleado || 'No asignado'} <span className="text-xs text-twine-300">(No editable)</span>
              </div>
            </div>
          </>
        );
      case 'administrativo':
        return (
          <>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Cargo</label>
              <input
                type="text"
                name="cargo"
                value={formData.cargo}
                onChange={handleChange}
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Ej: Secretaria"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Número de Empleado</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {formData.n_empleado || 'No asignado'} <span className="text-xs text-twine-300">(No editable)</span>
              </div>
            </div>
          </>
        );
      case 'tutor':
        return (
          <div>
            <label className="block text-sm font-semibold text-white font-patria mb-1">Ocupación</label>
            <input
              type="text"
              name="ocupacion"
              value={formData.ocupacion}
              onChange={handleChange}
              className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
              placeholder="Ej: Ingeniero"
            />
          </div>
        );
      case 'alumno':
        return (
          <>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Grado</label>
              <input
                type="text"
                name="grado"
                value={formData.grado}
                onChange={handleChange}
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Ej: 6to"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Grupo</label>
              <input
                type="text"
                name="grupo"
                value={formData.grupo}
                onChange={handleChange}
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Ej: A"
              />
            </div>
            {userData.tutor_nombre && (
              <div>
                <label className="block text-sm font-semibold text-white font-patria mb-1">Tutor Asignado</label>
                <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                  {userData.tutor_nombre} {userData.tutor_ape_pa}
                  <span className="text-xs text-twine-300 block">(No editable)</span>
                </div>
              </div>
            )}
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-patria font-bold text-white">Editar Información Personal</h2>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Foto de perfil */}
        <div className="mb-8 p-6 bg-white/5 rounded-2xl border border-white/10">
          <h3 className="text-xl font-patria font-bold text-white mb-4">Foto de Perfil</h3>
          <ProfilePhotoUpload
            currentPhoto={userData.foto}
            onPhotoChange={handlePhotoChange}
            disabled={isSaving}
          />
          {restoreDefaultPhoto && (
            <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
              <p className="text-yellow-300 text-sm font-patria">
                ✓ La foto se restaurará a la imagen por defecto
              </p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Información básica */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Nombre *</label>
              <input
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleChange}
                required
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Tu nombre"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Apellido Paterno *</label>
              <input
                type="text"
                name="apellidoPaterno"
                value={formData.apellidoPaterno}
                onChange={handleChange}
                required
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Tu apellido paterno"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Apellido Materno</label>
              <input
                type="text"
                name="apellidoMaterno"
                value={formData.apellidoMaterno}
                onChange={handleChange}
                className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                placeholder="Tu apellido materno"
              />
            </div>

            {/* Campos específicos del usuario */}
            {getUserSpecificFields()}
          </div>

          {/* Información de contacto y datos fijos */}
          <div className="space-y-4">
            {/* SOLO MOSTRAR TELÉFONO PARA NO ALUMNOS */}
            {!isAlumno && (
              <div>
                <label className="block text-sm font-semibold text-white font-patria mb-1">Teléfono</label>
                <input
                  type="tel"
                  name="telefono"
                  value={formData.telefono}
                  onChange={handleChange}
                  className="w-full bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl px-3 py-2 text-white placeholder-twine-200 font-patria focus:border-twine-400 focus:ring-2 focus:ring-twine-400/30 transition-all duration-300"
                  placeholder="Ej: 5551234567"
                />
              </div>
            )}

            {/* Información no editable */}
            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Fecha de Nacimiento</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.fechaNacimiento} <span className="text-xs text-twine-300">(No editable)</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">CURP</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.curp} <span className="text-xs text-twine-300">(No editable)</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-white font-patria mb-1">Correo electrónico</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.email} <span className="text-xs text-twine-300">(No editable)</span>
              </div>
            </div>

            {/* ESPACIO EXTRA PARA ALUMNOS (para mantener diseño balanceado) */}
            {isAlumno && (
              <div className="pt-4">
                <p className="text-sm text-twine-300 font-patria">
                  <span className="text-white font-semibold">Información de contacto:</span><br />
                  Para alumnos, la información de contacto se gestiona a través del tutor asignado.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Botones de acción */}
        <div className="mt-8 pt-6 border-t border-white/10 flex justify-end space-x-4">
          <button
            type="button"
            onClick={onCancel}
            disabled={isSaving}
            className="px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-xl hover:bg-white/20 transition-all duration-300 font-patria font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-3 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {isSaving ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Guardando...
              </>
            ) : (
              'Guardar Cambios'
            )}
          </button>
        </div>
      </form>

      {/* Nota informativa */}
      <div className="mt-6 p-4 bg-white/5 rounded-xl border border-white/10">
        <p className="text-sm text-twine-200 font-patria">
          <span className="font-bold text-white">Nota:</span> Los campos marcados como "No editable" requieren contacto con el administrador del sistema para ser modificados. Para cambios en tu CURP, fecha de nacimiento, tipo de usuario, número de empleado o asignación de escuela, por favor contacta al soporte técnico.
          {isAlumno && (
            <span className="block mt-2">
              <span className="font-bold text-white">Para alumnos:</span> La información de contacto se maneja a través del tutor asignado. Cambios en el tutor deben ser gestionados por el administrador.
            </span>
          )}
        </p>
      </div>
    </div>
  );
};

export default EditProfileForm;