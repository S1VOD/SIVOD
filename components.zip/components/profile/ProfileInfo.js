import React from 'react';

const ProfileInfo = ({ userData, onEditClick }) => {
  if (!userData) return null; // Si no hay datos, no renderizar
  
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-patria font-bold text-white">Información Personal</h2>
        <button 
          onClick={onEditClick}
          className="bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white px-4 py-2 rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria"
        >
          Editar Información
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Información básica */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Nombre completo</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
              {userData.nombre} {userData.apellidoPaterno} {userData.apellidoMaterno}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">CURP</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
              {userData.curp || 'No especificado'}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Fecha de Nacimiento</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
              {userData.fechaNacimiento ? new Date(userData.fechaNacimiento).toLocaleDateString('es-MX') : 'No especificada'}
            </div>
          </div>
        </div>

        {/* Información de contacto */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Correo electrónico</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
              {userData.email || 'No especificado'}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Teléfono</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
              {userData.telefono || 'No especificado'}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Tipo de usuario</label>
            <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10 capitalize">
              {userData.userType || 'No especificado'}
            </div>
          </div>
        </div>
      </div>

      {/* Información de la escuela - solo si existe */}
      {userData.escuela && (
        <div className="mt-6 pt-6 border-t border-white/10">
          <h3 className="text-xl font-patria font-bold text-white mb-4">Información de la Escuela</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Nombre de la escuela</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.escuela.nombre || 'No especificada'}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">CCT</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.escuela.cct || 'No especificado'}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Municipio</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.escuela.municipio || 'No especificado'}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-twine-300 font-patria mb-1">Turno</label>
              <div className="text-white font-patria bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                {userData.escuela.turno || 'No especificado'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileInfo;