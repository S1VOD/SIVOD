import React from 'react';

const ProfileMedals = ({ medallas }) => {
  const getMedalColor = (nivel) => {
    const colors = {
      oro: 'from-yellow-400 to-yellow-600',
      plata: 'from-gray-300 to-gray-500',
      bronce: 'from-orange-700 to-orange-900'
    };
    return colors[nivel] || 'from-twine-400 to-twine-600';
  };

  const getMedalIcon = (nivel) => {
    const icons = {
      oro: '★',
      plata: '◆',
      bronce: '●'
    };
    return icons[nivel] || '✓';
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <h2 className="text-2xl font-patria font-bold text-white mb-6">Reconocimientos y Medallas</h2>
      
      {medallas.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
            <div className="w-8 h-8 bg-gradient-to-r from-twine-400 to-twine-600 rounded-lg"></div>
          </div>
          <p className="text-twine-200 font-patria">Aún no tienes reconocimientos</p>
          <p className="text-twine-300 text-sm font-patria mt-1">Participa en evaluaciones para obtener medallas</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {medallas.map((medalla) => (
            <div 
              key={medalla.id}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 transform hover:scale-105 transition-all duration-300"
            >
              <div className={`w-12 h-12 bg-gradient-to-br ${getMedalColor(medalla.nivel)} rounded-full flex items-center justify-center mx-auto mb-3 border-2 border-white/20`}>
                <span className="text-white font-bold text-lg">
                  {getMedalIcon(medalla.nivel)}
                </span>
              </div>
              <h3 className="text-white font-patria font-bold text-center mb-2 capitalize">
                {medalla.nombre}
              </h3>
              <div className="text-center">
                <span className={`inline-block px-2 py-1 rounded-full text-xs font-patria font-bold capitalize ${
                  medalla.nivel === 'oro' ? 'bg-yellow-500/20 text-yellow-300' :
                  medalla.nivel === 'plata' ? 'bg-gray-400/20 text-gray-300' :
                  'bg-orange-700/20 text-orange-300'
                }`}>
                  {medalla.nivel}
                </span>
              </div>
              <p className="text-twine-200 text-xs text-center mt-2 font-patria">
                Obtenido el {new Date(medalla.fecha).toLocaleDateString('es-MX')}
              </p>
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-6 pt-6 border-t border-white/10">
        <button className="w-full bg-white/10 backdrop-blur-sm border border-white/20 text-white py-3 rounded-xl hover:bg-white/20 transition-all duration-300 font-patria">
          Ver todos los reconocimientos
        </button>
      </div>
    </div>
  );
};

export default ProfileMedals;