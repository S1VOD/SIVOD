import React, { useState } from 'react';
import InfoModal from '../common/InfoModal';

const ProfileHeader = ({ userData }) => {
  const [showInfoModal, setShowInfoModal] = useState(false);

  const getProfileInfo = () => {
    return {
      title: 'Panel de Perfil',
      description: 'En esta ventana podrás gestionar toda tu información personal, ver tus publicaciones, editar datos y revisar tu actividad en la plataforma.',
      sections: [
        {
          title: 'Información Personal',
          items: [
            'Ver y editar tus datos básicos de contacto',
            'Actualizar tu foto de perfil',
            'Modificar información profesional',
            'Gestionar preferencias de privacidad'
          ]
        },
        {
          title: 'Publicaciones y Contenido',
          items: [
            'Revisar tus publicaciones creadas',
            'Ver encuestas en las que has participado',
            'Consultar logros y reconocimientos',
            'Gestionar tu historial de actividades'
          ]
        },
        {
          title: 'Configuración y Seguridad',
          items: [
            'Actualizar contraseña y datos de acceso',
            'Configurar notificaciones y preferencias',
            'Revisar dispositivos conectados',
            'Exportar datos personales'
          ]
        }
      ],
      advice: 'Mantén tu información actualizada para una mejor experiencia en la plataforma y revisa regularmente tu configuración de privacidad.'
    };
  };

  const profileInfo = getProfileInfo();

  // Obtener iniciales para la foto
  const getInitials = () => {
    if (userData?.nombre && userData?.apellidoPaterno) {
      return `${userData.nombre.charAt(0)}${userData.apellidoPaterno.charAt(0)}`;
    }
    return 'US';
  };

  return (
    <>
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          {/* Foto de perfil */}
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-twine-400 to-twine-600 rounded-2xl flex items-center justify-center border-4 border-white/20 relative">
              {userData?.foto ? (
                <img 
                  src={userData.foto} 
                  alt="Foto de perfil" 
                  className="w-full h-full rounded-2xl object-cover"
                />
              ) : (
                <div className="text-3xl text-white font-patria font-bold">
                  {getInitials()}
                </div>
              )}
              
              {/* Botón de información */}
              <button
                onClick={() => setShowInfoModal(true)}
                className="absolute -top-2 -right-2 w-6 h-6 bg-twine-500 rounded-full flex items-center justify-center border border-white/20 hover:bg-twine-600 transition-all duration-300 group"
                aria-label="Información del perfil"
              >
                <span className="text-white text-xs font-bold font-patria group-hover:scale-110 transition-transform">i</span>
              </button>
            </div>
            <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-twine-500 rounded-full flex items-center justify-center border-2 border-white/20 hover:bg-twine-600 transition-all duration-300">
              <div className="w-4 h-4 bg-white rounded-sm"></div>
            </button>
          </div>

          {/* Información principal */}
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl font-patria font-bold text-white mb-2">
              {userData?.nombre || 'Usuario'} {userData?.apellidoPaterno || ''} {userData?.apellidoMaterno || ''}
            </h1>
            <p className="text-twine-200 font-patria mb-3">{userData?.email || 'No especificado'}</p>
            
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl border border-white/20">
                <span className="text-white font-patria font-medium capitalize">
                  {userData?.userType || 'Usuario'}
                </span>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl border border-white/20">
                <span className="text-white font-patria">
                  {userData?.escuela?.nombre || 'Sin escuela asignada'}
                </span>
              </div>
            </div>
          </div>

          {/* Estado del perfil - VERSIÓN MINIMALISTA */}
          <div className="text-center">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10 min-w-[180px]">
              <div className="mb-2">
                <div className="text-sm text-twine-300 font-patria mb-1">Estado de la cuenta</div>
                <div className="flex items-center justify-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${userData?.activo === 1 ? 'bg-green-400' : 'bg-yellow-400'}`}></div>
                  <div className={`text-lg font-patria font-semibold ${userData?.activo === 1 ? 'text-green-300' : 'text-yellow-300'}`}>
                    {userData?.activo === 1 ? 'Activa' : 'Pendiente'}
                  </div>
                </div>
              </div>
              
              <div className="pt-2 border-t border-white/10">
                <div className="text-xs text-twine-300 font-patria mb-1">Verificación</div>
                <div className={`text-sm font-patria ${userData?.activo === 1 ? 'text-green-200' : 'text-yellow-200'}`}>
                  {userData?.activo === 1 ? 'Completada' : 'En proceso'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Información usando el componente externo */}
      <InfoModal
        isOpen={showInfoModal}
        onClose={() => setShowInfoModal(false)}
        title={profileInfo.title}
        description={profileInfo.description}
        sections={profileInfo.sections}
        advice={profileInfo.advice}
      />
    </>
  );
};

export default ProfileHeader;