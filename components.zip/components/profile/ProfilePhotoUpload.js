import React, { useState, useRef } from 'react';

const ProfilePhotoUpload = ({ currentPhoto, onPhotoChange, disabled = false }) => {
  const [preview, setPreview] = useState(currentPhoto || null);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  // Formatos permitidos
  const allowedFormats = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  const maxSizeMB = 5; // 5MB máximo

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setError('');

    if (!file) return;

    // Validar formato
    if (!allowedFormats.includes(file.type)) {
      setError('Formato no válido. Usa JPG, PNG, GIF o WebP.');
      return;
    }

    // Validar tamaño (5MB máximo)
    if (file.size > maxSizeMB * 1024 * 1024) {
      setError(`La imagen es muy grande. Máximo ${maxSizeMB}MB.`);
      return;
    }

    // Crear preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result);
      // Convertir a base64 para enviar al backend
      onPhotoChange(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setPreview(null);
    // Enviar señal especial para restaurar a foto por defecto
    onPhotoChange('DEFAULT_FOTO_PERFIL');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleButtonClick = () => {
    if (!disabled) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center">
        {/* Foto actual / preview */}
        <div className="relative group">
          <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-white/20 bg-white/10">
            {preview ? (
              <img
                src={preview}
                alt="Preview"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-4xl text-twine-300">
                  <svg className="w-20 h-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
              </div>
            )}
          </div>

          {/* Overlay para upload */}
          {!disabled && (
            <div
              onClick={handleButtonClick}
              className="absolute inset-0 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center cursor-pointer"
            >
              <div className="text-white text-center">
                <svg className="w-10 h-10 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span className="text-sm font-patria">Cambiar foto</span>
              </div>
            </div>
          )}
        </div>

        {/* Input file oculto */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".jpg,.jpeg,.png,.gif,.webp"
          className="hidden"
          disabled={disabled}
        />

        {/* Botones de acción */}
        <div className="mt-4 flex space-x-3">
          <button
            type="button"
            onClick={handleButtonClick}
            disabled={disabled}
            className="px-4 py-2 bg-gradient-to-r from-twine-500/90 to-twine-600/90 text-white rounded-xl hover:from-twine-600 hover:to-twine-700 transition-all duration-300 font-patria text-sm disabled:opacity-50"
          >
            {preview ? 'Cambiar Foto' : 'Subir Foto'}
          </button>

          {preview && preview !== currentPhoto && !disabled && (
            <button
              type="button"
              onClick={handleRemovePhoto}
              disabled={disabled}
              className="px-4 py-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all duration-300 font-patria text-sm"
            >
              Quitar
            </button>
          )}
        </div>
      </div>

      {/* Mensajes de error/ayuda */}
      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
          <p className="text-red-300 text-sm font-patria">{error}</p>
        </div>
      )}

      <div className="p-3 bg-white/5 rounded-xl">
        <p className="text-twine-200 text-sm font-patria">
          <span className="font-bold text-white">Nota:</span> Al hacer clic en "Restaurar por defecto", se usará la foto "Fotoperfil.jpg".
          <br />
          <span className="font-bold text-white">Formatos aceptados:</span> JPG, PNG, GIF, WebP
          <br />
          <span className="font-bold text-white">Tamaño máximo:</span> 5MB
          <br />
          <span className="text-xs">Recomendado: 400x400 px para mejor calidad</span>
        </p>
      </div>
    </div>
  );
};

export default ProfilePhotoUpload;