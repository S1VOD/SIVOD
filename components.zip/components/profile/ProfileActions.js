import React from 'react';
import {
  PencilSquareIcon,
  LockClosedIcon,
  Cog6ToothIcon,
  DocumentTextIcon,
  ArrowRightIcon,
  ArrowDownTrayIcon,
  UserCircleIcon,
  ShieldCheckIcon,
  BellIcon,
  FolderIcon,
  ChevronRightIcon,
  DocumentArrowDownIcon
} from '@heroicons/react/24/outline';

const ProfileActions = ({ userData, onEditProfile }) => {
  const actions = [
    {
      title: 'Editar Perfil',
      description: 'Actualiza tu información personal',
      type: 'edit',
      icon: <PencilSquareIcon className="h-6 w-6" />,
      onClick: () => onEditProfile(),
      color: 'from-blue-500/30 to-cyan-500/30',
      iconColor: 'text-blue-300'
    },
    {
      title: 'Cambiar Contraseña',
      description: 'Actualiza tu contraseña de acceso',
      type: 'security',
      icon: <LockClosedIcon className="h-6 w-6" />,
      color: 'from-green-500/30 to-emerald-500/30',
      iconColor: 'text-green-300'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/20 shadow-xl">
      {/* Header con icono */}
      <div className="flex items-center mb-8">
        <div className="w-12 h-12 bg-gradient-to-r from-twine-500/30 to-twine-600/30 rounded-xl flex items-center justify-center border border-twine-400/30 mr-4">
          <UserCircleIcon className="h-7 w-7 text-twine-300" />
        </div>
        <div>
          <h2 className="text-2xl font-patria font-bold text-white">Acciones Rápidas</h2>
          <p className="text-twine-200 text-sm font-patria">Gestiona tu cuenta y preferencias</p>
        </div>
      </div>
      
      {/* Lista de acciones */}
      <div className="space-y-5 mb-8">
        {actions.map((action, index) => (
          <button 
            key={index}
            onClick={action.onClick}
            className="group w-full bg-gradient-to-br from-white/5 to-white/2 backdrop-blur-sm border border-white/10 rounded-xl p-5 text-left hover:bg-white/10 hover:border-white/20 hover:shadow-lg transition-all duration-300"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-14 h-14 bg-gradient-to-r ${action.color} rounded-xl flex items-center justify-center border border-white/20 group-hover:scale-110 transition-transform duration-300`}>
                  <div className={action.iconColor}>
                    {action.icon}
                  </div>
                </div>
                <div>
                  <h3 className="text-white font-patria font-semibold text-lg group-hover:text-twine-200 transition-colors duration-300">
                    {action.title}
                  </h3>
                  <p className="text-twine-200 text-sm font-patria mt-1">
                    {action.description}
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center group-hover:bg-white/10 transition-colors duration-300">
                  <ChevronRightIcon className="h-5 w-5 text-white group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ProfileActions;