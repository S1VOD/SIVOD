import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  DocumentArrowUpIcon, 
  CheckCircleIcon,
  XCircleIcon,
  ShieldCheckIcon,
  UserCircleIcon,
  InformationCircleIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';
import { useDocumentValidation } from '../../hooks/useDocumentValidation';

const AccountVerificationUploader = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [verificationStatus, setVerificationStatus] = useState('pending'); // pending, processing, success, error
  const [verificationResult, setVerificationResult] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [uploadKey, setUploadKey] = useState(Date.now()); // Para resetear el input file
  const navigate = useNavigate();
  
  const { 
    validateDocument, 
    validationResult, 
    isLoading, 
    error: validationError,
    resetValidation 
  } = useDocumentValidation();

  const userType = localStorage.getItem('userType');
  const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');

  // Resetear estados cuando se monta el componente
  useEffect(() => {
    resetLocalState();
  }, []);

  const resetLocalState = () => {
    setSelectedFile(null);
    setVerificationStatus('pending');
    setVerificationResult(null);
    setErrorMessage(null);
    resetValidation();
    // Forzar reset del input file
    setUploadKey(Date.now());
  };

  // Tipos de documentos según usuario
  const getDocumentTypes = () => {
    switch(userType) {
      case 'educativo':
        return ['Constancia de trabajo escolar', 'Carta de nombramiento', 'Nómina educativa'];
      case 'administrativo':
        return ['Constancia administrativa', 'Contrato laboral', 'Nómina administrativa'];
      case 'tutor':
        return ['Identificación oficial (INE)', 'Comprobante de parentesco', 'Acta de nacimiento del alumno'];
      case 'alumno':
        return ['Acta de nacimiento', 'Certificado de estudios anterior', 'Credencial escolar'];
      default:
        return ['Documento oficial de identificación'];
    }
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && file.type === 'application/pdf') {
      setSelectedFile(file);
      setVerificationStatus('pending');
      setVerificationResult(null);
      setErrorMessage(null);
    } else {
      alert('Por favor, selecciona un archivo PDF válido');
      // Limpiar el input
      event.target.value = '';
    }
  };

  const activateAccount = async (verificationData) => {
    try {
      const userId = localStorage.getItem('userId');
      const userType = localStorage.getItem('userType');
      const token = localStorage.getItem('token');
      
      console.log('Activando cuenta para:', { userId, userType });
      
      const response = await fetch('http://localhost:8000/api/v1/activate-account', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          userId: parseInt(userId),
          userType: userType,
          verificationResult: verificationData
        })
      });

      const result = await response.json();
      console.log('Respuesta de activación:', result);
      
      if (result.success) {
        // Actualizar localStorage
        const currentProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
        
        // Actualizar con los datos del servidor
        if (result.userData) {
          Object.assign(currentProfile, result.userData);
        } else {
          currentProfile.activo = 1;
        }
        
        localStorage.setItem('userProfile', JSON.stringify(currentProfile));
        localStorage.setItem('accountActive', 'true');
        
        console.log('✅ Cuenta activada en frontend');
        return true;
      } else {
        throw new Error(result.message || 'Error activando cuenta');
      }
    } catch (error) {
      console.error('❌ Error activando cuenta:', error);
      throw error;
    }
  };

  const handleVerification = async () => {
    if (!selectedFile) {
      setErrorMessage('Por favor, selecciona un documento PDF');
      return;
    }

    setVerificationStatus('processing');
    setErrorMessage(null);
    
    try {
      console.log('🔍 Validando documento:', selectedFile.name);
      
      const result = await validateDocument(selectedFile);
      setVerificationResult(result);
      
      console.log('📊 Resultado de validación:', result);

      if (result.isValid && result.documentType !== 'no-oficial' && result.documentType !== 'error') {
        console.log('✅ Documento válido, activando cuenta...');
        
        const activationSuccess = await activateAccount(result);
        
        if (activationSuccess) {
          setVerificationStatus('success');
          
          // Limpiar el archivo después de éxito
          setSelectedFile(null);
          
          // Redirigir después de 3 segundos
          setTimeout(() => {
            navigate('/dashboard');
          }, 3000);
        } else {
          setVerificationStatus('error');
          setErrorMessage('Error al activar la cuenta. Intenta nuevamente.');
        }
      } else {
        // Documento no válido
        console.log('❌ Documento no válido:', result.reason);
        setVerificationStatus('error');
        setErrorMessage(`Documento no válido: ${result.reason || 'No es un documento oficial reconocido'}`);
        
        // Limpiar archivo y resetear input
        setSelectedFile(null);
        setUploadKey(Date.now()); // Forzar reset del input
      }
    } catch (error) {
      console.error('❌ Error en verificación:', error);
      setVerificationStatus('error');
      setErrorMessage(`Error: ${error.message || 'Error en el proceso de validación'}`);
      
      // Limpiar archivo en caso de error
      setSelectedFile(null);
      setUploadKey(Date.now());
    }
  };

  const resetVerification = () => {
    resetLocalState();
  };

  // Obtener mensaje de estado
  const getStatusMessage = () => {
    switch(verificationStatus) {
      case 'success':
        return '¡Verificación exitosa! Redirigiendo al dashboard...';
      case 'error':
        return 'Verificación fallida';
      case 'processing':
        return 'Procesando documento...';
      default:
        return 'Esperando documento';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-twine-500/20 to-twine-600/20 rounded-2xl flex items-center justify-center border-2 border-twine-400/30 mx-auto mb-4">
          <ShieldCheckIcon className="w-8 h-8 text-twine-300" />
        </div>
        <h2 className="text-2xl font-patria font-bold text-white mb-2">
          Verificación de Cuenta
        </h2>
        <div className="text-twine-200 font-patria mb-1">
          {getStatusMessage()}
        </div>
      </div>

      {/* Información del usuario */}
      <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 mb-6 border border-white/10">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 bg-twine-500/20 rounded-xl flex items-center justify-center border border-twine-400/30">
            <UserCircleIcon className="w-6 h-6 text-twine-300" />
          </div>
          <div>
            <h3 className="text-lg font-patria font-bold text-white">Usuario a Verificar</h3>
            <p className="text-twine-200 text-sm font-patria">
              {userProfile?.nombre} {userProfile?.ape_pa} - {userType}
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-twine-200 text-xs mb-1">Tipo de Usuario</p>
            <p className="text-white font-medium capitalize">{userType}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <p className="text-twine-200 text-xs mb-1">Estado</p>
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
              userProfile?.activo === 1 
                ? 'bg-green-500/20 text-green-200' 
                : 'bg-red-500/20 text-red-200'
            }`}>
              {userProfile?.activo === 1 ? 'Verificado' : 'No Verificado'}
            </span>
          </div>
        </div>
      </div>

      {/* Documentos aceptados */}
      <div className="bg-twine-500/10 backdrop-blur-sm rounded-xl p-6 mb-6 border border-twine-400/20">
        <h3 className="text-lg font-patria font-bold text-white mb-3 flex items-center gap-2">
          <InformationCircleIcon className="w-5 h-5 text-twine-300" />
          Documentos Aceptados para {userType}
        </h3>
        <ul className="space-y-2">
          {getDocumentTypes().map((docType, index) => (
            <li key={index} className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-gradient-to-r from-twine-300 to-twine-400 rounded-sm flex-shrink-0"></div>
              <span className="text-twine-200 text-sm font-patria">{docType}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Subida de archivo */}
      <div className="space-y-6">
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
          <div className="file-input-container">
            <input
              key={uploadKey} // Esto fuerza el reset del input
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
              id="verificationFileInput"
              disabled={isLoading || verificationStatus === 'processing'}
            />
            <label 
              htmlFor="verificationFileInput" 
              className={`block w-full bg-white/10 backdrop-blur-sm border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-300 group ${
                selectedFile 
                  ? 'border-twine-400/50 bg-twine-500/10' 
                  : 'border-white/20 hover:border-white/30 hover:bg-white/15'
              }`}
            >
              <div className="w-12 h-12 bg-gradient-to-r from-twine-400 to-twine-600 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-300">
                <DocumentArrowUpIcon className="w-6 h-6 text-white" />
              </div>
              <div className="text-white font-patria font-semibold mb-2">
                {selectedFile ? 'Documento Listo' : 'Seleccionar Documento PDF'}
              </div>
              <div className="text-twine-200 text-sm font-patria">
                {selectedFile 
                  ? selectedFile.name 
                  : 'Haz clic aquí para seleccionar tu documento'
                }
              </div>
            </label>
          </div>
          
          {/* Mostrar nombre del archivo solo si hay uno seleccionado */}
          {selectedFile && (
            <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/10">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-twine-500/20 rounded-lg flex items-center justify-center">
                    <DocumentArrowUpIcon className="w-4 h-4 text-twine-300" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium truncate max-w-xs">
                      {selectedFile.name}
                    </p>
                    <p className="text-twine-300 text-xs">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedFile(null);
                    setUploadKey(Date.now()); // Resetear input
                  }}
                  className="w-8 h-8 bg-red-500/20 rounded-lg flex items-center justify-center border border-red-400/30 hover:bg-red-500/30 transition-colors"
                >
                  <XCircleIcon className="w-4 h-4 text-red-300" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Mensajes de error */}
        {/*{errorMessage && (
          <div className="bg-red-500/20 backdrop-blur-sm rounded-xl p-4 border border-red-400/30">
            <div className="flex items-center space-x-3">
              <XCircleIcon className="w-5 h-5 text-red-300 flex-shrink-0" />
              <p className="text-red-200 font-patria text-sm">{errorMessage}</p>
            </div>
          </div>
        )}*/}

        {/* Botón de verificación */}
        <button 
          onClick={handleVerification}
          disabled={!selectedFile || isLoading || verificationStatus === 'processing'}
          className="w-full py-4 bg-gradient-to-r from-twine-500/90 to-twine-600/90 backdrop-blur-sm border border-twine-400 text-white font-semibold rounded-2xl hover:from-twine-600 hover:to-twine-700 transform hover:scale-105 transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3 font-patria"
        >
          {isLoading || verificationStatus === 'processing' ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              Procesando documento...
            </>
          ) : (
            <>
              <ShieldCheckIcon className="w-5 h-5" />
              {verificationStatus === 'error' ? 'Intentar Nuevamente' : 'Verificar y Activar Cuenta'}
            </>
          )}
        </button>

        {/* Botón para resetear si hay error */}
        {verificationStatus === 'error' && (
          <button 
            onClick={resetVerification}
            className="w-full py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-2xl hover:bg-white/20 transition-all duration-300 flex items-center justify-center gap-2 font-patria"
          >
            <ArrowPathIcon className="w-4 h-4" />
            Seleccionar otro documento
          </button>
        )}

        {/* Resultados - Éxito */}
        {verificationStatus === 'success' && (
          <div className="bg-green-500/20 backdrop-blur-sm rounded-2xl p-6 border border-green-400/30 animate-pulse">
            <div className="flex items-center space-x-4">
              <CheckCircleIcon className="w-12 h-12 text-green-300" />
              <div>
                <h3 className="text-xl font-patria font-bold text-white">¡Verificación Exitosa!</h3>
                <p className="text-green-200 font-patria mt-2">
                  Tu cuenta ha sido verificada y activada correctamente.
                </p>
                <p className="text-green-100 text-sm font-patria mt-1">
                  Serás redirigido al dashboard en 3 segundos...
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Resultados - Error */}
        {verificationStatus === 'error' && verificationResult && (
          <div className="bg-red-500/20 backdrop-blur-sm rounded-2xl p-6 border border-red-400/30">
            <div className="flex items-center space-x-4">
              <XCircleIcon className="w-12 h-12 text-red-300" />
              <div>
                <h3 className="text-xl font-patria font-bold text-white">Verificación Fallida</h3>
                <div className="mt-2 space-y-2">
                  <p className="text-red-200 font-patria">
                    Motivo: {verificationResult.reason || 'Documento no válido'}
                  </p>
                  <p className="text-red-100 text-sm font-patria">
                    Tipo: {verificationResult.documentType || 'Desconocido'}
                  </p>
                  <p className="text-red-100 text-sm font-patria">
                    Confianza: {verificationResult.confidence || 0}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Información adicional */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="flex items-center justify-between">
          <div className="text-twine-300 text-sm font-patria">
            Proceso de verificación:
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${verificationStatus === 'pending' ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
            <div className={`w-3 h-3 rounded-full ${['processing', 'success', 'error'].includes(verificationStatus) ? 'bg-yellow-500' : 'bg-white/20'}`}></div>
            <div className={`w-3 h-3 rounded-full ${verificationStatus === 'success' ? 'bg-green-500' : 'bg-white/20'}`}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountVerificationUploader;